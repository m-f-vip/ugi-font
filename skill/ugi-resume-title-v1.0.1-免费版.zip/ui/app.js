/* ==========================================================================
   UGI Font · 工作台
   一个任务：把文本排成 32 位透明 text-mask。
   ========================================================================== */
'use strict';

const $ = (id) => document.getElementById(id);
const FAM_RENDER_CAP = 600;      // 一次最多渲染多少个家族分组
const LINE_MAX = 50;             // 输入契约 v1：单行文本 ≤ 50 字
/* 「当前选择字体」没有数量上限：15 只是卡片默认显示行数（见 WF_DISPLAY_ROWS），
   手动加入 / 按 tag 同步 / 替换建议都不截断，生成张数 = 当前选择字体数。 */

const state = {
  cfg: null,
  page: 'work',
  channel: 'local',
  mode: 'smart_tag',
  fonts: [],
  groups: [],
  poolIndex: new Map(),
  open: new Set(),               // 用户手动展开的家族
  qOpen: null,                   // 搜索时临时展开的家族（null = 未计算）
  sel: new Set(),
  work: [],
  manual: new Set(),             // 字库池手动加入的字体：权限最高，自动同步不覆盖
  bad: new Set(),                // 上次任务里加载失败的字体
  running: false,
  paused: false,
  stopping: false,               // 已点「结束」，等服务端收尾：中断按钮立刻复位
  results: [],
  startedAt: 0,
  curIdx: 0,                     // 「当前文本行」对应的文本框行号
  replaceBad: [],                // 本次缺字 / 不可用的字体 value
  replacePool: [],               // 按 tag + 白名单排出的替换候选
};

let pollTimer = null;
let saveTimer = null;
let busyTag = false;

const MODE_HINT = {
  smart_tag: '默认。先用结巴分词提取关键词，再按「智能tag + 指定tag」挑字体；手动加入的字体始终优先保留。',
  random: '把当前选择字体打乱顺序，每次生成不同；手动加入的字体始终优先保留。',
  specified: '全部当前选择字体，顺序不变，每个各出 1 张；手动加入的字体置顶。',
};

const MODE_LABEL = {
  smart_tag: '智能tag', random: '随机', specified: '指定',
};

/* ------------------------------------------------------------------ 工具 */

function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }

function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined) n.textContent = text;
  return n;
}

function toast(msg, kind) {
  const t = $('toast');
  t.textContent = msg;
  t.className = 'toast on' + (kind ? ' ' + kind : '');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { t.className = 'toast'; }, 2400);
}

async function api(path, body) {
  const opt = body === undefined ? {} : {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  };
  let res;
  try { res = await fetch(path, opt); }
  catch (e) { return { ok: false, error: '无法连接本地服务' }; }
  let data = null;
  try { data = await res.json(); } catch (e) { data = { ok: false, error: '响应不是 JSON' }; }
  if (!res.ok && data && !data.error) data.error = 'HTTP ' + res.status;
  return data;
}

function setSeg(container, active) {
  container.querySelectorAll('button').forEach((b) => {
    const key = b.dataset.channel || b.dataset.mode;
    b.classList.toggle('on', key === active);
  });
}

/* ------------------------------------------------------------------ 主 page */

function showPage(name) {
  state.page = name === 'param' ? 'param' : 'work';
  $('mainNav').querySelectorAll('.tab').forEach((b) => {
    b.classList.toggle('on', b.dataset.page === state.page);
  });
  $('pageWork').classList.toggle('on', state.page === 'work');
  $('pageParam').classList.toggle('on', state.page === 'param');
  if (location.hash !== '#' + state.page) {
    history.replaceState(null, '', '#' + state.page);
  }
}

/* ------------------------------------------------------------------ 配置 */

function fillForm(cfg) {
  const ta = $('text');
  ta.value = cfg.text || '';
  ta.selectionStart = ta.selectionEnd = 0;   // 首屏「当前文本行」落在第 1 行
  $('smartTag').value = cfg.smart_tag || '';
  $('specifiedTag').value = cfg.specified_tag ?? '屌丝，躺平';
  $('fontSize').value = cfg.font_size;
  $('maskMargin').value = cfg.mask_margin;
  $('charGap').value = cfg.char_gap ?? 0;
  $('opticalFit').checked = !!cfg.optical_fit;

  const api = cfg.api || {};
  $('apiPort').value = api.port;
  $('apiTimeout').value = api.ugi_timeout;
  $('apiFg').value = api.ugi_fg;
  $('apiBg').value = api.ugi_bg;
  $('apiOutput').value = api.ugi_output_format === 'b64' ? 'b64' : 'file';
  $('apiEndpoint').value = api.ugi_endpoint || '';
  $('apiListfonts').value = api.ugi_listfonts || '';
  $('apiStandard').value = api.ugi_standard_url || '';
  syncStandardLink();
  $('apiKey').value = api.ugi_key || '';
  $('autoFetchCloud').checked = api.auto_fetch_cloud !== false;

  $('outputDir').value = cfg.output_dir || '';

  // v2 架构：字库池恒为「字库池」（mtag 授权 ∩ 云端可达）。
  state.channel = 'cloud';
  state.mode = cfg.font_mode || 'smart_tag';
  if (!MODE_LABEL[state.mode]) state.mode = 'smart_tag';   // 旧配置里的 mixed 已移除，归一到默认
  state.work = (cfg.work_fonts || []).slice();
  state.manual = new Set(Array.isArray(cfg.manual_fonts) ? cfg.manual_fonts : []);
  setSeg($('fontModeSeg'), state.mode);
  $('fontModeLabel').textContent = MODE_LABEL[state.mode] || state.mode;
  $('modeHint').textContent = MODE_HINT[state.mode] || '';

  updateLineInfo();
  markTagLine();          // 初始化不覆盖已保存的 tag，之后由光标切行 / 启动刷新触发
  jobHint();
}

function readForm() {
  const cfg = JSON.parse(JSON.stringify(state.cfg || {}));
  cfg.font_size = clamp(parseInt($('fontSize').value, 10) || 160, 24, 1200);
  cfg.mask_margin = clamp(parseInt($('maskMargin').value, 10) || 0, 0, 16);
  cfg.char_gap = clamp(parseInt($('charGap').value, 10) || 0, 0, 60);
  cfg.optical_fit = $('opticalFit').checked;
  cfg.channel = state.channel;
  cfg.font_mode = state.mode;
  cfg.smart_tag = $('smartTag').value.trim();
  cfg.specified_tag = $('specifiedTag').value.trim();
  cfg.text = $('text').value;
  cfg.current_text = currentLine();
  cfg.output_modes = ['single'];            // 只出单行文本
  cfg.work_fonts = state.work.slice();
  cfg.selected_fonts = state.work.slice();
  cfg.manual_fonts = [...state.manual].filter((v) => state.work.includes(v));
  cfg.api = Object.assign({}, cfg.api, {
    port: clamp(parseInt($('apiPort').value, 10) || 8766, 1, 65535),
    ugi_timeout: clamp(parseFloat($('apiTimeout').value) || 40, 5, 180),
    ugi_fg: ($('apiFg').value || 'FFFFFF').replace('#', '').toUpperCase(),
    ugi_bg: ($('apiBg').value || '000000').replace('#', '').toUpperCase(),
    ugi_output_format: $('apiOutput').value === 'b64' ? 'b64' : 'file',
    ugi_endpoint: $('apiEndpoint').value.trim(),
    ugi_listfonts: $('apiListfonts').value.trim(),
    ugi_standard_url: $('apiStandard').value.trim(),
    ugi_key: $('apiKey').value.trim(),
    auto_fetch_cloud: $('autoFetchCloud').checked,
  });
  cfg.output_dir = $('outputDir').value.trim();
  return cfg;
}

function scheduleSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => saveConfig(true), 900);
}

async function saveConfig(silent) {
  const cfg = readForm();
  const d = await api('/api/config', { config: cfg });
  if (!d.ok) { toast(d.error || '保存失败', 'bad'); return null; }
  state.cfg = d.config;
  renderDirState(d.dirs);
  if (!silent) toast('设置已保存', 'ok');
  return d;
}

/* ------------------------------------------------------------------ 文本 */

/* 「当前文本行」= 光标落在文本池的第几行；落在空行时退回到第一个有内容的行 */
function curIndex() {
  const ta = $('text');
  const raw = ta.value || '';
  const arr = raw.split('\n');
  const pos = clamp(ta.selectionStart || 0, 0, raw.length);
  let idx = raw.slice(0, pos).split('\n').length - 1;
  if (!(arr[idx] || '').trim()) {
    const first = arr.findIndex((l) => l.trim());
    if (first >= 0) idx = first;
  }
  return clamp(idx, 0, arr.length - 1);
}

function currentLine() {
  const arr = ($('text').value || '').split('\n');
  return arr[state.curIdx] || '';
}

/* 改「当前文本行」= 改文本池里对应的那一行（t 字段） */
function setLineAt(idx, value) {
  const ta = $('text');
  const arr = (ta.value || '').split('\n');
  while (arr.length <= idx) arr.push('');
  arr[idx] = value;
  ta.value = arr.join('\n');
}

function updateLineInfo() {
  const arr = ($('text').value || '').split('\n');
  const n = arr.filter((l) => l.trim()).length;
  state.curIdx = curIndex();
  $('lineCount').textContent = n ? `第 ${state.curIdx + 1} / ${arr.length} 行` : '空';
  const box = $('curLine');
  const cur = arr[state.curIdx] || '';
  if (document.activeElement !== box) box.value = cur;
  box.title = `第 ${state.curIdx + 1} 行（t）· 当前文本行，可直接编辑，会同步回文本池`;
  updateLenInfo();
  followCurrentLine();     // 光标换行 / 本行内容变化 → 智能 tag 同步变化
}

/* 单行 ≤ 50 字：label 常显当前文本行字数，超限标红 */
function updateLenInfo() {
  const info = $('lenInfo');
  if (!info) return;
  const cur = (currentLine() || '').trim();
  const len = [...cur].length;
  info.textContent = `当前文本行 ${len} / ${LINE_MAX} 字` + (len > LINE_MAX ? ' · 超出，请精简' : '');
  info.classList.toggle('over', len > LINE_MAX);
  const over = ($('text').value || '').split('\n').some((l) => [...l.trim()].length > LINE_MAX);
  $('lineCount').classList.toggle('over', over);
  return len;
}

/* ------------------------------------------- 当前文本行变化 → 智能 tag 同步变化 */

let tagFollowTimer = null;
let lastTagKey = '';
let tagSeq = 0;

/* 记住当前「行号 + 行内容」，用于判断光标是否切到了另一行 / 本行是否被改写 */
function markTagLine() {
  lastTagKey = state.curIdx + '|' + (currentLine() || '').trim();
  clearTimeout(tagFollowTimer);
}

/* 策略下的预计出图张数，与后端 matrix_font_plan 的口径保持一致 */
/* 三种策略都出「当前选择字体」全集（手动加入的必出），区别只在顺序与自动重算 */
function expectedShots() {
  return state.work.length;
}

function followCurrentLine() {
  const line = (currentLine() || '').trim();
  if (!line) return;
  const key = state.curIdx + '|' + line;
  if (key === lastTagKey) return;
  lastTagKey = key;
  clearTimeout(tagFollowTimer);
  tagSeq += 1;
  const seq = tagSeq;
  tagFollowTimer = setTimeout(() => syncTagForLine(line, seq), 280);
}

/* 启动 / 手动「重新识别」时强制按当前文本行刷新一次 */
function refreshTagForCurrentLine() {
  const line = (currentLine() || '').trim();
  if (!line) return Promise.resolve(false);
  markTagLine();
  tagSeq += 1;
  return syncTagForLine(line, tagSeq);
}

async function syncTagForLine(line, seq) {
  let r = null;
  try {
    r = await api('/api/smart-tag', { text: line, topk: 6, follow: true });
  } catch (_) { return false; }
  if (seq !== tagSeq) return false;                 // 已有更新的当前文本行，丢弃过期结果
  if (!r || !r.ok) return false;
  const box = $('smartTag');
  if (document.activeElement === box) return false; // 用户正在手改 tag，不抢输入
  const next = r.smart_tag || '';
  if (box.value === next) return false;
  box.value = next;
  scheduleSave();
  // 智能tag 策略下 tag 变了要连带刷新「当前选择字体」，策略才真正起作用
  if (state.mode === 'smart_tag' && state._workInited) await syncWorkByTag(true);
  return true;
}

/* ------------------------------------------------------------------ 字库池 */

async function loadFonts() {
  const d = await api('/api/fonts?channel=' + encodeURIComponent(state.channel));
  if (!d.ok) { $('poolList').innerHTML = '<div class="empty">字库读取失败</div>'; return; }
  state.fonts = d.fonts || [];
  state.poolIndex = new Map(state.fonts.map((f) => [f.value, f]));
  renderPool();
  renderWork();
}

/* 重新拉云端字库清单：服务器陆续上线新字体时用。
   拉完轮询 catalog-status 直到就绪再读字库池；不动「当前选择字体」。 */
async function reloadFonts() {
  const btn = $('btnReloadFonts');
  if (btn && btn.disabled) return;
  const label = btn ? btn.textContent : '';
  if (btn) { btn.disabled = true; btn.textContent = '刷新中…'; }
  try {
    await api('/api/catalog?refresh=1&cloud=1');
    let ready = false;
    for (let i = 0; i < 20; i += 1) {
      await new Promise((r) => setTimeout(r, 1000));
      const d = await api('/api/catalog-status');
      if (d && d.ok) {
        $('pillFonts').textContent = `可用字体总数：${d.whitelist_reachable || 0}。`;
        if (d.ready) { ready = true; break; }
      }
    }
    await loadFonts();
    await ensureDefaultWork();
    const total = (state.fonts || []).length;
    toast(ready ? `字库已刷新：${total} 款可选` : `刷新超时，保留现有 ${total} 款`, ready ? 'ok' : 'bad');
  } catch (e) {
    toast('刷新失败：' + (e && e.message ? e.message : '网络异常'), 'bad');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = label || '刷新字库'; }
  }
}

/* 家族名去掉数字：ACIDBRANCH1 / ACIDBRANCH7 归到 ACIDBRANCH，CLAY3 / clay4 归到 CLAY
   （文件名里的编号、变体号不参与分家；比较用大小写不敏感，显示保留首次出现的写法） */
function famLabel(f) {
  const raw = f.family || f.stem || f.name || f.value || '未分组';
  const base = raw.replace(/\d+/g, '').replace(/[\s._-]+$/, '').trim();
  return base || raw;
}

function famKey(f) {
  return famLabel(f).toLowerCase();
}

function filteredFonts() {
  const q = ($('poolSearch').value || '').trim().toLowerCase();
  if (!q) return state.fonts;
  return state.fonts.filter((f) => (
    (f.name || '') + ' ' + (f.value || '') + ' ' + (f.family || '')
  ).toLowerCase().includes(q));
}

function buildGroups(rows) {
  const map = new Map();
  rows.forEach((f) => {
    const k = famKey(f);
    if (!map.has(k)) map.set(k, { label: famLabel(f), items: [] });
    map.get(k).items.push(f);
  });
  return [...map.entries()]
    .map(([key, g]) => ({
      key,
      label: g.label,
      fams: new Set(g.items.map((f) => f.family || f.stem || '')).size,
      items: g.items.slice().sort((a, b) => (a.name || '').localeCompare(b.name || '')),
    }))
    .sort((a, b) => a.key.localeCompare(b.key, 'zh'));
}

function shortName(f) {
  const full = f.stem || f.name || f.value || '';
  const fam = f.family || '';
  if (fam && full.toLowerCase().startsWith(fam.toLowerCase())) {
    const rest = full.slice(fam.length).replace(/^[_\-\s]+/, '');
    if (rest) return rest;
  }
  return full || fam;
}

function updateSelHint() {
  $('selHint').textContent = state.sel.size ? `已勾选 ${state.sel.size} 个` : '未勾选';
}

/* 勾选 ≡ 当前选择字体：已在 work 里的字体在字库池里必须保持勾选 */
function syncSelFromWork() {
  state.work.forEach((v) => state.sel.add(v));
}

/* 整体替换 / 清空「当前选择字体」后，勾选必须严格等于新的 work，
   否则字库池会残留已不属于当前选择的「幽灵勾选」。 */
function resetSelToWork() {
  state.sel = new Set(state.work);
}

/* 手动加入权限最高：
   1) 任何自动同步（按 tag / 切行 / 换策略 / 启动填充）都先算 tag 结果，再叠加手动字体；
   2) 手动字体置顶并优先占位；没有数量上限，不挤掉任何自动字体；
   3) 因此与智能tag 无关的字体也能稳定留在「当前选择字体」里并参与出图。 */
function applyAutoWork(vals, silent, persist, label) {
  const ok = (v) => !!v && (!state.poolIndex || state.poolIndex.has(v));
  const pinned = [...state.manual].filter(ok);
  const seen = new Set(pinned);
  const rest = [];
  (vals || []).forEach((v) => {
    if (!ok(v) || seen.has(v)) return;
    seen.add(v);
    rest.push(v);
  });
  state.work = [...pinned, ...rest];
  state.manual = new Set(pinned);        // 收敛：被白名单挤掉的不留幽灵
  resetSelToWork();
  renderWork(); renderPool(); jobHint();
  if (persist !== false) scheduleSave();
  if (!silent) {
    const tip = pinned.length ? ` · 保留 ${pinned.length} 个手动加入` : '';
    toast(`${label} ${state.work.length} 个字体${tip}`, 'ok');
  }
  return true;
}

function itemRow(f, fullName) {
  const picked = state.sel.has(f.value);
  const row = el('div', 'item' + (picked ? ' picked' : ''));
  const cb = document.createElement('input');
  cb.type = 'checkbox';
  cb.checked = picked;
  cb.addEventListener('change', () => {
    if (cb.checked) {
      state.sel.add(f.value);
    } else {
      state.sel.delete(f.value);
      // 取消已选字体的勾选 = 把它从「当前选择字体」里移除
      const i = state.work.indexOf(f.value);
      if (i >= 0) state.work.splice(i, 1);
      state.manual.delete(f.value);
      state.bad.delete(f.value);
    }
    row.classList.toggle('picked', cb.checked);
    // 单个子项变化时同步所属家族的「全选 / 半选」复选框
    const fam = row.closest('.fam');
    if (fam) {
      const head = fam.querySelector('.fam-head input');
      const boxes = [...fam.querySelectorAll('.fam-body .item input')];
      if (head && boxes.length) {
        const on = boxes.filter((b) => b.checked).length;
        head.checked = on === boxes.length;
        head.indeterminate = on > 0 && on < boxes.length;
      }
    }
    updateSelHint();
    renderWork();
    jobHint();
    scheduleSave();
  });
  row.appendChild(cb);
  const nm = el('span', 'nm', fullName ? (f.stem || f.name || f.value) : shortName(f));
  nm.title = (f.stem || f.name || f.value) + (f.size_mb ? ` · ${f.size_mb}M` : '');
  row.appendChild(nm);
  if (f.size_mb) row.appendChild(el('span', 'meta', f.size_mb + 'M'));
  if (state.work.includes(f.value)) row.appendChild(el('span', 'meta', '已选'));
  row.addEventListener('click', (ev) => {
    if (ev.target === cb) return;
    cb.checked = !cb.checked;
    cb.dispatchEvent(new Event('change'));
  });
  return row;
}

function famBlock(g, open) {
  const wrap = el('div', 'fam' + (open ? ' open' : ''));
  const head = el('div', 'fam-head');
  head.appendChild(el('span', 'caret', '▶'));

  const body = el('div', 'fam-body');
  // 合并了多个家族时，子项用完整文件名，避免「002F」这种重名看不出来源
  const merged = (g.fams || 1) > 1;
  const fill = () => {
    if (body.dataset.filled) return;
    body.dataset.filled = '1';
    const frag = document.createDocumentFragment();
    g.items.forEach((f) => frag.appendChild(itemRow(f, merged)));
    body.appendChild(frag);
  };
  if (open) fill();

  const cb = document.createElement('input');
  cb.type = 'checkbox';
  const selCount = g.items.filter((f) => state.sel.has(f.value)).length;
  cb.checked = selCount === g.items.length;
  cb.indeterminate = selCount > 0 && selCount < g.items.length;
  cb.addEventListener('click', (ev) => ev.stopPropagation());
  cb.addEventListener('change', () => {
    g.items.forEach((f) => {
      if (cb.checked) {
        state.sel.add(f.value);
      } else {
        state.sel.delete(f.value);
        const i = state.work.indexOf(f.value);
        if (i >= 0) state.work.splice(i, 1);
        state.manual.delete(f.value);
        state.bad.delete(f.value);
      }
    });
    body.querySelectorAll('.item').forEach((row) => {
      const box = row.querySelector('input');
      if (box) box.checked = cb.checked;
      row.classList.toggle('picked', cb.checked);
    });
    cb.indeterminate = false;
    updateSelHint();
    renderWork(); jobHint(); scheduleSave();
  });
  head.appendChild(cb);
  const nm = el('span', 'fam-nm', g.label || g.key);
  nm.title = merged ? `${g.label} · ${g.fams} 个家族合并，共 ${g.items.length} 个字体` : (g.label || g.key);
  head.appendChild(nm);
  head.appendChild(el('span', 'fam-n', '×' + g.items.length));

  head.addEventListener('click', () => {
    const willOpen = !wrap.classList.contains('open');
    if (willOpen) fill();
    wrap.classList.toggle('open', willOpen);
    if (willOpen) state.open.add(g.key); else state.open.delete(g.key);
    if (state.qOpen) {
      if (willOpen) state.qOpen.add(g.key); else state.qOpen.delete(g.key);
    }
  });

  wrap.appendChild(head);
  wrap.appendChild(body);
  return wrap;
}

function renderPool() {
  syncSelFromWork();
  const box = $('poolList');
  const q = ($('poolSearch').value || '').trim();
  const rows = filteredFonts();
  box.innerHTML = '';

  if (!rows.length) {
    box.appendChild(el('div', 'empty', q ? '没有匹配的字体' : '当前通道没有字体'));
    $('poolCount').textContent = '0';
    updateSelHint();
    return;
  }

  state.groups = buildGroups(rows);
  if (!q) state.qOpen = null;
  else if (!state.qOpen) state.qOpen = new Set(state.groups.map((g) => g.key));

  const frag = document.createDocumentFragment();
  state.groups.slice(0, FAM_RENDER_CAP).forEach((g) => {
    if (g.items.length === 1) {
      frag.appendChild(itemRow(g.items[0], true));
    } else {
      const openBySearch = !!q && !!state.qOpen && state.qOpen.has(g.key);
      frag.appendChild(famBlock(g, state.open.has(g.key) || openBySearch));
    }
  });
  box.appendChild(frag);

  if (state.groups.length > FAM_RENDER_CAP) {
    box.appendChild(el('div', 'empty', '仅显示前 ' + FAM_RENDER_CAP + ' 个组，可用搜索缩小范围'));
  }

  $('poolCount').textContent = `${state.groups.length} 组 · ${rows.length} 个`;
  updateSelHint();
}

function renderWork() {
  const box = $('wfList');
  box.innerHTML = '';
  state.work = state.work.filter((v, i, a) => a.indexOf(v) === i);
  syncSelFromWork();
  $('wfCount').textContent = state.work.length;
  if (!state.work.length) {
    box.appendChild(el('div', 'empty', '还没有选字体：左侧勾选后点「加入 →」'));
    return;
  }
  state.work.forEach((val, i) => {
    const f = state.poolIndex.get(val);
    const bad = state.bad.has(val);
    const row = el('div', 'item');
    const nm = el('span', 'nm', f ? (f.stem || f.name) : val);
    if (f) nm.title = f.value;
    else { nm.title = '不在当前通道字库内，切回原通道即可继续使用'; nm.style.opacity = .62; }
    row.appendChild(nm);
    if (state.manual.has(val)) {
      const pin = el('span', 'meta pin', '手动');
      pin.title = '字库池手动加入 · 权限最高：按 tag 同步 / 光标切行 / 换策略都不会移除';
      row.appendChild(pin);
    }
    if (bad) {
      row.appendChild(el('span', 'meta bad', '缺字/不可用'));
      const sw = el('span', 'swap', '换');
      sw.title = '按 tag + 白名单给这个字体找替换';
      sw.addEventListener('click', (ev) => {
        ev.stopPropagation();
        suggestReplacements([val]);
      });
      row.appendChild(sw);
    }
    else if (!f) row.appendChild(el('span', 'meta', '不在当前字库'));
    const x = el('span', 'x', '×');
    x.title = '移除';
    x.addEventListener('click', (ev) => {
      ev.stopPropagation();
      state.work.splice(i, 1);
      state.sel.delete(val);
      state.manual.delete(val);
      state.bad.delete(val);
      renderWork(); renderPool(); jobHint(); scheduleSave();
    });
    row.appendChild(x);
    box.appendChild(row);
  });
}

/* ------------------------------------------- 用量：剩余时间 / 可用次数 / 升级提醒 */

/* 平台下发的「周期标识」：优先 URL 查询参数（平台打开 Skill 时带上），
   其次本地缓存。Skill 只比较它是否变化，不感知支付动作、不判断租期到期。 */
function cycleMarker() {
  try {
    const p = new URLSearchParams(location.search);
    const q = p.get('cycle') || p.get('CycleEndTime') || p.get('cycle_end') || '';
    if (q) { localStorage.setItem('ugi_cycle', q); return q; }
  } catch (e) { /* location 不可用时忽略 */ }
  try { return localStorage.getItem('ugi_cycle') || ''; } catch (e) { return ''; }
}

function fmtTs(t) {
  const n = Number(t);
  if (!n || !isFinite(n)) return '—';
  const d = new Date(n * 1000);
  const p = (x) => String(x).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function applyUsage(u) {
  if (!u) return;
  state.usage = u;
  // 产品名：由服务端按 mtag 授权清单自动定档后下发，显示在 logo 右侧
  const brand = $('brandName');
  const pname = (u.tier && u.tier.display_name) || '';
  if (brand && pname) {
    brand.textContent = pname;
    const t = u.tier || {};
    brand.title = [
      t.position ? `${t.position} · ${u.tag || ''}` : (u.tag || ''),
      t.library ? `字库 ${t.library} 款` : '',
      (t.price === undefined || t.price === null) ? '' : `月费 ¥${t.price}`,
      t.unit_price ? `每款 ¥${t.unit_price}` : '',
      t.monthly_cap ? `月上限 ${t.monthly_cap} 张` : '',
    ].filter(Boolean).join(' · ');
    document.title = pname + ' · 标题字 text-mask';
  }
  const cap = Number(u.cap || 0);
  const used = Number(u.used || 0);
  const remain = Math.max(0, cap - used);
  const days = (u.days_left === undefined || u.days_left === null) ? '—' : u.days_left;
  const totalDays = Number(u.period_days || 30);
  const timePill = $('pillTime');
  if (timePill) {
    const src = u.days_left_source;
    const basis = src === 'cycle'
      ? '按平台下发的订阅周期结束时间计算'
      : (src === 'anchor'
        ? `按本周期首次使用起算 ${totalDays} 天倒计时（到期由平台处理，不影响出图）`
        : (src === 'expired'
          ? `${totalDays} 天周期已到期，等待平台下发新周期（不影响出图）`
          : `还没出过图，本周期按 ${totalDays} 天计，首次出图后开始倒计时`));
    timePill.textContent = `剩余时间：${days} / ${totalDays} 天`;
    const ends = u.period_end ? `\n本周期结束：${fmtTs(u.period_end)}` : '';
    timePill.title = `${basis}\n本周期首次：${fmtTs(u.first_ts)}\n最近出图：${fmtTs(u.last_active)}${ends}`;
  }
  const q = $('pillQuota');
  if (q) {
    q.textContent = `可用次数：${remain} / ${cap} 张`;
    q.className = 'pill ' + (u.over_limit ? 'bad' : (u.near_limit ? 'warn' : 'dim'));
  }
  const tip = $('upgradeTip');
  const txt = $('upgradeText');
  const lvl = u.level || (u.over_limit ? 'blocked' : (u.near_limit ? 'near' : 'ok'));
  const show = lvl === 'near' || lvl === 'over' || lvl === 'blocked';
  if (tip) tip.hidden = !show;
  if (show && txt) {
    const head = lvl === 'blocked' ? '额度已用尽'
      : (lvl === 'over' ? '已超月上限' : '接近月上限');
    const price = (u.tier && u.tier.price !== undefined) ? u.tier.price : '—';
    txt.innerHTML = `<b>${head}</b> · ${u.message || ''}`
      + `（${u.tag || ''} · 月费 ¥${price} · 已用 ${used}/${cap} 张）`;
  }
  const sync = u.sync || u.cycle_sync;
  if (sync && sync.changed) {
    toast(sync.reason === 'activated' ? '订阅已激活：用量计数器已重置'
                                      : '已检测到新订阅周期：用量计数器已重置', 'ok');
  }
}

async function pollUsage() {
  const m = cycleMarker();
  const d = await api('/api/usage' + (m ? '?cycle=' + encodeURIComponent(m) : ''));
  if (d && d.ok !== false) applyUsage(d);
}

/* ------------------------------------------- 白名单约束 + 默认当前文本行匹配 */

/* 过滤掉不在白名单（state.poolIndex）内的当前选择字体：不显示、不参与计算 */
function sanitizeWork() {
  if (!Array.isArray(state.work) || !state.poolIndex) return 0;
  const before = state.work.length;
  state.work = state.work.filter((v) => state.poolIndex.has(v));
  state.manual = new Set([...state.manual].filter((v) => state.poolIndex.has(v)));
  if (state.work.length !== before) resetSelToWork();
  return before - state.work.length;
}

/* 用「当前文本行」匹配到的字体填充当前选择字体（只保留白名单内） */
async function initWorkFromCurrentLine(silent, persist) {
  const line = (currentLine() || '').trim();
  let tags = line;
  if (line) {
    // 用当前文本行文本做智能 tag 识别，而不是沿用上次保存的 smart_tag
    const st = await api('/api/smart-tag', { text: line, topk: 6, follow: true });
    if (st && st.ok && st.smart_tag) tags = st.smart_tag;
  } else {
    tags = ($('smartTag').value || '').trim();
  }
  if (!tags || !String(tags).trim()) return false;
  const d = await api('/api/work-fonts', {
    tags: tags, specified_tag: $('specifiedTag').value.trim(),
    channel: state.channel, top_n: (state.cfg && state.cfg.tag_top_n) || 12,
  });
  if (!d.ok || !d.work_fonts || !d.work_fonts.length) {
    if (!silent) toast('没匹配到字体，换个 tag 试试', 'bad');
    return false;
  }
  // 先按当前文本行的 tag 出结果，再叠加手动加入的字体（手动权限最高）
  return applyAutoWork(d.work_fonts, silent, persist, '已按当前文本行同步');
}

/* 目录就绪后：刷新白名单字体 → 默认按当前文本行匹配填充 → 过滤非白名单 */
async function ensureDefaultWork() {
  if (state._workInited) return;
  state._workInited = true;
  await loadFonts();
  const auto = !(state.cfg && state.cfg.auto_work_fonts === false);
  // 默认：启动即用「当前文本行匹配字体」填充（auto_work_fonts 关闭时尊重已保存选择）
  if (auto && await initWorkFromCurrentLine(true, false)) return;
  sanitizeWork();
  renderWork(); jobHint();
}

/* ------------------------------------------------------------------ 智能 tag */

async function loadTagPresets() {
  const d = await api('/api/tag-presets');
  const box = $('tagPresets');
  box.innerHTML = '';
  if (!d.ok) return;
  (d.presets || []).forEach((p) => {
    const c = el('span', 'chip', p.name);
    c.title = p.hint || p.text;
    c.addEventListener('click', async () => {
      if (busyTag) return;
      busyTag = true;
      const r = await api('/api/smart-tag', { text: p.text, topk: 6, follow: true });
      busyTag = false;
      if (r.ok && r.smart_tag) {
        $('smartTag').value = r.smart_tag;
        toast('已识别：' + r.smart_tag, 'ok');
        scheduleSave();
      }
    });
    box.appendChild(c);
  });
}

async function autoTag() {
  const text = currentLine() || $('text').value;
  if (!text.trim()) { toast('先输入文本', 'bad'); return; }
  const r = await api('/api/smart-tag', { text: text, topk: 6, follow: true });
  if (!r.ok) { toast(r.error || '识别失败', 'bad'); return; }
  $('smartTag').value = r.smart_tag || '';
  tagSeq += 1;                 // 让在途的自动跟随结果失效，不用旧 tag 覆盖本次识别
  markTagLine();
  toast('智能tag：' + (r.smart_tag || '（空）'), 'ok');
  scheduleSave();
  if (state.mode === 'smart_tag' && state._workInited) await syncWorkByTag(true);
}

async function syncWorkByTag(silent) {
  const tags = $('smartTag').value.trim() || currentLine();
  const d = await api('/api/work-fonts', {
    tags: tags, specified_tag: $('specifiedTag').value.trim(),
    channel: state.channel, top_n: (state.cfg && state.cfg.tag_top_n) || 12,
  });
  if (!d.ok || !d.work_fonts || !d.work_fonts.length) {
    if (!silent) toast('没匹配到字体，换个 tag 试试', 'bad');
    return false;
  }
  // 只保留授权白名单 ∩ 云端可达的字体；先按 tag 出结果，再叠加手动加入的字体
  return applyAutoWork(d.work_fonts, silent, true, '已按 tag 同步');
}

/* --------------------------------------------- 缺字 / 不可用字体 → 替换建议（tag + 白名单） */

function fontLabel(v) {
  const f = state.poolIndex.get(v);
  return f ? (f.stem || f.name || v) : v;
}

/* 缺字 / 不可用字体定位：优先用后端结构化的 failed_fonts（准确的字体 value），
   老版本服务或异常路径再退回从 skipped / errors 文本里模糊推断。 */
function resolveBadValues(s) {
  const hit = [];
  (Array.isArray(s.failed_fonts) ? s.failed_fonts : []).forEach((v) => {
    if (state.work.includes(v)) { hit.push(v); return; }
    if (!v || String(v).length < 4) return;      // 过短片段不做模糊匹配，避免误伤
    const near = state.work.find((w) => w === v || w.endsWith(v) || v.endsWith(w)
      || (v.length >= 8 && (w.includes(v) || v.includes(w))));
    if (near && !hit.includes(near)) hit.push(near);
  });
  if (hit.length) return hit;
  return resolveBadFromText(s.skipped, s.errors);
}

/* skipped / errors 里可能是字体名、文件名或 value，尽量映射回 work 的 value */
function resolveBadFromText(skipped, errors) {
  const raw = [...(skipped || []), ...(errors || [])]
    .map((x) => String(x || '').trim()).filter(Boolean);
  const found = new Set();
  raw.forEach((s) => {
    if (state.work.includes(s)) { found.add(s); return; }
    if (s.length < 3) return;               // 过短的片段不做模糊匹配，避免误伤
    state.work.forEach((v) => {
      const label = fontLabel(v);
      if (s.includes(v) || v.includes(s) || s.includes(label) || label.includes(s)) found.add(v);
    });
  });
  return [...found];
}

function hideReplaceTip() {
  $('replaceTip').hidden = true;
  state.replaceBad = [];
  state.replacePool = [];
}

/* 用「智能 tag + 指定 tag」向 /api/work-fonts 取排序结果，再按白名单池过滤 */
async function suggestReplacements(badVals) {
  const bad = (badVals || []).filter((v) => state.work.includes(v));
  state.replaceBad = bad;
  const tip = $('replaceTip');
  const list = $('replaceList');
  tip.hidden = false;
  $('replaceTitle').textContent = bad.length
    ? `${bad.length} 个字体缺字 / 不可用 → 替换建议`
    : '生成未全部成功 → 按 tag 推荐可替换字体';
  $('btnReplaceAll').hidden = !bad.length;
  list.innerHTML = '<span class="rt-empty">正在按 tag + 白名单匹配…</span>';

  const tags = ($('smartTag').value || '').trim() || (currentLine() || '').trim();
  const d = await api('/api/work-fonts', {
    tags: tags,
    specified_tag: $('specifiedTag').value.trim(),
    channel: state.channel,
    top_n: 24,
  });
  const rows = d.records || [];
  const byValue = new Map(rows.map((r) => [String(r.value || ''), r]));
  const vals = d.work_fonts || rows.map((r) => r.value);
  const taken = new Set([...state.replaceBad, ...state.work]);
  const cand = [];
  vals.forEach((v) => {
    // 只保留授权白名单（当前字库池）内、且未被选中 / 未出问题的字体
    if (!v || taken.has(v) || !state.poolIndex.has(v)) return;
    const rec = byValue.get(v) || {};
    cand.push({ value: v, label: fontLabel(v), tags: rec.tags || '' });
    taken.add(v);
  });
  state.replacePool = cand.slice(0, 8);

  list.innerHTML = '';
  if (!state.replacePool.length) {
    list.appendChild(el('span', 'rt-empty',
      '白名单内没有可替换的字体；试试改「智能 tag」或点「按 tag 同步」'));
    return;
  }
  state.replacePool.forEach((c) => {
    const chip = el('button', 'rt-chip', c.label);
    chip.title = `${c.value}` + (c.tags ? ` · tag: ${c.tags}` : '')
      + (bad.length ? `\n替换：${bad.map(fontLabel).join('、')}` : '\n点选加入当前选择字体');
    chip.addEventListener('click', () => applyReplacement([c.value]));
    list.appendChild(chip);
  });
}

/* 点选一个候选：有坏字体就等量替换一个，没有就直接加入 */
function applyReplacement(values) {
  const bad = state.replaceBad.slice(0, values.length);
  bad.forEach((v) => {
    state.work = state.work.filter((x) => x !== v);
    state.sel.delete(v);
    state.manual.delete(v);
    state.bad.delete(v);
  });
  values.forEach((v) => {
    if (!state.work.includes(v)) state.work.push(v);
    state.manual.add(v);          // 用户点选加入 = 手动加入，后续 tag 同步不覆盖
    state.sel.add(v);
  });
  // 与后端出图顺序一致：手动加入的字体置顶（无数量上限）
  const pins = state.work.filter((v) => state.manual.has(v));
  const autos = state.work.filter((v) => !state.manual.has(v));
  state.work = [...pins, ...autos];
  state.replaceBad = state.replaceBad.slice(values.length);
  if (!state.replaceBad.length) hideReplaceTip();
  else $('replaceTitle').textContent = `${state.replaceBad.length} 个字体缺字 / 不可用 → 替换建议`;
  renderWork(); renderPool(); jobHint(); scheduleSave();
  toast(bad.length ? `已替换 ${bad.length} 个字体` : '已加入当前选择字体', 'ok');
}

/* ------------------------------------------------------------------ 渲染 */

function jobHint() {
  const wf = state.work.length;
  const cur = (currentLine() || '').trim();
  const shots = expectedShots();
  const short = cur.length > 12 ? cur.slice(0, 12) + '…' : cur;
  const hint = !wf ? '还没选字体'
    : (cur ? `当前文本行「${short}」· ${MODE_LABEL[state.mode] || state.mode} → 预计 ${shots} 张`
           : '当前文本行为空');
  $('jobHint').textContent = hint;
  $('jobHint').title = hint + `（当前选择 ${wf} 个字体）`;
}

async function render() {
  if (state.running) { toast('任务进行中', 'bad'); return; }
  if (!state.work.length) { toast('先选字体并「加入 →」', 'bad'); return; }
  // 只出「当前文本行」× 字体策略给出的字体序列
  const cur = (currentLine() || '').trim();
  if (!cur) { toast('当前文本行为空：请在文本池里输入或选中一行', 'bad'); return; }
  if ([...cur].length > LINE_MAX) {
    toast(`当前文本行 ${[...cur].length} 字，超出单行 ${LINE_MAX} 字上限，请精简`, 'bad');
    return;
  }
  hideReplaceTip();
  const cfg = readForm();
  if (!await saveConfig(true)) return;
  state.results = [];
  $('results').innerHTML = '';
  $('logs').textContent = '';
  $('bar').style.width = '0%';
  $('stateText').textContent = '正在启动任务…';
  const d = await api('/api/render', { text: cur, options: cfg,
                                      render_matrix: true, cycle: cycleMarker() });
  if (!d.ok) {
    toast(d.error || '启动失败', 'bad');
    if (d.usage) applyUsage(d.usage);
    return;
  }
  if (d.usage) applyUsage(d.usage);
  if (d.cycle_sync && d.cycle_sync.changed) {
    toast(d.cycle_sync.reason === 'activated' ? '订阅已激活：用量已重置'
                                              : '已检测到新订阅周期：用量已重置', 'ok');
    pollUsage();
  }
  if (d.reminder) toast(d.reminder, (d.usage && d.usage.over_limit) ? 'bad' : 'ok');
  state.running = true;
  state.paused = false;
  state.stopping = false;
  state.startedAt = Date.now();
  setButtons();
  $('stateText').textContent = `运行中 · ${MODE_LABEL[state.mode] || state.mode} · 预计 ${d.total} 张`
    + (d.font_mode_note ? ` · ${d.font_mode_note}` : '');
  startPoll();
}

function setButtons() {
  // 已点「结束」后任务进入收尾：中断/继续立即失效并复位，不必等最后一张图跑完
  const live = state.running && !state.stopping;
  $('btnRender').disabled = state.running;
  $('btnPause').disabled = !live;
  $('btnStop').disabled = !live;
  $('btnPause').textContent = (live && state.paused) ? '继续' : '中断';
  $('btnPause').classList.toggle('on', live && state.paused);
  $('stateTag').textContent = !state.running ? '空闲'
    : (state.stopping ? '正在结束' : (state.paused ? '已中断' : '运行中'));
}

function startPoll() {
  clearTimeout(pollTimer);
  const tick = async () => {
    const s = await api('/api/state');
    if (!s.ok) { pollTimer = setTimeout(tick, 1200); return; }
    applyState(s);
    if (s.status === 'running') {
      pollTimer = setTimeout(tick, 550);
    } else {
      state.running = false;
      state.paused = false;
      state.stopping = false;
      setButtons();
      const bad = resolveBadValues(s);
      if (bad.length) { state.bad = new Set(bad); renderWork(); }
      if (bad.length || (s.errors || []).length) suggestReplacements(bad);
      else hideReplaceTip();
      // 服务端把用量快照随状态一起下发：结束的这一拍就能刷新次数/剩余时间，
      // 不用等下一次 /api/usage（否则会读到记账前的旧值）
      if (s.usage) applyUsage(s.usage);
      $('stateText').textContent = summaryText(s);
      const n = (s.results || []).length;
      const u = s.usage;
      const quota = u ? ` · 本月已用 ${u.used || 0}/${u.cap || 0} 张` : '';
      if (s.status === 'stopped') toast(`已结束 · 已出 ${n} 张${quota}`, 'warn');
      else if (s.status === 'done') toast(`生成完成 ${n} 张${quota}`, 'ok');
      else if (s.status === 'error') toast(s.last_error || '任务出错', 'bad');
      if (!s.usage) pollUsage();
    }
  };
  tick();
}

function summaryText(s) {
  const label = { done: '完成', stopped: '已结束', error: '出错', idle: '空闲' }[s.status] || s.status;
  const skipped = s.skipped || [];
  const badCount = (s.failed_fonts || []).length || skipped.length;
  return `${label} · 成功 ${(s.results || []).length} 张`
    + ((s.errors || []).length ? ` · 失败 ${s.errors.length} 条` : '')
    + (badCount ? ` · ${badCount} 个字体缺字/不可用` : '')
    + (s.elapsed ? ` · ${s.elapsed}s` : '');
}

/* 刷新页面后把服务端上一次任务的结果接回来（正在跑就继续轮询） */
async function restoreState() {
  let s = null;
  try { s = await api('/api/state'); } catch (_) { return; }
  if (!s || !s.ok) return;
  if (s.status === 'running') {
    state.running = true;
    state.stopping = !!s.stopping;
    state.paused = !!s.paused;
    setButtons();
    applyState(s);
    startPoll();
    return;
  }
  if (!(s.results || []).length && !(s.logs || []).length) return;
  applyState(s);
  const bad = resolveBadValues(s);
  if (bad.length) { state.bad = new Set(bad); renderWork(); }
  $('stateText').textContent = summaryText(s);
  $('stateTag').textContent = { done: '完成', stopped: '已结束', error: '出错' }[s.status] || '空闲';
}

function applyState(s) {
  const pct = s.total ? Math.round((s.done / s.total) * 100) : 0;
  $('bar').style.width = pct + '%';
  if (s.status === 'running') {
    $('stateText').textContent = `${s.done} / ${s.total} · ${s.current || ''}`;
    state.paused = !!s.paused;
    // 本地已点「结束」时不再被在途的旧响应改回去，避免按钮闪一下又变回可用
    state.stopping = state.stopping || !!s.stopping;
    setButtons();
  }
  if (s.usage && s.usage.used !== undefined) applyUsage(s.usage);
  if (s.results) {
    const sig = (a) => a.length + ':' + (a[0] ? a[0].file : '') + ':' + (a.length ? a[a.length - 1].file : '');
    if (sig(s.results) !== sig(state.results)) {
      state.results = s.results;
      renderResults();
    }
  }
  if (s.logs && s.logs.length) {
    $('logs').textContent = s.logs.join('\n');
    $('logs').scrollTop = $('logs').scrollHeight;
  }
}

function renderResults() {
  const box = $('results');
  box.innerHTML = '';
  if (!state.results.length) {
    box.appendChild(el('div', 'empty', '生成后在这里预览'));
    return;
  }
  state.results.slice().reverse().forEach((r) => {
    const t = el('div', 'thumb');
    const img = document.createElement('img');
    img.loading = 'lazy';
    img.src = '/api/preview?file=' + encodeURIComponent(r.file) + '&t=' + (r.bytes || 0);
    img.alt = r.text || '';
    t.appendChild(img);
    t.appendChild(el('div', 'cap', `${r.width}×${r.height}`));
    t.title = `${r.text}\n${r.font}\n留边 ${r.mask_margin}px · 光学校正 ×${r.optical}`;
    t.addEventListener('click', () => openLightbox(r));
    box.appendChild(t);
  });
}

function openLightbox(r) {
  $('lbImg').src = '/api/preview?file=' + encodeURIComponent(r.file);
  $('lbInfo').textContent = `${r.text} · ${r.font} · ${r.width}×${r.height} · 留边 ${r.mask_margin}px`;
  $('lightbox').classList.add('on');
}

/* ------------------------------------------------------------------ 目录 / 探测 */

function renderDirState(dirs) {
  if (!dirs) return;
  const o = dirs.output_dir || {};
  const fmt = (d) => (d.exists ? (d.writable ? '可写' : '只读') : '不存在');
  $('dirState').textContent = `输出目录 ${fmt(o)}（字库池走 UGI-API 云通道）`;
}

async function probe() {
  $('probeInfo').textContent = '正在请求云接口…';
  $('probeInfo').style.color = '';
  const cfg = readForm();
  const d = await api('/api/probe', {
    endpoint: cfg.api.ugi_endpoint, key: cfg.api.ugi_key, size: cfg.font_size,
    timeout: cfg.api.ugi_timeout,
  });
  if (!d.ok) {
    $('probeInfo').textContent = '失败：' + (d.error || '未知错误');
    $('probeInfo').style.color = 'var(--bad)';
    return;
  }
  $('probeInfo').textContent = `正常 · ${d.font} · ${d.width}×${d.height}`;
  toast('云接口可用', 'ok');
}

/* ------------------------------------------------------------------ 事件绑定 */

/* 演示站 / 标准参考站：输入框改了就同步到右侧「打开」热链接 */
function syncStandardLink() {
  const a = $('linkStandard');
  if (!a) return;
  const url = ($('apiStandard').value || '').trim() || 'https://ugi.z-w.vip/';
  a.href = url;
  a.title = url;
}

/* 只是「卡片默认显示 15 行」的量高基准，不是字体数量上限：
   选中的字体多于 15 个时全部保留并出图，列表内部滚动即可。 */
const WF_DISPLAY_ROWS = 15;

function fitBand(force) {
  const band = $('listBand');
  const card = document.querySelector('.workgrid .wf');
  const list = $('wfList');
  if (!band || !card || !list) return;
  const probe = el('div', 'item', '字');
  probe.style.cssText = 'position:absolute;left:-9999px;top:0;visibility:hidden';
  list.appendChild(probe);
  const rowH = probe.getBoundingClientRect().height || 19;
  probe.remove();
  const chrome = Math.max(0, card.getBoundingClientRect().height - list.getBoundingClientRect().height);
  let saved = 0;
  try { saved = Number(localStorage.getItem('ugi.bandH2')) || 0; } catch (_) { saved = 0; }
  const manual = saved >= 220 && !force;
  // 默认按 15 行量高（仅显示）；窗口装不下时按 86vh 收敛（最少 6 行）；人手调过就沿用记录的高度
  const room = Math.floor((window.innerHeight * 0.86 - chrome) / (rowH || 30));
  const rows = Math.max(6, Math.min(WF_DISPLAY_ROWS, room > 0 ? room : WF_DISPLAY_ROWS));
  band.style.height = Math.round(manual ? saved : chrome + rowH * rows + 2) + 'px';
}

/* 等高带拖拽手柄 */
/* 顶栏高度 → CSS 变量，让主 tab 条精确吸顶在顶栏下方（顶栏换行时也同步） */
function syncTopHeight() {
  const top = document.querySelector('.top');
  if (!top) return;
  document.documentElement.style.setProperty('--topH',
    Math.round(top.getBoundingClientRect().height) + 'px');
}

function bindBandSplit() {
  const band = $('listBand');
  const split = $('bandSplit');
  let saved = 0;
  try { saved = Number(localStorage.getItem('ugi.bandH2')) || 0; } catch (_) { saved = 0; }
  if (saved >= 220) band.style.height = saved + 'px';

  split.addEventListener('pointerdown', (ev) => {
    ev.preventDefault();
    split.setPointerCapture(ev.pointerId);
    split.classList.add('dragging');
    const startY = ev.clientY;
    const startH = band.getBoundingClientRect().height;
    const maxH = Math.round(window.innerHeight * 0.78);
    $('wfList').style.minHeight = '0px';

    const onMove = (e) => {
      const h = Math.min(maxH, Math.max(200, startH + e.clientY - startY));
      band.style.height = h + 'px';
    };
    const onUp = () => {
      split.classList.remove('dragging');
      split.removeEventListener('pointermove', onMove);
      split.removeEventListener('pointerup', onUp);
      split.removeEventListener('pointercancel', onUp);
      try {
        localStorage.setItem('ugi.bandH2', String(Math.round(band.getBoundingClientRect().height)));
      } catch (_) { /* 隐私模式忽略 */ }
    };
    split.addEventListener('pointermove', onMove);
    split.addEventListener('pointerup', onUp);
    split.addEventListener('pointercancel', onUp);
  });
}

function bind() {
  // 主 page
  $('mainNav').addEventListener('click', (ev) => {
    const b = ev.target.closest('button[data-page]');
    if (b) showPage(b.dataset.page);
  });
  window.addEventListener('hashchange', () => showPage(location.hash.replace('#', '')));

  bindBandSplit();

  // v2 新架构：字库池恒为「字库池」（mtag 授权 ∩ 云端可达），
  // 不再有本地 / 云 API 切换；下方通道切换逻辑已移除。

  // 字体策略：切换后立刻在提示与预计张数上可见，并由后端决定本次字体序列
  $('fontModeSeg').addEventListener('click', async (ev) => {
    const b = ev.target.closest('button[data-mode]');
    if (!b || b.dataset.mode === state.mode) return;
    state.mode = b.dataset.mode;
    setSeg($('fontModeSeg'), state.mode);
    $('fontModeLabel').textContent = MODE_LABEL[state.mode] || b.textContent;
    $('modeHint').textContent = MODE_HINT[state.mode] || '';
    jobHint();
    scheduleSave();
    toast(`字体策略：${MODE_LABEL[state.mode] || state.mode} · 预计 ${expectedShots()} 张`, 'ok');
    // 智能tag：切进来就按当前文本行的 tag 重新挑字，让策略立刻起作用
    if (state.mode === 'smart_tag' && state._workInited) {
      await syncWorkByTag(true);
      jobHint();
    }
  });

  // 设置 Tab
  $('setTabs').addEventListener('click', (ev) => {
    const b = ev.target.closest('button[data-tab]');
    if (!b) return;
    $('setTabs').querySelectorAll('.tab').forEach((t) => t.classList.toggle('on', t === b));
    ['param', 'api'].forEach((k) => {
      $('pane' + k.charAt(0).toUpperCase() + k.slice(1)).classList.toggle('on', k === b.dataset.tab);
    });
  });

  // 文本
  const ta = $('text');
  ta.addEventListener('input', () => { updateLineInfo(); jobHint(); scheduleSave(); });
  ta.addEventListener('keyup', () => { updateLineInfo(); jobHint(); });
  ta.addEventListener('click', () => { updateLineInfo(); jobHint(); });

  const cur = $('curLine');
  cur.addEventListener('input', () => {
    setLineAt(state.curIdx, cur.value);
    const arr = ($('text').value || '').split('\n');
    const n = arr.filter((l) => l.trim()).length;
    $('lineCount').textContent = n ? `第 ${state.curIdx + 1} / ${arr.length} 行` : '空';
    updateLenInfo();
    followCurrentLine();
    jobHint(); scheduleSave();
  });
  cur.addEventListener('focus', () => {
    const ta2 = $('text');
    const arr = (ta2.value || '').split('\n');
    const before = arr.slice(0, state.curIdx).join('\n').length + (state.curIdx ? 1 : 0);
    ta2.selectionStart = ta2.selectionEnd = before + (arr[state.curIdx] || '').length;
  });

  // 字库池
  $('poolSearch').addEventListener('input', () => {
    state.qOpen = null;            // 搜索词变了，命中组重新自动展开
    renderPool();
  });
  $('btnExpandAll').addEventListener('click', () => {
    state.groups.forEach((g) => state.open.add(g.key));
    if (state.qOpen) state.qOpen = new Set(state.groups.map((g) => g.key));
    renderPool();
  });
  $('btnCollapseAll').addEventListener('click', () => {
    state.open.clear();
    if (state.qOpen) state.qOpen.clear();
    renderPool();
  });
  $('btnClearSel').addEventListener('click', () => {
    state.sel.clear();
    state.work = [];
    state.manual.clear();
    state.bad.clear();
    renderWork(); renderPool(); jobHint(); scheduleSave();
    toast('已取消全部勾选', 'ok');
  });
  $('btnReloadFonts').addEventListener('click', reloadFonts);
  $('btnSelectAll').addEventListener('click', () => {
    filteredFonts().forEach((f) => state.sel.add(f.value));
    renderPool();
    toast(`已勾选 ${filteredFonts().length} 个，点「加入 →」生效（无数量上限）`, 'ok');
  });
  $('btnAddWork').addEventListener('click', () => {
    if (!state.sel.size) { toast('先勾选字体', 'bad'); return; }
    const want = [...state.sel].filter((v) => !state.work.includes(v));
    if (!want.length) { toast('勾选的字体都已在当前选择里', 'ok'); return; }
    // 手动加入权限最高：不设数量上限，不挤掉任何已有字体（含 tag 自动挑的），
    // 因此与智能tag 无关的字体也加得进来，且后续自动同步不会移除。
    want.forEach((v) => {
      state.work.push(v);
      state.manual.add(v);          // 字库池手动加入：权限最高
    });
    // 与后端出图顺序一致：手动加入的字体立即置顶
    const pins = state.work.filter((v) => state.manual.has(v));
    const autos = state.work.filter((v) => !state.manual.has(v));
    state.work = [...pins, ...autos];
    // 加入后不清除勾选：已选择的字体在字库池里始终保持勾选
    renderWork(); renderPool(); jobHint(); scheduleSave();
    toast(`已手动加入 ${want.length} 个字体 · 置顶必出、不会被 tag 同步覆盖`, 'ok');
  });
  $('btnSyncTag').addEventListener('click', () => syncWorkByTag(false));
  $('btnClearWork').addEventListener('click', () => {
    state.work = [];
    state.sel.clear();
    state.manual.clear();
    state.bad.clear();
    renderWork(); renderPool(); jobHint(); scheduleSave();
  });

  // 智能 tag
  $('btnAutoTag').addEventListener('click', autoTag);
  $('smartTag').addEventListener('input', scheduleSave);
  $('specifiedTag').addEventListener('input', scheduleSave);

  // 参数变更 → 自动保存 + 估算
  ['fontSize', 'maskMargin', 'charGap', 'opticalFit', 'apiPort', 'apiTimeout',
    'apiFg', 'apiBg', 'apiOutput', 'apiEndpoint', 'apiListfonts', 'apiStandard',
    'apiKey', 'autoFetchCloud', 'outputDir'].forEach((id) => {
    const n = $(id);
    if (!n) return;
    n.addEventListener('change', () => {
      if (id === 'apiStandard') syncStandardLink();
      jobHint(); scheduleSave();
    });
  });

  // 操作
  $('btnSave').addEventListener('click', () => saveConfig(false));
  $('btnReplaceAll').addEventListener('click', () => {
    const picks = state.replacePool.slice(0, state.replaceBad.length).map((c) => c.value);
    if (!picks.length) { toast('没有可用的替换字体', 'bad'); return; }
    applyReplacement(picks);
  });
  $('btnReplaceClose').addEventListener('click', hideReplaceTip);
  $('btnRender').addEventListener('click', render);
  $('btnPause').addEventListener('click', async () => {
    if (state.stopping) return;
    const d = await api('/api/pause', { paused: !state.paused });
    if (d.ok) { state.paused = d.paused; setButtons(); }
    else toast(d.error || '操作失败', 'bad');
  });
  $('btnStop').addEventListener('click', async () => {
    if (!state.running || state.stopping) return;
    // 立刻复位：中断按钮回到「中断」并禁用、结束按钮禁用，不等服务端把
    // 最后一张图跑完（云端慢字体可能要几秒，否则看起来像按钮卡住）
    state.stopping = true;
    state.paused = false;
    setButtons();
    $('stateText').textContent = '正在结束…（已出图会保留并计入本月次数）';
    const d = await api('/api/stop');
    if (d && d.usage) applyUsage(d.usage);
    if (!d || !d.ok) {
      state.stopping = false;
      setButtons();
      toast((d && d.error) || '结束请求失败', 'bad');
      return;
    }
    if (!d.stopping) {          // 服务端本来就没在跑：直接收尾
      state.running = false;
      state.stopping = false;
      setButtons();
    }
    toast('已请求结束', 'warn');
    // 兜底：服务端迟迟不确认（卡在一次云端请求里）时把界面复位，允许重新生成
    const t0 = Date.now();
    const wait = setInterval(async () => {
      if (!state.stopping) { clearInterval(wait); return; }
      if (Date.now() - t0 < 15000) return;
      clearInterval(wait);
      state.running = false;
      state.paused = false;
      state.stopping = false;
      setButtons();
      $('stateText').textContent = '已请求结束（服务端仍在收尾）';
      toast('服务端仍在收尾，界面已复位；稍后可再次生成', 'bad');
    }, 700);
  });

  // 目录 / 探测
  $('btnOpenOut').addEventListener('click', () => api('/api/open-folder?which=output'));
  $('btnOpenOut2').addEventListener('click', () => api('/api/open-folder?which=output'));
  $('btnProbe').addEventListener('click', probe);

  const up = $('btnUpgrade');
  if (up) up.addEventListener('click', () => {
    const url = (state.cfg && state.cfg.api && state.cfg.api.ugi_standard_url) || 'https://ugi.z-w.vip/';
    window.open(url, '_blank');
  });

  // 大图
  $('lightbox').addEventListener('click', () => $('lightbox').classList.remove('on'));
  document.addEventListener('keydown', (ev) => {
    if (ev.key === 'Escape') $('lightbox').classList.remove('on');
  });
}

/* ------------------------------------------------------------------ 启动 */

async function loadConfig() {
  const d = await api('/api/config');
  if (!d.ok) { toast(d.error || '配置读取失败', 'bad'); return; }
  state.cfg = d.config;
  fillForm(d.config);
  renderWork();
  renderDirState(d.dirs);
  applyUsage(d.usage);   // 顶栏不再显示授权 pill：logo 旁留空
}

async function pollCatalog(tries) {
  const n = tries === undefined ? 30 : tries;
    const d = await api('/api/catalog-status');
  if (d && d.ok) {
    const wl = d.whitelist_reachable || 0;
    $('pillFonts').textContent = `可用字体总数：${wl}。`;
    if (d.ready) { await ensureDefaultWork(); return; }
  }
  if (n > 1) setTimeout(() => pollCatalog(n - 1), 1000);
  else await ensureDefaultWork();   // 离线兜底：即使目录未就绪也初始化默认选择
}

async function boot() {
  bind();
  syncTopHeight();
  const topEl = document.querySelector('.top');
  if (topEl && window.ResizeObserver) {
    new ResizeObserver(syncTopHeight).observe(topEl);
  }
  showPage(location.hash.replace('#', ''));
  renderResults();
  await loadConfig();
  await loadFonts();
  refreshTagForCurrentLine();   // 启动即让智能 tag 与「当前文本行」一致
  requestAnimationFrame(() => fitBand());
  window.addEventListener('resize', () => {
    clearTimeout(fitBand._t);
    fitBand._t = setTimeout(() => fitBand(false), 160);
  });
  await loadTagPresets();
  await restoreState();
  pollCatalog();
  pollUsage();
  setInterval(pollUsage, 60000);
}

document.addEventListener('DOMContentLoaded', boot);
