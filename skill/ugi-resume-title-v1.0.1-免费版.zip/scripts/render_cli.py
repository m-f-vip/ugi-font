#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UGI Font 命令行入口（无需启动服务）。

示例::

  python scripts/render_cli.py --list-fonts
  python scripts/render_cli.py --text "会挣钱的智能体" --json
  python scripts/render_cli.py --text "富贵吉祥" --split-mode char --margin 3
  python scripts/render_cli.py --text "元字库" --channel cloud --probe
  python scripts/render_cli.py --font-spec --json
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import catalog  # noqa: E402
import font_spec  # noqa: E402
import render_engine  # noqa: E402
import truetype_api  # noqa: E402
import usage  # noqa: E402
from smart_tag import tags_for_text  # noqa: E402
from tag_pools import pools_from_config  # noqa: E402
from ugi_core import (  # noqa: E402
    DEFAULT_CONFIG_PATH, FONT_MODES, SPLIT_MODES, build_render_jobs, effective_key,
    inspect_png, list_fonts, load_config, parse_text, resolve_output_modes,
)


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="UGI Font 命令行渲染器（只输出 text-mask）")
    ap.add_argument("--config", default=str(DEFAULT_CONFIG_PATH))
    ap.add_argument("--text", default=None, help="每行 × 每个 work-font 各出一张；行内 \\n 换行")
    ap.add_argument("--in-file", default=None, help="从 .txt 读取文本")
    ap.add_argument("--channel", choices=("cloud",), help="字库与渲染固定走云通道")
    ap.add_argument("--mode", choices=FONT_MODES, dest="font_mode",
                    help="字体策略，默认 smart_tag（智能tag：先分词再按 tag 选字）")
    ap.add_argument("--split-mode", choices=SPLIT_MODES, dest="split_mode",
                    help="只输出指定的一种方式：multi 多行 / single 单行 / char 单字")
    ap.add_argument("--smart-tag", default=None)
    ap.add_argument("--specified-tag", default=None)
    ap.add_argument("--specified-fonts", default=None, help="逗号分隔")
    ap.add_argument("--work-fonts", default=None, help="当前选择字体，逗号分隔（优先参与渲染）")
    ap.add_argument("--tag-top-n", type=int)
    ap.add_argument("--size", type=int, help="基准字号")
    ap.add_argument("--margin", type=int, help="裁边后四周留边 px（默认 3）")
    ap.add_argument("--no-optical", action="store_true", help="关闭光学校正")
    ap.add_argument("--no-matrix", action="store_true", help="只按字体策略出一张，不遍历 work-fonts")
    ap.add_argument("--out", default=None, help="输出目录")
    ap.add_argument("--key", default=None, help="UGI-API Key（覆盖配置）")
    ap.add_argument("--endpoint", default=None)
    ap.add_argument("--timeout", type=float)
    ap.add_argument("--font", action="append", default=[], help="指定字体，可重复")
    ap.add_argument("--list-fonts", action="store_true")
    ap.add_argument("--catalog", action="store_true", help="强制刷新云端字库清单")
    ap.add_argument("--tag-match", default=None, help="测试 tag 匹配，逗号分隔")
    ap.add_argument("--tag-stats", action="store_true")
    ap.add_argument("--font-spec", action="store_true", help="查看字体基准（国字留边 / 光学校正）")
    ap.add_argument("--rebuild", action="store_true", help="配合 --font-spec：重建本机字体基准（云通道下按需自动生成）")
    ap.add_argument("--probe", action="store_true", help="测试云接口（不写文件）")
    ap.add_argument("--inspect", default=None, help="校验一张 PNG 的 alpha / 墨迹 / 留边")
    ap.add_argument("--dry-run", action="store_true", help="只算张数，不渲染")
    ap.add_argument("--no-count", action="store_true",
                    help="不计入本月次数（仅本机预览/自检用；默认按出图张数计次）")
    ap.add_argument("--json", action="store_true")
    return ap


def emit(obj, as_json: bool, human: str = "") -> None:
    if as_json:
        print(json.dumps(obj, ensure_ascii=False, indent=2))
    elif human:
        print(human)


def main() -> int:
    ap = build_parser()
    args = ap.parse_args()
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, OSError):
        pass
    cfg = load_config(args.config)

    # ---- 信息类命令 ------------------------------------------------------
    if args.font_spec:
        paths = ([f["path"] for f in list_fonts(cfg["font_dir"], cfg.get("recursive_fonts", True))]
                 if args.rebuild else None)
        if args.rebuild and not paths:
            print("未配置本机字体文件，--rebuild 已跳过；云通道下基准按需自动生成。")
        created = font_spec.ensure(paths, int(cfg.get("font_index", 0))) if paths else []
        stats = font_spec.stats()
        rows = font_spec.rows(paths, int(cfg.get("font_index", 0)))
        emit({"ok": True, **stats, "created": len(created), "rows": rows}, args.json,
             f"基准文件 {stats['path']} · {stats['fonts']} 个字体 / {stats['usable']} 个可用"
             + (f" · 新建 {len(created)}" if created else ""))
        if not args.json:
            for r in rows[:40]:
                s = r.get("side") or {}
                print(f"  {r.get('file')}  字面率 {r.get('face')}  留边 "
                      f"左{s.get('l')} 上{s.get('t')} 右{s.get('r')} 下{s.get('b')}  "
                      f"校正 ×{r.get('optical')}")
        return 0
    if args.tag_stats:
        s = pools_from_config(cfg).stats()
        emit(s, args.json, f"tag-pools: {s.get('fonts')} 字体 / {s.get('unique_tags')} 标签 / "
                           f"{s.get('aliases')} 场景别名词")
        return 0
    if args.tag_match is not None:
        pools = pools_from_config(cfg)
        m = pools.match(args.tag_match, top_n=args.tag_top_n or int(cfg.get("tag_top_n") or 12))
        m["expanded"] = {t: pools.expand_alias(t) for t in args.tag_match.split(",") if t.strip()}
        emit(m, args.json, "匹配字体：" + ", ".join(m["fonts"][:12])
             + f"\n候选 {m['candidates']} · 未命中 {m['unmatched_tags']}")
        return 0
    if args.inspect:
        emit(inspect_png(args.inspect), args.json)
        return 0
    if args.catalog or args.list_fonts:
        cat = catalog.prepare_catalog(cfg, force=True, allow_cloud=bool(args.catalog))
        rows = cat.get("merged") or []
        if args.list_fonts:
            out = [{"value": r["value"], "group": r["group"], "source": r["source"]} for r in rows]
            emit({"ok": True, "count": len(rows), "fonts": out}, args.json,
                 f"共 {len(rows)} 个字体（云 {len([r for r in rows if r['source'] == 'cloud'])}"
                 f" / 本地 {len([r for r in rows if r['source'] == 'local'])}）")
        else:
            emit(cat, args.json, "字库已刷新：" + "；".join(cat.get("notes", [])))
        return 0

    # ---- 覆盖配置 --------------------------------------------------------
    if args.channel: cfg["channel"] = args.channel
    if args.font_mode: cfg["font_mode"] = args.font_mode
    if args.split_mode: cfg["output_modes"] = [args.split_mode]
    if args.smart_tag is not None: cfg["smart_tag"] = args.smart_tag
    if args.specified_tag is not None: cfg["specified_tag"] = args.specified_tag
    if args.specified_fonts is not None:
        cfg["specified_fonts"] = [x.strip() for x in args.specified_fonts.split(",") if x.strip()]
    if args.work_fonts is not None:
        cfg["work_fonts"] = [x.strip() for x in args.work_fonts.split(",") if x.strip()]
        cfg["selected_fonts"] = list(cfg["work_fonts"])
    if args.font:
        cfg["specified_fonts"] = list(dict.fromkeys(list(cfg["specified_fonts"]) + args.font))
    if args.tag_top_n: cfg["tag_top_n"] = args.tag_top_n
    if args.size: cfg["font_size"] = args.size
    if args.margin is not None: cfg["mask_margin"] = max(0, int(args.margin))
    if args.no_optical: cfg["optical_fit"] = False
    cfg["render_matrix"] = not args.no_matrix
    if args.out: cfg["output_dir"] = args.out
    if args.key: cfg["api"]["ugi_key"] = args.key
    if args.endpoint: cfg["api"]["ugi_endpoint"] = args.endpoint
    if args.timeout: cfg["api"]["ugi_timeout"] = args.timeout

    text = args.text
    if args.in_file:
        raw = Path(args.in_file).read_bytes()
        for enc in ("utf-8-sig", "utf-8", "gbk"):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
    if text is None:
        text = str(cfg.get("text") or "")

    if args.probe:
        ep = cfg["api"].get("ugi_endpoint") or truetype_api.DEFAULT_ENDPOINT
        fonts = catalog.prepare_catalog(cfg, allow_cloud=False).get("merged") or []
        cloud = [r["value"] for r in fonts if r.get("source") == "cloud"]
        raw, info = truetype_api.render_one(
            ep, parse_text(text)[0][0] if parse_text(text) else "元字库",
            cloud[0] if cloud else truetype_api.DEFAULT_FONT,
            size=int(cfg.get("font_size") or 160),
            key=effective_key(cfg),
            timeout=float(cfg["api"].get("ugi_timeout") or 40))
        mask, spec = truetype_api.to_white_mask(raw)
        emit({"ok": True, **spec, "info": info, "bytes": len(mask)}, args.json,
             f"云接口正常：{spec['width']}×{spec['height']} · 32位RGBA · d=ltr")
        return 0

    # 与 batch_render / server /api/render 共用同一套按组展开，张数永远一致
    jobs = build_render_jobs(text, cfg)
    if not jobs:
        ap.error("文本框为空：请至少输入一行文字")
    if args.dry_run:
        emit({"ok": True, "total": len(jobs), "groups": len({j["group"] for j in jobs}),
              "output_modes": resolve_output_modes(cfg), "mode": cfg["font_mode"],
              "channel": cfg["channel"], "mask_margin": cfg["mask_margin"],
              "matrix": cfg["render_matrix"]}, args.json,
             f"预览：{len(jobs)} 个输出单元 · {cfg['font_mode']}"
             f" · 输出方式 {' / '.join(resolve_output_modes(cfg))}"
             f" · 留边 {cfg['mask_margin']}px")
        return 0

    result = render_engine.batch_render(
        text, cfg, cfg["output_dir"],
        logger=None if args.json else (lambda m: print(m, file=sys.stderr)))
    # 次数与时间同源：只写 assets/zwcnt.pkl；--no-count 时只读取快照
    tag = usage.default_tag_from_config(cfg)
    try:
        quota = (usage.status(tag) if args.no_count
                 else usage.record(tag, int(result.get("success") or 0)))
    except Exception:  # noqa: BLE001 - 计数失败不影响已出的图
        quota = None
    if args.json:
        emit({**result, "usage": quota}, True)
    else:
        print(f"完成：成功 {result['success']} 张 / 失败 {result['failed']} 条 · "
              f"用时 {result['elapsed']}s → {result['output_dir']}")
        if quota:
            print(f"本月已用 {quota.get('used', 0)}/{quota.get('cap', 0)} 张 · "
                  f"剩余 {quota.get('remaining', 0)} 张 · "
                  f"剩余时间 {quota.get('days_left', '—')} 天")
        for r in result["results"][:20]:
            print(f"  {r['index']:03d}  {r['font']}  {r['text']}  → {r['file']}")
        for e in result["errors"][:10]:
            print("  ! " + e)
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
