#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UGI Font — 配置、授权 Key、字体发现、文本拆组与 32 位透明 text-mask 渲染。

只依赖 Pillow。命令行与服务端共用这一个模块；本技能的唯一产物就是 text-mask。
"""
from __future__ import annotations

import json
import math
import os
import random
import re
import sys
from datetime import datetime
from functools import lru_cache
from pathlib import Path

try:
    from PIL import Image, ImageDraw, ImageFont
    PILLOW_OK = True
    PILLOW_ERROR = ""
except ImportError as exc:  # 保持可导入，check_env.py 才能提示并修复
    Image = ImageDraw = ImageFont = None  # type: ignore[assignment]
    PILLOW_OK = False
    PILLOW_ERROR = str(exc)

PILLOW_HINT = "缺少 Pillow 图像库。请运行: python -m pip install pillow 或 python scripts/check_env.py --install"

SKILL_DIR = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = SKILL_DIR / "config.json"
ASSETS_DIR = SKILL_DIR / "assets"
FONT_EXTS = {".ttf", ".otf", ".ttc"}

BUILTIN_KEY = "ugi-free-2026-12-12"


def load_hot_lines() -> list[str]:
    """内置语句池，启动时默认全部载入文本框。"""
    p = ASSETS_DIR / "hot_lines.json"
    try:
        with p.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        lines = [str(x).strip() for x in (data.get("lines") or []) if str(x).strip()]
        if lines:
            return lines
    except (OSError, ValueError, AttributeError):
        pass
    return ["有人真心喜欢，就有人真心不喜欢", "UGI", "会挣钱的AGI"]


DEFAULT_CONFIG: dict = {
    "edition": "ugi-font1700",
    "product_tag": "ugi-font1700",      # 六档 SKU 标识；实际档位由 mtag 清单自动推断（见 usage.infer_tier）
    "api": {
        "host": "127.0.0.1",
        "port": 8766,
        "base": "/api",
        "ugi_endpoint": "https://ugiapi.z-w.vip/api/truetype",
        "ugi_listfonts": "https://ugiapi.z-w.vip/api/listfonts",
        "ugi_standard_url": "https://ugi.z-w.vip/",
        "ugi_key": BUILTIN_KEY,
        "ugi_fg": "FFFFFF",
        "ugi_bg": "000000",
        "ugi_output_format": "file",
        "ugi_timeout": 40,
        "ugi_insecure": False,
        "ugi_denoise": True,
        "auto_fetch_cloud": True,
        "cloud_timeout": 10,
    },
    "channel": "cloud",                 # v2 新架构：本地字库已移除，恒走 UGI-API 云通道
    "font_dir": "",                      # 本地字库已移除，不再扫描本机字体目录
    "output_dir": "d:\\ugi-out",
    "font_size": 160,                   # 字号 s：本地 / 云端共用这一个
    "font_interval": 0.1,               # 单张图间隔（秒）：相邻两张图之间固定等待
    "char_gap": 0,                      # 字距（px），默认 0；汉字/英文/标点混用切分有误差，不建议加大
    "mask_margin": 3,                   # 裁边后四周留边（px），保护「一」「丨」等细薄笔画
    "color": "#FFFFFF",
    "opacity": 255,
    "font_index": 0,
    "filename": "{index:03d}_{font}_{text}_{split}",
    "overwrite": True,
    "recursive_fonts": True,
    "selected_fonts": [],               # 与 work_fonts 始终同步
    "work_fonts": [],                   # 当前选择字体（真正参与渲染）
    "manual_fonts": [],                 # 字库池手动加入的字体（权限最高，自动同步不覆盖）
    "auto_work_fonts": True,            # 智能tag 变化时自动同步当前选择字体
    "current_text": load_hot_lines()[0],
    "current_segment": "",
    "text": "\n".join(load_hot_lines()),
    "text_source": "builtin",           # builtin = 载入内置语句池；custom = 用户自写
    "output_modes": ["single"],         # 只出单行文本
    "font_mode": "smart_tag",           # 默认策略：智能tag（jieba 分词 + 关键词提取 → tag 选字）
    "smart_tag": "",
    "specified_tag": "屌丝，躺平",
    "specified_fonts": [],
    "tag_top_n": 12,
    "tag_dimension_weight": True,
    "auto_tag_follow": True,
    # 新架构（v2）：mtag 授权清单改为 pkl 格式；不同档次用不同文件（差异化核心）。
    "tag_file": "assets/zwfnt26mtag_v1x.pkl",
    "optical_fit": True,                # 按基准的字面率做光学校正，同字号视觉一致
}

FONT_MODES = ("smart_tag", "random", "specified")
FONT_MODE_LABELS = {
    "smart_tag": "智能tag模式",
    "random": "随机模式",
    "specified": "指定模式",
}


# --------------------------------------------------------------------------- config

def _norm_dir(value) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    try:
        return os.path.normpath(raw)
    except (OSError, ValueError):
        return raw


def load_config(path: str | Path | None = None, overrides: dict | None = None) -> dict:
    """读 config.json，按默认值深合并，再套用 overrides。"""
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    p = Path(path) if path else DEFAULT_CONFIG_PATH
    if p.exists():
        try:
            user = json.loads(p.read_text(encoding="utf-8"))
            for k, v in user.items():
                if k not in cfg:
                    continue
                if isinstance(v, dict) and isinstance(cfg[k], dict):
                    cfg[k].update(v)
                else:
                    cfg[k] = v
        except (OSError, ValueError) as exc:
            raise ValueError(f"配置文件读取失败 {p}: {exc}") from exc
    if overrides:
        for k, v in overrides.items():
            if v is None or k not in cfg:
                continue
            if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                cfg[k].update(v)
            else:
                cfg[k] = v
    # 只有用户保存过自己的文本时才尊重已存内容，否则回落到内置语句池
    if cfg.get("text_source", "builtin") != "custom" or not str(cfg.get("text") or "").strip():
        cfg["text"] = "\n".join(load_hot_lines())
        cfg["text_source"] = "builtin"
    for k in ("font_dir", "output_dir"):
        cfg[k] = _norm_dir(cfg.get(k))
    # 云端方向恒为 ltr，不作为配置项
    cfg["api"].pop("ugi_direction", None)
    return cfg


def save_config(cfg: dict, path: str | Path | None = None) -> Path:
    p = Path(path) if path else DEFAULT_CONFIG_PATH
    p.parent.mkdir(parents=True, exist_ok=True)
    clean = json.loads(json.dumps(cfg))
    clean.get("api", {}).pop("ugi_direction", None)
    for k in ("font_dir", "output_dir"):
        if k in clean:
            clean[k] = _norm_dir(clean[k])
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(clean, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)
    return p


def public_config(cfg: dict) -> dict:
    """返回给浏览器的副本，授权 Key 需要可见可改。"""
    return json.loads(json.dumps(cfg))


# ------------------------------------------------------------------- mtag / whitelist

def resolve_tagfile(raw: str | Path | None = None) -> Path:
    """把配置里的 tag_file（相对 skill 根目录）解析成绝对路径。

    允许直接指向**目录**（如 ``ugi-sum/ugi-font500/``）：目录里取那份
    mtag 清单（优先 ``*v1x.pkl``，其次任意 ``zwfnt26mtag*``），这样
    「不同档次各放一个目录」时只需把 ``tag_file`` 指到目录。
    """
    raw = str(raw or DEFAULT_CONFIG["tag_file"]).strip()
    p = Path(raw)
    if not p.is_absolute():
        p = SKILL_DIR / p
    if p.is_dir():
        cands = sorted(p.glob("zwfnt26mtag*.pkl")) + sorted(p.glob("zwfnt26mtag*.json"))
        if cands:
            prefer = [c for c in cands if c.stem.lower().endswith("v1x")]
            return (prefer or cands)[0]
    return p


def load_mtag_raw(raw: str | Path | None = None) -> dict:
    """读取 mtag 授权清单原始结构（字体 id -> {维度: {cn_tag, en_tag}}）。

    同时支持新架构的 ``.pkl`` 与旧 ``.json``，加载失败返回 ``{}`` 不抛异常。
    这是各档次白名单的来源：不同版本用不同 mtag 文件 -> 白名单不同 -> 档次不同。
    """
    p = resolve_tagfile(raw)
    if not p.is_file():
        return {}
    try:
        if p.suffix.lower() == ".pkl":
            import pickle
            with p.open("rb") as fh:
                data = pickle.load(fh)
        else:
            with p.open("r", encoding="utf-8-sig") as fh:
                data = json.load(fh)
    except Exception:  # noqa: BLE001 - 清单损坏不应阻断启动
        return {}
    return data if isinstance(data, dict) else {}


def ensure_dirs(cfg: dict, create: bool = True) -> dict:
    report = {}
    for key in ("font_dir", "output_dir"):
        raw = str(cfg.get(key, "") or "").strip()
        p = Path(raw)
        if raw and not p.exists() and create:
            try:
                p.mkdir(parents=True, exist_ok=True)
            except OSError as exc:
                report[key] = {"path": raw, "exists": False, "error": str(exc)}
                continue
        report[key] = {"path": raw, "exists": p.is_dir() if raw else False,
                       "writable": os.access(str(p), os.W_OK) if p.is_dir() else False}
    return report


# --------------------------------------------------------------------------- licence

def license_info(key: str | None = None) -> dict:
    """本机离线校验，不联网；内置 Key 仅供功能自检、禁止商用，不阻断出图。"""
    k = str(key or BUILTIN_KEY).strip()
    if k == BUILTIN_KEY:
        return {"key": k, "tier": "builtin", "label": "内置自检 Key",
                "expires": "", "expired": False,
                "days_left": -1, "hint": "仅供本机功能自检，禁止商用"}
    if re.fullmatch(r"UGI-(PRO|TEAM)-[A-Z0-9]{4}-[A-Z0-9]{4}", k, re.I):
        return {"key": k, "tier": k.split("-")[1].lower(),
                "label": "正式授权版", "expires": "", "expired": False,
                "days_left": -1, "hint": "正式授权 Key 已在本机校验通过"}
    if not k:
        return {"key": "", "tier": "none", "label": "未设置 Key",
                "expires": "", "expired": False, "days_left": 0,
                "hint": "请填入授权 Key；云端接口也接受空 Key"}
    return {"key": k, "tier": "custom", "label": "自定义 Key",
            "expires": "", "expired": False, "days_left": -1,
            "hint": "自定义 Key 将原样传给 UGI-API"}


def effective_key(cfg: dict) -> str:
    """环境变量优先，其次配置里的 Key。"""
    return (os.environ.get("UGI_FONT_KEY") or str(cfg.get("api", {}).get("ugi_key") or BUILTIN_KEY)).strip()


# --------------------------------------------------------------------------- fonts

def list_fonts(font_dir: str | Path, recursive: bool = True) -> list[dict]:
    d = Path(font_dir or "")
    if not d.is_dir():
        return []
    it = d.rglob("*") if recursive else d.glob("*")
    out = []
    for p in it:
        try:
            if not p.is_file() or p.suffix.lower() not in FONT_EXTS:
                continue
            st = p.stat()
            out.append({"name": p.name, "stem": p.stem, "path": str(p),
                        "size_mb": round(st.st_size / 1048576, 2),
                        "ext": p.suffix.lower()})
        except OSError:
            continue
    return sorted(out, key=lambda x: x["name"].lower())


def resolve_fonts(selection, font_dir, all_fonts: bool = False) -> list[dict]:
    fonts = list_fonts(font_dir)
    if all_fonts:
        return fonts
    if isinstance(selection, str):
        selection = [s for s in (x.strip() for x in selection.split(",")) if s]
    by_path = {f["path"].lower(): f for f in fonts}
    by_name = {f["name"].lower(): f for f in fonts}
    by_stem = {f["stem"].lower(): f for f in fonts}
    resolved, seen = [], set()
    for raw in selection or []:
        f = None
        rp = Path(raw)
        if rp.is_file() and rp.suffix.lower() in FONT_EXTS:
            f = by_path.get(str(rp.resolve()).lower()) or {
                "name": rp.name, "stem": rp.stem, "path": str(rp.resolve()),
                "size_mb": round(rp.stat().st_size / 1048576, 2),
                "ext": rp.suffix.lower()}
        else:
            f = by_path.get(str(raw).lower()) or by_name.get(str(raw).lower()) or by_stem.get(str(raw).lower())
        if f and f["path"].lower() not in seen:
            seen.add(f["path"].lower())
            resolved.append(f)
    return resolved


@lru_cache(maxsize=64)
def load_font(path: str, size: int, index: int = 0):
    if not PILLOW_OK:
        raise RuntimeError(PILLOW_HINT)
    return ImageFont.truetype(path, size=size, index=index)


def norm_font_id(value: str) -> str:
    """把云端字体值 / 本地文件名 / tag-pool id 归一到同一个键。

    ``CLAY3_黏土体系列/zw.CLAY3_001F`` -> ``zw.clay3_001f``
    ``zw.CLAY3_001F.ttf``             -> ``zw.clay3_001f``
    """
    s = str(value or "").strip().lower().replace("\\", "/").split("/")[-1]
    s = re.sub(r"\.(ttf|otf|ttc)$", "", s)
    return re.sub(r"\s+", "", s)


def font_id_variants(value: str) -> list[str]:
    """三级匹配：完整 id、去掉尾部 F/J 变体、系列前缀。"""
    nid = norm_font_id(value)
    stem = re.sub(r"([0-9])[fj]$", r"\1", nid)
    series = re.sub(r"_?[0-9]+[a-z]?$", "", nid)
    out = [nid]
    for x in (stem, series):
        if x and x not in out:
            out.append(x)
    return out


# --------------------------------------------------------------------------- text

def parse_text(text: str) -> list[list[str]]:
    """一个非空行 = 一组图；行内的字面 \\n 视为换行。"""
    items: list[list[str]] = []
    normalized = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    for raw in normalized.split("\n"):
        if not raw.strip():
            continue
        lines = [seg for seg in raw.split("\\n")]
        if any(seg.strip() for seg in lines):
            items.append(lines)
    return items


SPLIT_MODES = ("multi", "single", "char")
SPLIT_MODE_LABELS = {"multi": "多行输出", "single": "单行输出", "char": "单字输出"}
_SPLIT_PUNCT = set(
    "，。！？；：、,.!?;:…—～~·「」『』（）()【】[]《》<>"
    "\"'“”‘’")


def split_by_punctuation(line: str) -> list[str]:
    """按标点把一行切成多组，标点保留在组尾。"""
    groups: list[str] = []
    cur = ""
    for ch in str(line or ""):
        cur += ch
        if ch in _SPLIT_PUNCT and any(
                c not in _SPLIT_PUNCT and not c.isspace() for c in cur):
            groups.append(cur)
            cur = ""
    if cur.strip():
        groups.append(cur)
    return groups or ([line] if str(line or "").strip() else [])


def expand_text_items(items: list[list[str]], mode: str = "multi") -> list[list[str]]:
    """按输出方式展开任务列表，每个元素 = 一张输出图。"""
    mode = str(mode or "multi").lower()
    if mode not in SPLIT_MODES:
        mode = "multi"
    if mode == "single":
        return items
    out: list[list[str]] = []
    for lines in items:
        if mode == "char":
            for line in lines:
                for ch in line:
                    if ch.strip():          # 标点也单独出图，只跳过空白
                        out.append([ch])
        else:
            groups: list[str] = []
            for line in lines:
                groups.extend(split_by_punctuation(line))
            out.append(groups or lines)
    return out


OUTPUT_MODES = ("single", "char", "multi")
OUTPUT_MODE_LABELS = {"single": "单行文本", "char": "单字输出", "multi": "多行输出"}


def resolve_output_modes(cfg: dict) -> list[str]:
    raw = cfg.get("output_modes")
    if isinstance(raw, (list, tuple)) and raw:
        modes = [str(m).lower() for m in raw if str(m).lower() in OUTPUT_MODES]
        if modes:
            return modes
    return ["single"]


def build_render_jobs(text: str, cfg: dict) -> list[dict]:
    """每行文本 = 一组；每组按 output_modes 展开成输出单元。

    服务端 /api/render 的张数、命令行 --dry-run 与渲染主循环共用这一份结果，
    避免三处各算一套导致总数对不上。
    """
    modes = resolve_output_modes(cfg)
    jobs: list[dict] = []
    for gi, group in enumerate(parse_text(text)):
        for mode in modes:
            for unit, lines in enumerate(expand_text_items([group], mode)):
                jobs.append({"group": gi, "mode": mode, "unit": unit, "lines": lines})
    return jobs


def join_lines(lines: list[str]) -> str:
    return "\n".join(l for l in lines)


INVALID_CHARS = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


def safe_filename(text: str, maxlen: int = 48) -> str:
    s = INVALID_CHARS.sub("_", text or "")
    s = re.sub(r"\s+", " ", s).strip().strip(".")
    s = s[:maxlen].strip()
    return s or "text"


def make_filename(cfg: dict, index: int, font_stem: str, lines: list[str],
                  used: set[str], ext: str = ".png") -> str:
    label = safe_filename(" ".join(l.strip() for l in lines))
    values = {"index": index, "font": safe_filename(font_stem, 40), "text": label,
              "date": datetime.now().strftime("%Y%m%d"),
              "time": datetime.now().strftime("%H%M%S"),
              "mode": str(cfg.get("font_mode", "smart_tag")),
              "split": str(cfg.get("_output_mode") or "single")}
    try:
        stem = str(cfg.get("filename") or DEFAULT_CONFIG["filename"]).format(**values)
    except (KeyError, ValueError, IndexError):
        stem = DEFAULT_CONFIG["filename"].format(**values)
    stem = safe_filename(stem, 110) or f"{index:03d}"
    name = stem + ext
    if not cfg.get("overwrite", True):
        n = 2
        while name in used:
            name = f"{stem}_{n}{ext}"
            n += 1
    used.add(name)
    return name


def hex_to_rgb(value: str) -> tuple[int, int, int]:
    v = (value or "#FFFFFF").lstrip("#")
    if len(v) == 3:
        v = "".join(c * 2 for c in v)
    if not re.fullmatch(r"[0-9a-fA-F]{6}", v):
        return (255, 255, 255)
    return (int(v[0:2], 16), int(v[2:4], 16), int(v[4:6], 16))


# --------------------------------------------------------------------------- render

def _layout(fonts_for_lines: list[list], lines: list[str], cfg: dict):
    """算出每个字形的落笔位置，支持逐字不同字体（混合模式）。"""
    size = int(cfg.get("font_size", 160))
    line_h = size * 1.2
    margin = int(size * 0.4) + 24
    widths, placements = [], []
    for li, line in enumerate(lines):
        x = 0.0
        row = []
        fonts = fonts_for_lines[li]
        for ci, ch in enumerate(line):
            f = fonts[ci] if ci < len(fonts) else fonts[-1]
            w = f.getlength(ch)
            row.append((ch, f, float(x), float(margin + li * line_h + size * 1.05)))
            x += w
        widths.append(x)
        placements.append(row)
    return placements, widths, line_h, margin


def crop_to_ink(img: "Image.Image", pad: int = 0) -> "Image.Image":
    """按 alpha 墨迹边界紧贴裁切，再在四周**精确**补齐 ``pad`` 像素。

    只按 alpha 求边界：`getbbox()` 包含抗锯齿半透明边，所以「一」「丨」这类
    细薄笔画的端点不会被切掉；裁完用新建画布补边（而不是在原图上内缩），
    四边留边永远等于 ``pad``，不受字形是否贴到画布边缘影响。
    """
    if not PILLOW_OK:
        return img
    pad = max(0, int(pad))
    src = img if img.mode in ("L", "RGBA") else img.convert("RGBA")
    alpha = src.getchannel("A") if src.mode == "RGBA" else src
    bbox = alpha.getbbox()
    if bbox is None:
        return src
    ink = src.crop(bbox)
    if pad <= 0:
        return ink
    fill = (255, 255, 255, 0) if ink.mode == "RGBA" else 0
    out = Image.new(ink.mode, (ink.width + 2 * pad, ink.height + 2 * pad), fill)
    out.paste(ink, (pad, pad))
    return out


def render_mask_image(fonts_for_lines: list[list], lines: list[str], cfg: dict) -> Image.Image:
    """渲染成 RGBA text-mask：像素颜色恒定，只有 alpha 变化。

    ``fonts_for_lines[line][char]`` 允许逐字换字体（混合模式），其余模式传同一个字体。
    渲染完统一按墨迹裁边并补 ``mask_margin`` 像素（默认 3）。
    """
    if not PILLOW_OK:
        raise RuntimeError(PILLOW_HINT)
    placements, widths, line_h, margin = _layout(fonts_for_lines, lines, cfg)
    max_w = max([w for w in widths if w > 0] or [int(cfg.get("font_size", 160))])
    probe_w = int(math.ceil(max_w)) + 2 * margin
    probe_h = int(line_h * len(lines)) + 2 * margin
    mask = Image.new("L", (max(1, probe_w), max(1, probe_h)), 0)
    draw = ImageDraw.Draw(mask)
    for _li, row in enumerate(placements):
        for ch, f, x, y in row:
            draw.text((x + margin, y), ch, font=f, fill=255, anchor="ls")
    if mask.getbbox() is None:
        raise ValueError("字体无法渲染该文本（字形缺失或文本为空）")

    edge = max(0, int(cfg.get("mask_margin", 3)))
    # 先紧贴裁到墨迹，留边由后面按需精确补齐，避免贴边字形被裁掉笔画
    ink = crop_to_ink(mask, 0)
    opacity = max(0, min(255, int(cfg.get("opacity", 255))))
    if opacity < 255:
        ink = ink.point(lambda a: a * opacity // 255)
    r, g, b = hex_to_rgb(str(cfg.get("color", "#FFFFFF")))

    padded = crop_to_ink(ink, edge)
    canvas = Image.new("RGBA", padded.size, (r, g, b, 0))
    canvas.putalpha(padded)
    return canvas


def single_font_matrix(font, lines: list[str]) -> list[list]:
    return [[font for _ in line] for line in lines]


def save_rgba(img: Image.Image, out_path: str | Path, fmt: str = "PNG") -> dict:
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    img.convert("RGBA").save(out, format=fmt, optimize=False)
    return {"file": str(out), "width": img.width, "height": img.height,
            "bytes": out.stat().st_size, "mode": "RGBA", "bits_per_pixel": 32}


def inspect_png(path: str | Path) -> dict:
    with Image.open(path) as im:
        im.load()
        rgba = im.convert("RGBA")
        alpha = rgba.getchannel("A")
        hist = alpha.histogram()
        corners = [rgba.getpixel(pt)[3] for pt in
                   [(0, 0), (rgba.width - 1, 0), (0, rgba.height - 1),
                    (rgba.width - 1, rgba.height - 1)]]
        bbox = alpha.getbbox() or (0, 0, 0, 0)
        return {"file": str(path), "format": im.format, "mode": im.mode,
                "size": [im.width, im.height],
                "bits_per_pixel": 32 if im.mode == "RGBA" else None,
                "alpha_min": next((i for i, v in enumerate(hist) if v), 0),
                "alpha_max": next((i for i in range(255, -1, -1) if hist[i]), 0),
                "corner_alpha": corners, "opaque_pixel_count": hist[255],
                "ink": [bbox[2] - bbox[0], bbox[3] - bbox[1]],
                "pad": [bbox[0], bbox[1], rgba.width - bbox[2], rgba.height - bbox[3]]}
