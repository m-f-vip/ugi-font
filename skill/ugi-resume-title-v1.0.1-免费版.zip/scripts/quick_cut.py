#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""结巴风格的「快速版」中文分词器（零依赖、纯本地）。

参考 jieba 精确模式的核心算法，但为本项目做了精简加速：

* 前缀词典 + DAG 有向无环图 + 动态规划最大概率路径；
* **关闭 HMM 新词发现**（即 jieba ``cut(HMM=False)`` 的「快速版」），
  不跑 Viterbi，只有词典词与单字兜底，速度快、结果稳定；
* jieba 若已安装则直接走 ``jieba.cut(HMM=False)``（更快的加速路径）；
* 词典 = 项目 tag-pools 的全部 cn_tag（设计/字体/PPT/短视频场景词）+
  内置高频通用词，因此像「赛博朋克」「钱兔无量」「国潮」这类场景词能
  整词命中，不会切出「友们兔」「心不喜」这种跨词碎片。

对外只暴露 ``cut(text) -> list[str]`` 与 ``engine() -> str``。
"""
from __future__ import annotations

import json
import math
import re
from functools import lru_cache

from ugi_core import ASSETS_DIR, load_mtag_raw, resolve_tagfile

# 通用高频词：保证日常语句（20 条爆款网络语句等）也能被合理切分。
# 领域词由 tag-pools 自动注入，这里只补通用词，避免词典过大拖慢启动。
_COMMON_WORDS = """
我们 你们 他们 咱们 大家 自己 别人 有人 没人 人们 朋友 家人 老师 同学 同事
喜欢 真心 快乐 开心 幸福 美好 热爱 感动 温柔 善良 勇敢 坚强 努力 奋斗
选择 决定 放弃 坚持 相信 希望 期待 等待 遇见 错过 拥有 失去 明白 懂得 记得
生活 人生 世界 时间 岁月 青春 未来 今天 明天 昨天 现在 从来 永远 一生 一时
工作 事业 学习 成长 成熟 成功 失败 运气 实力 底气 结果 过程 故事 日子
孩子 大人 成年 少年 青年 老人 女人 男人 父母 妈妈 爸爸 爱人 对象
一个 一些 一种 一样 一切 一半 一起 一直 一定 一点 更加 已经 曾经
可以 应该 需要 能够 必须 可能 愿意 想要 打算 准备 开始 结束 继续 保持
不是 就是 还是 但是 所以 因为 如果 虽然 而且 然后 并且 与其 不如 只要
很多 很少 好多 多么 这样 那样 这么 那么 这里 那里 哪里 全部 整个 部分
正在 马上 立刻 偶尔 经常 总是 从未 从不 再也 最终 最后 别的 其它 其他
另外 尤其 特别 非常 十分 都好 都是 都行 没有 没用 办法 都要 都行
山海 远方 眼前 苟且 诗歌 奔赴 崩溃 自愈 焦虑 自律 自由 钝感 情绪 稳定
修养 积累 来时 身后 回头 出发 行动 及时 止损 最好 完美 值得 喜欢
祝你 祝我 祝他 朋友们 兔年 钱兔 无量 大吉 大利 如意 吉祥 恭喜 发财
新年 快乐 春节 过年 红包 好运 暴富 升值 加薪 中奖 智能体 好好 挣钱 赚钱
世界 尽头 角落 风景 天空 太阳 月亮 星星 大海 山川 河流 花朵 微风 细雨
风起 雨落 追风 听雨 起风 落叶 花开 结果 四季 春天 夏天 秋天 冬天
"""
_COMMON_WORDS = " ".join(w for w in _COMMON_WORDS.split() if len(w) >= 2)

# 未登录单字合并后的目标块大小（2~3 字更像词）
_MAX_UNKNOWN = 4
_WORD_RE = re.compile(r"[\u4e00-\u9fff]+|[A-Za-z][A-Za-z0-9]*|\d+")

# 领域词：与 smart_tag.DOMAIN_WORDS 呼应，额外补常见成语/网络语组合。
_EXTRA_WORDS = (
    "赛博朋克", "霓虹灯", "科技感", "未来感", "国风水墨", "水墨书法",
    "中秋海报", "春节海报", "新年快乐", "兔年大吉", "钱兔无量",
    "恭喜发财", "前程似锦", "万事如意", "真心喜欢", "真心不喜欢",
    "成年人的选择", "我都要", "保持热爱", "奔赴山海", "及时止损",
    "情绪稳定", "修身养性", "努力奋斗", "暴富发财", "标题字", "短视频",
    "主视觉", "视觉", "海报主视觉", "片头动效", "花字标题", "标准字",
    "钱兔", "兔年", "大吉", "无量", "朋友们", "喜欢的人", "不喜欢的人",
)


@lru_cache(maxsize=1)
def _jieba_module():
    try:
        import jieba  # type: ignore
    except Exception:
        return None
    # 只把「结巴默认词典里没有」的项目领域词加入用户词典，绝不覆盖默认词频。
    # add_word(word, freq=8~12) 会覆盖 jieba 内置高频词的词频，导致
    # 「时间→时/间」「自由→自/由」「好好生活→好/好生/活」这类错误切分。
    # 现在：默认词（如 时间/自由/成功）保留 jieba 原生词频；只有缺失的领域词
    # （赛博朋克/钱兔无量/成年人的选择/海报主视觉…）才以中等词频加入，整词命中。
    try:
        default_freq = jieba.dt.FREQ          # jieba 默认词典（含加载后的用户词典）
        freq, _, _ = _dict()
        candidates = list(freq) + list(_EXTRA_WORDS) + [
            "钱兔无量", "成年人的选择", "真心不喜欢", "奔赴山海", "诗和远方",
            "时间", "自由", "好好生活", "成功", "财富", "未来",
        ]
        for word in candidates:
            w = str(word).strip()
            if len(w) < 2 or w in default_freq:
                continue                        # 已存在 -> 保留原生词频，不覆盖
            jieba.add_word(w, freq=1000)
    except Exception:
        pass
    return jieba


@lru_cache(maxsize=1)
def _dict() -> tuple[dict[str, float], int, float]:
    """构建一次并缓存：(词->原始频率, 最长词长, log(频率总和))。"""
    freq: dict[str, float] = {}

    def add(w: object, s: float) -> None:
        w = str(w).strip()
        if len(w) >= 2:
            freq[w] = max(freq.get(w, 0.0), float(s))

    for w in set(_COMMON_WORDS.split()):
        add(w, 8.0)
    # 领域词来自本版本 mtag 授权清单的 cn_tag（pkl / json 均可）。
    data = load_mtag_raw(resolve_tagfile())
    for rec in data.values():
        if not isinstance(rec, dict):
            continue
        for dim in rec.values():
            if not isinstance(dim, dict):
                continue
            for tag in dim.get("cn_tag") or []:
                add(tag, 12.0)
    for w in _EXTRA_WORDS:
        add(w, 11.0)

    max_len = min(16, max((len(w) for w in freq), default=8))
    log_total = math.log(1.0 + sum(freq.values()))
    return freq, max_len, log_total


def _build_dag(sentence: str, freq: dict[str, float], max_len: int) -> dict[int, list[int]]:
    """DAG：每个起点 i 的所有可达词尾下标（含），未登录则单字兜底。

    与结巴前缀 trie 等价，但用「最大词长窗口内枚举子串」实现，词典无需
    预存每个前缀，构建更快。
    """
    dag: dict[int, list[int]] = {}
    n = len(sentence)
    for i in range(n):
        dest: list[int] = []
        upper = min(n, i + max_len)
        for j in range(i + 1, upper + 1):
            if sentence[i:j] in freq:
                dest.append(j - 1)
        if not dest:
            dest = [i]
        dag[i] = dest
    return dag


def _dp_cut(sentence: str, freq: dict[str, float], max_len: int,
            log_total: float) -> list[str]:
    """DAG + 动态规划最大概率路径（结巴精确模式核心，关闭 HMM）。"""
    if not sentence:
        return []
    dag = _build_dag(sentence, freq, max_len)
    n = len(sentence)
    # route[i] = (从 i 到末尾的最大累计得分, 下一个起点)
    route: dict[int, tuple[float, int]] = {n: (0.0, n)}
    for i in range(n - 1, -1, -1):
        best = (-1e18, i + 1)
        for j in dag[i]:
            word = sentence[i:j + 1]
            weight = math.log(freq.get(word, 1.0)) - log_total
            score = weight + route[j + 1][0]
            if score > best[0]:
                best = (score, j + 1)
        route[i] = best
    out: list[str] = []
    i = 0
    while i < n:
        j = route[i][1]
        out.append(sentence[i:j])
        i = j
    return _merge_singles(out, freq)


def _chunk(s: str, freq: dict[str, float] | None = None) -> list[str]:
    """把一个未登录串切成更像词的块：优先用词典最大匹配切出已知词。"""
    out: list[str] = []
    if freq:
        k = 0
        while k < len(s):
            # 在最大词长内找最长的已知词；找不到就取 2 字兜底
            hit = 0
            for j in range(min(len(s), k + 8), k + 1, -1):
                if s[k:j] in freq:
                    hit = j - k
                    break
            if hit:
                out.append(s[k:k + hit])
                k += hit
            else:
                step = 2 if len(s) - k > 2 else 1
                out.append(s[k:k + step])
                k += step
        return [w for w in out if w]
    k = 0
    out = []
    while k < len(s):
        step = 2 if len(s) - k > 2 else 1
        out.append(s[k:k + step])
        k += step
    return out


def _merge_singles(words: list[str], freq: dict[str, float]) -> list[str]:
    """连续未登录单字合并，再用词典最大匹配切词，避免「一字一词」与半截词。"""
    out: list[str] = []
    buf = ""
    for w in words:
        if len(w) == 1 and w not in freq:
            buf += w
        else:
            if buf:
                out.extend(_chunk(buf, freq))
                buf = ""
            out.append(w)
    if buf:
        out.extend(_chunk(buf, freq))
    return out


def cut(text: str) -> list[str]:
    """对整段文本分词：先按中/英/数分块，再逐块走结巴式快速分词。"""
    s = str(text or "")
    if not s.strip():
        return []
    jb = _jieba_module()
    if jb is not None:
        try:
            # HMM=False -> 结巴「快速版」：前缀词典 + DAG + DP，不跑 Viterbi
            return [w for w in jb.cut(s, cut_all=False, HMM=False) if w.strip()]
        except Exception:
            pass
    freq, max_len, log_total = _dict()
    out: list[str] = []
    for m in _WORD_RE.finditer(s):
        block = m.group(0)
        if block[0].isascii():
            out.append(block)
        else:
            out.extend(_dp_cut(block, freq, max_len, log_total))
    return out


def engine() -> str:
    """当前分词引擎：jieba-fast（安装了结巴）或 builtin-dag（内置结巴式）。"""
    return "jieba-fast" if _jieba_module() is not None else "builtin-dag"


def has_word(word: str) -> bool:
    """该词是否在内置词典中（供上游做词级权重打分）。"""
    return bool(word) and str(word).strip() in _dict()[0]


if __name__ == "__main__":
    import sys
    samples = sys.argv[1:] or [
        "祝所有U友，兔年大吉，钱兔无量！",
        "有人真心喜欢，就有人真心不喜欢",
        "成年人的选择是我都要",
        "赛博朋克霓虹标题字 科技感海报主视觉",
        "国风水墨书法 中秋海报标题",
    ]
    for t in samples:
        print(t, "->", cut(t), engine())
