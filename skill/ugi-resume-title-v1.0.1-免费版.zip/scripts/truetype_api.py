#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UGI-API (truetype REST) client for UGI Font Pro.

Standard parameters: o / s / d / tc / bc / c / f / t / key.
The Pro edition always sends ``d=ltr`` (排版方向 removed from the UI) and
passes the configured Key (default ``ugi-free-2026-12-12``). If a Key is
rejected by the server, the catalogue call silently retries with an empty Key
and finally falls back to the built-in offline list -- startup never blocks.

The service returns an opaque PNG; :func:`to_white_mask` rebuilds a strict
32-bit RGBA, pure-white-glyph, alpha=0 background mask.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from PIL import Image

from ugi_core import hex_to_rgb, BUILTIN_KEY, crop_to_ink

DEFAULT_ENDPOINT = "https://ugiapi.z-w.vip/api/truetype"
DEFAULT_LISTFONTS = "https://ugiapi.z-w.vip/api/listfonts"
UGI_STANDARD_URL = "https://ugi.z-w.vip/"
DEFAULT_SIZE = 160
DEFAULT_TIMEOUT = 40
DIRECTION = "ltr"                  # fixed: no UI field in the Pro edition
DEFAULT_OUTPUT_FORMAT = "file"
DEFAULT_FG = "FFFFFF"
DEFAULT_BG = "000000"
DEFAULT_FONT = "CLAY3_黏土体系列/zw.CLAY3_001F"

PNG_MAGIC = b"\x89PNG\r\n\x1a\n"
RENDER_ERROR_MD5 = {"a6ee280fc4b82fc85029a53852efb81c"}
FALLBACK_FONTS = [
    DEFAULT_FONT,
    "CLAY4_粘土方系列/zw.CLAY4_001F",
    "LOSER9_屌丝粗系列/zw.LOSER9_001F",
    "zw.FAT4_003J",
    "思源真黑体-P-Normal",
]
_FONT_CACHE: dict = {"url": "", "ts": 0.0, "data": None}
_CACHE_TTL = 300.0


class UgiApiError(Exception):
    """Human-readable Chinese error for the cloud channel."""


def derive_listfonts(endpoint: str | None = None) -> str:
    e = str(endpoint or DEFAULT_ENDPOINT).strip()
    if not e:
        return DEFAULT_LISTFONTS
    if e.rstrip("/").endswith("/api/truetype"):
        return e.rstrip("/")[:-len("/api/truetype")] + "/api/listfonts"
    p = urllib.parse.urlsplit(e)
    return urllib.parse.urlunsplit((p.scheme, p.netloc, "/api/listfonts", "", ""))


def normalize_hex(value: str, default: str) -> str:
    v = str(value or default).strip().lstrip("#")
    if len(v) == 3:
        v = "".join(c * 2 for c in v)
    if not re.fullmatch(r"[0-9a-fA-F]{6}", v):
        raise UgiApiError(f"颜色值不合法（应为 6 位 hex）：{value}")
    return v.upper()


def _ssl_context(insecure: bool):
    if not insecure:
        return None
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def _http_get(url: str, timeout: float, insecure: bool = False) -> tuple[int, str, bytes]:
    req = urllib.request.Request(
        url, headers={"User-Agent": "UGI-Font-Pro/1.0 (+local skill)", "Accept": "*/*"})
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl_context(insecure)) as resp:
            return resp.status, resp.headers.get("Content-Type") or "", resp.read()
    except urllib.error.HTTPError as exc:
        try:
            detail = exc.read().decode("utf-8", "replace")[:200]
        except Exception:
            detail = ""
        raise UgiApiError(f"UGI-API 返回 HTTP {exc.code}：{detail or exc.reason}") from exc
    except urllib.error.URLError as exc:
        raise UgiApiError(f"无法连接 UGI-API（{getattr(exc, 'reason', exc)}）") from exc
    except TimeoutError as exc:
        raise UgiApiError(f"UGI-API 请求超时（{timeout}s）") from exc
    except Exception as exc:  # noqa: BLE001
        raise UgiApiError(f"调用 UGI-API 失败：{exc}") from exc


def _check_json_error(raw: bytes, ctype: str):
    if raw[:8] == PNG_MAGIC:
        return None
    if "json" not in ctype.lower() and not raw.lstrip().startswith((b"{", b'"')):
        return None
    try:
        value = json.loads(raw.decode("utf-8", "replace"))
    except (ValueError, UnicodeDecodeError):
        return None
    if isinstance(value, dict) and value.get("code") not in (None, 0, "0"):
        raise UgiApiError(f"UGI-API 返回错误 code={value.get('code')}：{value.get('msg') or '未提供说明'}")
    return value


def parse_image_response(raw: bytes, ctype: str) -> bytes:
    value = _check_json_error(raw, ctype)
    if value is None:
        if raw[:8] != PNG_MAGIC:
            head = raw[:120].decode("utf-8", "replace").replace("\n", " ")
            raise UgiApiError(f"UGI-API 返回的不是 PNG 图片：{head}")
        return raw
    blob = None
    if isinstance(value, str):
        blob = value
    elif isinstance(value, dict):
        for key in ("data", "image", "b64", "base64", "url"):
            v = value.get(key)
            if isinstance(v, str) and (v.startswith("data:") or len(v) > 60):
                blob = v
                break
    if not blob:
        raise UgiApiError(f"UGI-API 返回了非图片数据：{str(value)[:160]}")
    if "," in blob and blob.strip().startswith("data:"):
        blob = blob.split(",", 1)[1]
    try:
        decoded = base64.b64decode(blob, validate=True)
    except Exception as exc:  # noqa: BLE001
        raise UgiApiError(f"UGI-API 返回的 base64 无法解码：{exc}") from exc
    if decoded[:8] != PNG_MAGIC:
        raise UgiApiError("UGI-API 的 base64 内容不是 PNG 图片")
    return decoded


def is_render_error(png: bytes) -> bool:
    return hashlib.md5(png).hexdigest() in RENDER_ERROR_MD5


def _split_font(value: str) -> dict:
    raw = str(value or "").strip()
    group, name = raw.split("/", 1) if "/" in raw else ("默认", raw)
    return {"value": raw, "group": group, "name": name}


def fetch_fonts(endpoint: str | None = None, timeout: float = DEFAULT_TIMEOUT,
                key: str = "", refresh: bool = False, offline: bool = False,
                insecure: bool = False) -> dict:
    """Download the cloud font catalogue. Tries (key -> empty key -> offline)."""
    url = str(endpoint or DEFAULT_LISTFONTS).strip() or DEFAULT_LISTFONTS
    now = time.time()
    if (not refresh and not offline and _FONT_CACHE["data"] is not None
            and _FONT_CACHE["url"] == url and now - _FONT_CACHE["ts"] < _CACHE_TTL):
        return dict(_FONT_CACHE["data"], cached=True)
    if offline:
        return _offline_result(url)

    attempts = [str(key or "").strip()]
    if attempts[0] and "" not in attempts:
        attempts.append("")
    last_error = ""
    for k in attempts:
        params = {"key": k} if k else {}
        full = url + ("?" + urllib.parse.urlencode(params) if params else "")
        try:
            _s, ctype, raw = _http_get(full, float(timeout), insecure)
            value = _check_json_error(raw, ctype)
            if not isinstance(value, dict):
                raise UgiApiError("字体清单接口返回格式不正确（应为 JSON 对象）")
            data = value.get("data") or {}
            ttf = [str(x) for x in (data.get("ttf") or []) if str(x).strip()]
            if not ttf:
                ttf = list(FALLBACK_FONTS)
            groups: dict[str, list[str]] = {}
            src = data.get("ttf_groups") or {}
            if isinstance(src, dict) and src:
                for g, items in src.items():
                    groups[str(g)] = [str(x) for x in items if str(x)]
            else:
                for item in ttf:
                    groups.setdefault(_split_font(item)["group"], []).append(_split_font(item)["name"])
            result = {
                "ok": True, "endpoint": url,
                "fonts": [_split_font(v) for v in ttf],
                "groups": {g: list(v) for g, v in groups.items()},
                "total": len(ttf),
                "source": "UGI-API /api/listfonts",
                "standard_url": UGI_STANDARD_URL,
                "key_used": bool(k),
                "cached": False,
            }
            _FONT_CACHE.update({"url": url, "ts": now, "data": result})
            return result
        except UgiApiError as exc:
            last_error = str(exc)
            continue
    result = _offline_result(url)
    result["warning"] = f"云端字体清单下载失败，已使用内置离线清单：{last_error}"
    return result


def _offline_result(url: str) -> dict:
    return {"ok": True, "endpoint": url,
            "fonts": [_split_font(v) for v in FALLBACK_FONTS],
            "groups": {"内置离线清单": [_split_font(v)["name"] for v in FALLBACK_FONTS]},
            "total": len(FALLBACK_FONTS), "source": "内置离线清单（未联网）",
            "standard_url": UGI_STANDARD_URL, "key_used": False,
            "cached": False}


def clear_font_cache() -> None:
    _FONT_CACHE.update({"url": "", "ts": 0.0, "data": None})


def render_one(endpoint: str, text: str, font: str, *, size: int = DEFAULT_SIZE,
               fg: str = DEFAULT_FG, bg: str = DEFAULT_BG,
               output_format: str = DEFAULT_OUTPUT_FORMAT, key: str = "",
               timeout: float = DEFAULT_TIMEOUT, insecure: bool = False,
               category: str = "") -> tuple[bytes, dict]:
    """One UGI-API call. ``d`` is fixed to ``ltr`` per the Pro edition spec."""
    f = str(font or "").strip()
    if not f:
        raise UgiApiError("缺少字体名 f")
    if not str(text or "").strip():
        raise UgiApiError("缺少文本 t")
    if str(output_format) not in ("b64", "file"):
        raise UgiApiError("输出格式 o 只能是 b64 或 file")
    params = {
        "f": f, "t": str(text), "s": str(max(1, int(size))), "d": DIRECTION,
        "tc": normalize_hex(fg, DEFAULT_FG), "bc": normalize_hex(bg, DEFAULT_BG),
        "o": str(output_format),
    }
    if category:
        params["c"] = str(category)
    if key:
        params["key"] = str(key)
    url = str(endpoint or DEFAULT_ENDPOINT).strip() or DEFAULT_ENDPOINT
    full = url + ("&" if "?" in url else "?") + urllib.parse.urlencode(params, encoding="utf-8")
    _s, ctype, raw = _http_get(full, float(timeout), insecure)
    png = parse_image_response(raw, ctype)
    if is_render_error(png):
        raise UgiApiError(f"UGI-API 返回「渲染异常」图：字体「{f}」不存在或参数不被接受")
    with Image.open(io.BytesIO(png)) as im:
        info = {"width": im.width, "height": im.height, "mode": im.mode,
                "font": f, "text": str(text), "size": int(size),
                "direction": DIRECTION, "url": full}
    return png, info


def to_white_mask(png: bytes, fg: str = DEFAULT_FG, bg: str = DEFAULT_BG,
                  denoise: bool = True) -> tuple[bytes, dict]:
    """Rebuild a strict 32-bit RGBA white-mask from the opaque API image."""
    fg_rgb, bg_rgb = hex_to_rgb(normalize_hex(fg, DEFAULT_FG)), hex_to_rgb(normalize_hex(bg, DEFAULT_BG))

    def lum(rgb):
        r, g, b = rgb
        return 0.299 * r + 0.587 * g + 0.114 * b

    fg_l, bg_l = lum(fg_rgb), lum(bg_rgb)
    denom = fg_l - bg_l
    if abs(denom) < 1:
        raise UgiApiError("字色 tc 与底色 bc 太接近，无法提取透明度；请用白字黑底")
    table = []
    for v in range(256):
        a = max(0, min(255, round((v - bg_l) / denom * 255)))
        if denoise and a < 2:
            a = 0
        table.append(a)
    with Image.open(io.BytesIO(png)) as src:
        grey = src.convert("L")
        rgba = src.convert("RGBA")
    alpha = grey.point(table)
    mask = Image.new("RGBA", rgba.size, (255, 255, 255, 0))
    mask.putalpha(alpha)
    buf = io.BytesIO()
    mask.save(buf, format="PNG")
    lo, hi = alpha.getextrema()
    return buf.getvalue(), {"mode": "RGBA", "bits_per_pixel": 32,
                            "width": mask.width, "height": mask.height,
                            "alpha_min": lo, "alpha_max": hi, "bytes": len(buf.getvalue())}


DEFAULT_CHAR_GAP = 0            # 字距（px）默认 0；汉字/英文/标点混用切分有误差，不建议加大


def insert_char_gap(img: "Image.Image", text: str, gap: int = 0) -> "Image.Image":
    """按字符数把整行 mask 均分成字格，在相邻字格之间插入 ``gap`` px 透明列。

    UGI-API 的 ``t`` 一次接收整行文字，参数里没有字间距项；中文标题字按
    近似等宽排版（实测字号 160 时每字 ≈109px），因此本地切列插入即可，
    **不增加任何云端请求**。含换行时逐行处理再纵向拼回。
    """
    gap = max(0, int(gap or 0))
    lines = str(text or "").split("\n")
    counts = [len([c for c in line if not c.isspace()]) for line in lines]
    if gap <= 0 or sum(max(0, n - 1) for n in counts) <= 0:
        return img
    im = img.convert("RGBA")
    out_w = im.width + gap * sum(max(0, n - 1) for n in counts)
    out = Image.new("RGBA", (max(1, out_w), im.height), (255, 255, 255, 0))
    row_h = im.height / max(1, len(lines))
    for li, (line, n) in enumerate(zip(lines, counts)):
        y0 = int(round(li * row_h))
        y1 = int(round((li + 1) * row_h)) if li < len(lines) - 1 else im.height
        band = im.crop((0, y0, im.width, y1))
        if n <= 1:
            out.alpha_composite(band, (0, y0))
            continue
        bounds = [int(round(i * band.width / n)) for i in range(n + 1)]
        for i in range(n):
            piece = band.crop((bounds[i], 0, bounds[i + 1], band.height))
            out.alpha_composite(piece, (bounds[i] + i * gap, y0))
    return out


def render_mask(endpoint: str, text: str, font: str, cfg: dict,
                key: str = "") -> Image.Image:
    """云端通道 -> PIL RGBA text-mask（已按墨迹裁边并补安全边）。"""
    api = cfg.get("api") or {}
    raw, _info = render_one(
        endpoint or str(api.get("ugi_endpoint") or DEFAULT_ENDPOINT),
        text, font,
        size=int(cfg.get("font_size") or DEFAULT_SIZE),
        fg=str(api.get("ugi_fg") or DEFAULT_FG),
        bg=str(api.get("ugi_bg") or DEFAULT_BG),
        output_format=str(api.get("ugi_output_format") or DEFAULT_OUTPUT_FORMAT),
        key=key if key else str(api.get("ugi_key") or BUILTIN_KEY),
        timeout=float(api.get("ugi_timeout") or DEFAULT_TIMEOUT),
        insecure=bool(api.get("ugi_insecure") or False))
    png, _spec = to_white_mask(raw, str(api.get("ugi_fg") or DEFAULT_FG),
                               str(api.get("ugi_bg") or DEFAULT_BG),
                               bool(api.get("ugi_denoise", True)))
    with Image.open(io.BytesIO(png)) as im:
        # 先紧贴墨迹（不加留边）→ 插入字距 → 最后统一精确补 mask_margin
        ink = crop_to_ink(im.convert("RGBA"), 0)
        gap = int(cfg.get("char_gap", DEFAULT_CHAR_GAP) or 0)
        ink = insert_char_gap(ink, text, gap)
        return crop_to_ink(ink, int(cfg.get("mask_margin", 3)))
