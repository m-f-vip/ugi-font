#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UGI Font 本地 API 服务（标准库，仅监听回环地址）。

启动时在后台线程固定做三件事：下载 UGI-API 字体清单、扫描本地字体、
构建 tag-pools。界面轮询 /api/catalog-status 直到 ``ready``。
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import socket
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

HERE = Path(__file__).resolve().parent
SKILL_DIR = HERE.parent
UI_DIR = SKILL_DIR / "ui"
ASSETS_DIR = SKILL_DIR / "assets"
DOC_DIR = SKILL_DIR / "doc"
CONFIG_PATH = SKILL_DIR / "config.json"
sys.path.insert(0, str(HERE))

import catalog  # noqa: E402
import font_spec  # noqa: E402
import render_engine  # noqa: E402
import smart_tag  # noqa: E402
import truetype_api  # noqa: E402
import usage  # noqa: E402
from tag_pools import pools_from_config, split_tags, input_tags  # noqa: E402
from ugi_core import (  # noqa: E402
    FONT_MODE_LABELS, FONT_MODES, PILLOW_HINT, PILLOW_OK, ensure_dirs,
    license_info, load_config, public_config, safe_filename, save_config,
)

LOCK = threading.RLock()
CANCEL = threading.Event()   # 结束：提前终止任务
PAUSE = threading.Event()    # 中断/继续：暂停时不推进新图片
TASK = {"seq": 0}            # 任务代次：旧线程看到代次变了就自我作废，绝不覆盖新任务
MAX_BODY = 30 * 1024 * 1024
VERSION = "2.1.0"

STATE: dict = {
    "status": "idle", "done": 0, "total": 0, "percent": 0, "current": "",
    "paused": False, "stopping": False,
    "logs": [], "results": [], "errors": [], "skipped": [], "failed_fonts": [],
    "output_dir": "",
    "started_at": None, "finished_at": None, "last_error": "", "elapsed": 0,
    "runtime": {}, "usage": {},
}

MIME = {
    ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8", ".png": "image/png",
    ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".svg": "image/svg+xml",
    ".ico": "image/x-icon", ".txt": "text/plain; charset=utf-8",
    ".md": "text/markdown; charset=utf-8", ".json": "application/json; charset=utf-8",
    ".pdf": "application/pdf", ".ttf": "font/ttf", ".otf": "font/otf",
}


class BadRequest(Exception):
    pass


class PayloadTooLarge(Exception):
    pass


def state_snapshot() -> dict:
    with LOCK:
        s = dict(STATE)
        s["logs"] = list(STATE["logs"][-300:])
        s["results"] = list(STATE["results"][-300:])
        s["errors"] = list(STATE["errors"][-60:])
        s["skipped"] = list(STATE["skipped"][-40:])
        s["failed_fonts"] = list(STATE.get("failed_fonts") or [])
    return s


def add_log(msg: str) -> None:
    with LOCK:
        STATE["logs"].append(f"{time.strftime('%H:%M:%S')}  {msg}")
        if len(STATE["logs"]) > 500:
            del STATE["logs"][:-400]


def start_worker(text: str, cfg: dict, render_opts: dict | None = None,
                 usage_tag: str | None = None) -> None:
    """render_opts 只作用于本次任务（如矩阵输出），不写回持久配置。

    ``usage_tag`` 非空时，任务结束时按**实际成功张数**计入本月用量
    （点「结束」中止也照已出图的张数计，不做回退）。

    任务代次 ``TASK["seq"]``：每次启动 +1，旧线程一旦发现代次变了就自我
    作废——既不会继续出图，也不会把新任务的状态/结果覆盖掉。
    """
    CANCEL.clear()
    PAUSE.clear()
    job_cfg = dict(cfg)
    if render_opts:
        job_cfg.update(render_opts)
    TASK["seq"] += 1
    my_seq = TASK["seq"]

    def superseded() -> bool:
        return TASK["seq"] != my_seq

    def should_stop() -> bool:
        return CANCEL.is_set() or superseded()

    with LOCK:
        STATE.update({"status": "running", "done": 0, "total": 0, "percent": 0,
                      "current": "", "paused": False, "stopping": False,
                      "logs": [], "results": [], "errors": [],
                      "skipped": [], "failed_fonts": [],
                      "output_dir": cfg.get("output_dir", ""), "started_at": time.time(),
                      "finished_at": None, "last_error": "", "elapsed": 0, "runtime": {}})

    def progress(done, total, label):
        with LOCK:
            STATE["done"] = done
            STATE["total"] = total
            STATE["percent"] = round(done / max(1, total) * 100, 1)
            STATE["current"] = label

    def work():
        try:
            result = render_engine.batch_render(
                text, job_cfg, cfg["output_dir"], progress, add_log, should_stop,
                should_pause=PAUSE.is_set)
            # 先记账、后落状态：前端一看到「已结束 / 完成」就能读到刚更新的次数，
            # 不会出现「任务结束了但顶栏次数还是旧值」的竞态。
            us = None
            if usage_tag:
                try:
                    n = int(result.get("success") or 0)
                    us = usage.record(usage_tag, n)
                    add_log(f"本次计入 {n} 张，本月用量已更新："
                            f"{us.get('used', 0)}/{us.get('cap', 0)} 张")
                except Exception:  # noqa: BLE001 - 计数失败不影响出图结果
                    us = None
            if superseded():
                return
            with LOCK:
                STATE["status"] = "stopped" if result["stopped"] else ("done" if result["ok"] else "error")
                STATE["paused"] = False
                STATE["stopping"] = False
                STATE["results"] = result["results"]
                STATE["errors"] = result["errors"]
                STATE["skipped"] = result.get("skipped") or []
                STATE["failed_fonts"] = result.get("failed_fonts") or []
                STATE["done"] = result["done"]
                STATE["total"] = result["total"]
                STATE["percent"] = round(result["done"] / max(1, result["total"]) * 100, 1)
                STATE["elapsed"] = result["elapsed"]
                STATE["output_dir"] = result["output_dir"]
                STATE["runtime"] = result.get("runtime", {})
                STATE["finished_at"] = time.time()
                if us:
                    STATE["usage"] = us
        except Exception as exc:  # noqa: BLE001
            add_log(f"错误：{exc}")
            if superseded():
                return
            with LOCK:
                STATE["status"] = "error"
                STATE["paused"] = False
                STATE["stopping"] = False
                STATE["last_error"] = str(exc)
                STATE["finished_at"] = time.time()

    threading.Thread(target=work, name="ugi-font-render", daemon=True).start()


def startup_tasks(cfg: dict) -> None:
    try:
        usage.init_store()
    except Exception as exc:  # noqa: BLE001
        add_log(f"用量计数器初始化失败：{exc}")
    try:
        pools_from_config(cfg).load()
    except Exception as exc:  # noqa: BLE001
        add_log(f"tag-pools 载入失败：{exc}")
    catalog.prepare_catalog(cfg, force=True)
    st = catalog.status()
    add_log(f"运行时准备完成：云端清单下载 + mtag 白名单构建"
            f"（授权 {st.get('whitelist_total', 0)} 套 / 云端可达 {st.get('whitelist_reachable', 0)} 套）")


class Handler(BaseHTTPRequestHandler):
    server_version = "UGIFont/1.1"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass

    # ------------------------------------------------------------- helpers
    def _json(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        if self.close_connection:
            self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(data)

    def _bytes(self, data: bytes, ctype: str, code=200):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length", "0") or 0)
        if length <= 0:
            return {}
        if length > MAX_BODY + 1024 * 1024:
            remaining = length
            while remaining > 0:
                chunk = self.rfile.read(min(65536, remaining))
                if not chunk:
                    break
                remaining -= len(chunk)
            self.close_connection = True
            raise PayloadTooLarge("请求体超过 30MB 限制")
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise BadRequest(f"JSON 解析失败: {exc}") from exc

    def _static(self, rel: str, root: Path):
        rel = (rel or "").lstrip("/")
        from urllib.parse import unquote
        target = (root / unquote(rel)).resolve()
        if not target.is_relative_to(root.resolve()) or not target.is_file():
            self._json({"ok": False, "error": "文件不存在"}, 404)
            return
        self._bytes(target.read_bytes(), MIME.get(target.suffix.lower(), "application/octet-stream"))

    # ------------------------------------------------------------- GET
    def do_GET(self):  # noqa: N802
        u = urlparse(self.path)
        path, q = u.path, parse_qs(u.query)
        try:
            cfg = load_config(CONFIG_PATH)
            if path in ("/", "/index.html"):
                self._static("index.html", UI_DIR)
            elif path.startswith("/ui/"):
                self._static(path[4:], UI_DIR)
            elif path.startswith("/assets/"):
                self._static(path[8:], ASSETS_DIR)
            elif path == "/favicon.ico":
                self._static("logo.jpg", UI_DIR)
            elif path == "/api/health":
                product = usage.detect_product(cfg)
                utag = usage.default_tag_from_config(cfg)
                utier = usage.get_tier(utag)
                self._json({"ok": True, "service": "ugi-font", "edition": utag,
                            "edition_name": utier.get("display_name") or utier.get("name"),
                            "product": product,
                            "version": VERSION, "pillow_ok": PILLOW_OK,
                            "hint": "" if PILLOW_OK else PILLOW_HINT,
                            "python": sys.version.split()[0], "skill_dir": str(SKILL_DIR),
                            "license": license_info(cfg["api"].get("ugi_key"))})
            elif path == "/api/config":
                self._json({"ok": True, "config": public_config(cfg),
                            "dirs": ensure_dirs(cfg),
                            "license": license_info(cfg["api"].get("ugi_key")),
                            "catalog": catalog.status(),
                            "tag_pools": pools_from_config(cfg).stats(),
                            "font_spec": font_spec.stats(),
                            "usage": usage.status(usage.default_tag_from_config(cfg)),
                            "enums": {"font_modes": list(FONT_MODES),
                                      "font_mode_labels": FONT_MODE_LABELS}})
            elif path == "/api/catalog-status":
                self._json({"ok": True, **catalog.status()})
            elif path == "/api/catalog":
                force = q.get("refresh", [""])[0] in ("1", "true", "yes")
                cloud = q.get("cloud", [""])[0]
                if cloud in ("0", "false", "no"):
                    allow = False
                elif cloud in ("1", "true", "yes"):
                    allow = True          # 手动刷新强制拉云端，不受 auto_fetch_cloud 影响
                else:
                    allow = None
                if force:
                    catalog.prepare_catalog(cfg, force=True, allow_cloud=allow, background=True)
                self._json({"ok": True, **catalog.get_catalog()})
            elif path == "/api/fonts":
                channel = q.get("channel", ["all"])[0]
                rows = catalog.fonts_for(channel)
                if not rows:
                    catalog.prepare_catalog(cfg, allow_cloud=False)
                    rows = catalog.fonts_for(channel)
                self._json({"ok": True, "channel": channel, "count": len(rows), "fonts": rows})
            elif path == "/api/tag-presets":
                self._json({"ok": True, "presets": smart_tag.tag_presets()})
            elif path == "/api/tag-pools":
                pools = pools_from_config(cfg)
                self._json({"ok": True, **pools.stats(), "cloud": pools.tag_cloud(60),
                            "dimensions": pools.dimensions})
            elif path == "/api/tags":
                pools = pools_from_config(cfg)
                self._json({"ok": True,
                            "suggestions": pools.suggest(q.get("q", [""])[0],
                                                         int(q.get("limit", ["14"])[0] or 14))})
            elif path == "/api/hot-lines":
                from ugi_core import load_hot_lines
                lines = load_hot_lines()
                self._json({"ok": True, "name": "内置语句池",
                            "lines": lines, "count": len(lines)})
            elif path == "/api/segment":
                text = q.get("text", [""])[0]
                import quick_cut
                tokens = quick_cut.cut(text)
                self._json({"ok": True, "text": text, "tokens": tokens,
                            "segment": " / ".join(tokens),
                            "engine": quick_cut.engine()})
            elif path == "/api/smart-tag":
                text = q.get("text", [""])[0]
                topk = int(q.get("topk", ["6"])[0] or 6)
                follow = q.get("follow", ["1"])[0] not in ("0", "false", "no")
                raw_tokens = q.get("tokens", [""])[0]
                tokens = ([x.strip() for x in raw_tokens
                           .replace("，", "/").replace(",", "/").replace("、", "/").split("/")
                           if x.strip()] if raw_tokens else None)
                self._json({"ok": True,
                            **smart_tag.tags_for_text(text, topk, follow, tokens)})
            elif path == "/api/font-spec":
                # 只读已缓存基准；传 paths 时补测这几个字体。全量重建走命令行。
                paths = [p for p in q.get("paths", [""])[0].split(",") if p.strip()]
                rows = font_spec.rows(paths or None, int(cfg.get("font_index", 0)))
                self._json({"ok": True, **font_spec.stats(), "rows": rows})
            elif path == "/api/license":
                self._json({"ok": True, **license_info(cfg["api"].get("ugi_key"))})
            elif path == "/api/usage":
                tag = usage.default_tag_from_config(cfg)
                # 允许 GET 带 cycle= 周期头做一次轻量同步（平台透传场景）
                marker = (q or {}).get("cycle", [""])[0]
                synced = usage.sync_cycle(tag, marker) if marker else None
                self._json({"ok": True, **usage.status(tag), "sync": synced})
            elif path == "/api/state":
                self._json({"ok": True, **state_snapshot()})
            elif path == "/api/check":
                self._json({"ok": PILLOW_OK, "config": public_config(cfg),
                            "dirs": ensure_dirs(cfg), "catalog": catalog.status(),
                            "tag_pools": pools_from_config(cfg).stats(),
                            "font_spec": font_spec.stats(),
                            "hint": "" if PILLOW_OK else PILLOW_HINT})
            elif path == "/api/docs":
                name = safe_filename(q.get("name", ["user-guide"])[0], 60)
                doc = DOC_DIR / f"{name}.md"
                if not doc.is_file():
                    doc = DOC_DIR / "README.md"
                self._json({"ok": doc.is_file(), "name": doc.name,
                            "markdown": doc.read_text(encoding="utf-8") if doc.is_file() else ""})
            elif path == "/api/preview":
                f = Path(q.get("file", [""])[0]).resolve()
                root = Path(str(cfg.get("output_dir") or "")).resolve()
                if not f.is_relative_to(root) or not f.is_file() or f.suffix.lower() != ".png":
                    self._json({"ok": False, "error": "图片不在输出目录内"}, 403)
                    return
                self._bytes(f.read_bytes(), "image/png")
            elif path == "/api/open-folder":
                target = Path(str(cfg.get("output_dir") or SKILL_DIR))
                target.mkdir(parents=True, exist_ok=True)
                if sys.platform == "win32":
                    os.startfile(str(target))  # noqa: S606
                elif sys.platform == "darwin":
                    os.system(f'open "{target}"')
                else:
                    os.system(f'xdg-open "{target}"')
                self._json({"ok": True, "path": str(target)})
            else:
                self._json({"ok": False, "error": f"未知接口: {path}"}, 404)
        except (BadRequest, truetype_api.UgiApiError) as exc:
            self._json({"ok": False, "error": str(exc)}, 400)
        except Exception as exc:  # noqa: BLE001
            self._json({"ok": False, "error": str(exc)}, 500)

    # ------------------------------------------------------------- POST
    def do_POST(self):  # noqa: N802
        path = urlparse(self.path).path
        try:
            body = self._body()
            cfg = load_config(CONFIG_PATH)
            if path == "/api/config":
                incoming = body.get("config") if isinstance(body.get("config"), dict) else body
                for k, v in incoming.items():
                    if k not in cfg or v is None:
                        continue
                    if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                        cfg[k].update(v)
                    else:
                        cfg[k] = v
                cfg["api"].pop("ugi_direction", None)
                # 用户改过文本框才视为 custom；否则启动时仍自动载入内置语句池
                if "text" in incoming:
                    from ugi_core import load_hot_lines
                    same = str(incoming.get("text") or "").strip() == "\n".join(load_hot_lines())
                    cfg["text_source"] = "builtin" if same else "custom"
                # work-fonts 与 selected_fonts 始终是同一份当前选择字体
                wf = [str(x) for x in (cfg.get("work_fonts") or []) if str(x).strip()]
                sf = [str(x) for x in (cfg.get("selected_fonts") or []) if str(x).strip()]
                cfg["work_fonts"] = wf or sf
                cfg["selected_fonts"] = list(cfg["work_fonts"])
                save_config(cfg, CONFIG_PATH)
                cfg = load_config(CONFIG_PATH)   # 回读，响应与磁盘严格一致
                self._json({"ok": True, "config": public_config(cfg),
                            "dirs": ensure_dirs(cfg, create=True),
                            "license": license_info(cfg["api"].get("ugi_key")),
                            "font_spec": font_spec.stats(),
                            "note": "已写入 config.json；端口改动需重启服务"})
            elif path == "/api/catalog":
                allow = body.get("cloud", cfg["api"].get("auto_fetch_cloud", True))
                result = catalog.prepare_catalog(cfg, force=True, allow_cloud=bool(allow),
                                                 background=True)
                self._json({"ok": True, **result})
            elif path == "/api/usage/reset":
                # 计数器整体重置：次数与时间同属 assets/zwcnt.pkl，一次落盘清零。
                # 与 /api/reset（只清任务进度、不动用量）严格区分。
                tag = usage.resolve_tag(body.get("tag") or usage.default_tag_from_config(cfg))
                hard = str(body.get("hard", "")).lower() in ("1", "true", "yes")
                st = usage.reset(tag, hard=hard)
                add_log(f"用量计数器已重置：{tag} → 0/{st.get('cap')} 张"
                        f"（次数与首次/末次时间一并清零{'，含周期标识' if hard else ''}）")
                self._json({"ok": True, "hard": hard, **st})
            elif path == "/api/usage/sync":
                # 平台/服务端下发「周期标识」的入口。
                # 标识变化 => 新周期 => 计数器清零 + 重新激活；不感知支付动作、
                # 不判断是否到期（授权租期与到期关停由平台负责）。
                tag = usage.resolve_tag(body.get("tag") or usage.default_tag_from_config(cfg))
                marker = (body.get("cycle") or body.get("cycle_end")
                          or body.get("cycle_id") or body.get("CycleEndTime"))
                force = str(body.get("force", "")).lower() in ("1", "true", "yes")
                res = usage.reactivate(tag) if (force and not marker) else \
                    usage.sync_cycle(tag, marker, force=force)
                if res.get("changed"):
                    add_log(f"检测到新订阅周期（{res['reason']}）：用量计数器已重置")
                self._json({"ok": True, **res})
            elif path == "/api/work-fonts":
                spec = body.get("specified_tag")
                if spec is None:
                    spec = cfg.get("specified_tag", "")
                tags = ",".join(split_tags([
                    input_tags(body.get("tags") or cfg.get("smart_tag") or ""),
                    input_tags(spec)]))
                ch = str(body.get("channel") or cfg.get("channel") or "local")
                top_n = max(1, min(200, int(body.get("top_n") or cfg.get("tag_top_n") or 12)))
                available = catalog.get_catalog().get("merged") or []
                same = [r for r in available if r.get("source") == ch] or available
                # 与 smart_tag 策略共用同一挑选口径，界面所见即出图所用
                ranked = render_engine.rank_fonts_by_tag(cfg, tags, same, top_n)
                vals = [str(r.get("value") or r.get("name") or "") for r in ranked]
                vals = [v for v in vals if v][:top_n]
                self._json({"ok": True, "tags": tags, "channel": ch,
                            "work_fonts": vals, "count": len(vals),
                            "records": ranked[:top_n]})
            elif path == "/api/segment":
                text = str(body.get("text") or "")
                import quick_cut
                tokens = quick_cut.cut(text)
                self._json({"ok": True, "text": text, "tokens": tokens,
                            "segment": " / ".join(tokens), "engine": quick_cut.engine()})
            elif path == "/api/smart-tag":
                text = str(body.get("text") or "")
                topk = int(body.get("topk") or 6)
                follow = bool(body.get("follow", True))
                raw = body.get("tokens")
                tokens = None
                if isinstance(raw, list):
                    tokens = [str(x).strip() for x in raw if str(x).strip()]
                elif isinstance(raw, str) and raw.strip():
                    tokens = [x.strip() for x in raw
                              .replace("，", "/").replace(",", "/").replace("、", "/").split("/")
                              if x.strip()]
                self._json({"ok": True,
                            **smart_tag.tags_for_text(text, topk, follow, tokens)})
            elif path == "/api/tag-match":
                pools = pools_from_config(cfg)
                top_n = int(body.get("top_n") or cfg.get("tag_top_n") or 12)
                result = pools.match(body.get("tags") or "", top_n=top_n)
                available = catalog.get_catalog().get("merged") or []
                result["ranked"] = pools.rank_available(body.get("tags") or "", available, top_n)
                result["work_fonts"] = [str(r.get("value") or r.get("name") or "")
                                        for r in result["ranked"]][:top_n]
                self._json({"ok": True, **result})
            elif path == "/api/font-spec":
                index = int(body.get("font_index") or cfg.get("font_index") or 0)
                paths = [str(p) for p in (body.get("paths") or []) if str(p).strip()]
                created = font_spec.ensure(paths, index) if paths else []
                self._json({"ok": True, **font_spec.stats(), "created": len(created),
                            "rows": font_spec.rows(paths or None, index)})
            elif path == "/api/probe":
                ep = str(body.get("endpoint") or cfg["api"].get("ugi_endpoint")
                         or truetype_api.DEFAULT_ENDPOINT)
                font = str(body.get("font") or "")
                if not font:
                    cloud = catalog.fonts_for("cloud")
                    font = cloud[0]["value"] if cloud else truetype_api.DEFAULT_FONT
                raw, info = truetype_api.render_one(
                    ep, str(body.get("text") or "元字库"), font,
                    size=int(body.get("size") or cfg.get("font_size") or 160),
                    fg=str(cfg["api"].get("ugi_fg") or "FFFFFF"),
                    bg=str(cfg["api"].get("ugi_bg") or "000000"),
                    output_format=str(cfg["api"].get("ugi_output_format") or "file"),
                    key=str(body.get("key") or cfg["api"].get("ugi_key") or ""),
                    timeout=float(body.get("timeout") or cfg["api"].get("ugi_timeout") or 40),
                    insecure=bool(cfg["api"].get("ugi_insecure")))
                mask, spec = truetype_api.to_white_mask(raw)
                self._json({"ok": True, **spec, "font": font, "direction": "ltr",
                            "endpoint": ep, "info": info,
                            "preview": "data:image/png;base64," + base64.b64encode(mask).decode("ascii"),
                            "note": "仅测试连通与字形，未写入任何文件"})
            elif path == "/api/render":
                with LOCK:
                    if STATE["status"] == "running":
                        busy = ("任务正在结束，请等收尾完成再生成"
                                if STATE.get("stopping")
                                else "已有任务正在运行，请先点「结束」再生成")
                        self._json({"ok": False, "error": busy}, 409)
                        return
                # 周期校验：仅当服务端周期标识变化时重新激活 + 清零。
                # 平台托管授权租期，Skill 不判断到期、不中断服务。
                utag = usage.default_tag_from_config(cfg)
                marker = body.get("cycle") or body.get("cycle_end")
                cycle_sync = usage.sync_cycle(utag, marker) if marker else None
                if cycle_sync and cycle_sync.get("changed"):
                    add_log(f"检测到新订阅周期（{cycle_sync['reason']}）：用量计数器已重置")
                # 用量校验：只看额度是否超出「110% + 1 张」硬上限
                chk = usage.can_render(utag)
                with LOCK:
                    # 状态轮询里带上用量快照：前端一个 /api/state 就能同时刷新
                    # 进度与「次数 / 剩余时间」，不靠额外请求（避免读到旧值）
                    STATE["usage"] = chk["status"]
                if not chk["allowed"]:
                    self._json({"ok": False, "error": chk["message"],
                                "usage": chk["status"]}, 403)
                    return
                for k, v in (body.get("options") or {}).items():
                    if v is None or k not in cfg:
                        continue
                    if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                        cfg[k].update(v)
                    else:
                        cfg[k] = v
                text = str(body.get("text") if "text" in body else cfg.get("text") or "")
                matrix = str(body.get("render_matrix", "")).lower() in ("1", "true", "yes")
                if matrix:
                    # 生成口径固定：只出「当前文本行」× 字体策略给出的字体序列；
                    # 前端传的就是当前文本行，即使传入多行也只取首行，避免误出多组。
                    first_line = str(text or "").splitlines()
                    first_line = first_line[0] if first_line else ""
                    if not first_line.strip():
                        raise BadRequest("当前文本行为空：请在文本池里输入或选中一行")
                    text = first_line.strip()
                    cfg["output_modes"] = ["single"]
                from ugi_core import build_render_jobs, resolve_output_modes
                jobs = build_render_jobs(text, cfg)
                if not jobs:
                    raise BadRequest("文本框为空：请至少输入一行文字")
                if not PILLOW_OK and cfg.get("channel") == "local":
                    raise BadRequest(PILLOW_HINT)
                ensure_dirs(cfg, create=True)
                total = len(jobs)
                font_note = ""
                if matrix:
                    from font_selector import FontSelector
                    records = catalog.get_catalog().get("merged") or []
                    sel = FontSelector(cfg, records, pools_from_config(cfg))
                    plan = render_engine.matrix_font_plan(
                        cfg, sel, str(cfg.get("channel") or "local"), text)
                    count = len(plan["records"])
                    if not count:
                        raise BadRequest("当前选择字体为空或没有可用的字体文件，请先在字库池选择字体")
                    total = len(jobs) * count
                    font_note = plan.get("note", "")
                start_worker(text, cfg, render_opts={"render_matrix": True} if matrix else None,
                             usage_tag=utag)
                self._json({"ok": True, "status": "running", "total": total,
                            "output_dir": cfg["output_dir"],
                            "font_mode": cfg.get("font_mode"),
                            "font_mode_note": font_note,
                            "char_gap": cfg.get("char_gap"),
                            "work_fonts": len(cfg.get("work_fonts") or []),
                            "render_matrix": matrix, "mask_margin": cfg.get("mask_margin"),
                            "output_modes": resolve_output_modes(cfg),
                            "usage": chk["status"], "reminder": chk["status"].get("message", ""),
                            "cycle_sync": cycle_sync,
                            "groups": len({j["group"] for j in jobs})})
            elif path == "/api/pause":
                want = body.get("paused", True)
                want = bool(want) if not isinstance(want, str) else want not in ("0", "false", "no")
                with LOCK:
                    running = STATE["status"] == "running"
                    stopping = bool(STATE.get("stopping"))
                if not running:
                    self._json({"ok": False, "error": "当前没有正在运行的任务",
                                "status": STATE["status"], "paused": False}, 409)
                    return
                if stopping:
                    # 已经点过「结束」：不允许再暂停/继续，否则按钮状态会来回跳
                    self._json({"ok": False, "error": "任务正在结束，不能再中断/继续",
                                "status": "running", "paused": False}, 409)
                    return
                if want:
                    PAUSE.set()
                else:
                    PAUSE.clear()
                with LOCK:
                    STATE["paused"] = want
                add_log("已暂停任务（点「继续」可恢复）" if want else "已继续任务")
                self._json({"ok": True, "paused": want, "status": "running"})
            elif path == "/api/stop":
                CANCEL.set()
                PAUSE.clear()
                with LOCK:
                    STATE["paused"] = False
                    running = STATE["status"] == "running"
                    # 先把「正在结束」挂上：前端据此立刻把中断按钮复位，
                    # 不必等最后一张图（云端慢字体可能要几秒）跑完。
                    if running:
                        STATE["stopping"] = True
                add_log("已请求结束当前任务" if running else "当前没有运行中的任务")
                utag = usage.default_tag_from_config(cfg)
                self._json({"ok": True, "stopping": running,
                            "status": STATE["status"],
                            "usage": usage.status(utag)})
            elif path == "/api/reset":
                CANCEL.set()
                PAUSE.clear()
                with LOCK:
                    STATE.update({"status": "idle", "done": 0, "total": 0, "percent": 0,
                                  "current": "", "paused": False, "stopping": False,
                                  "logs": [], "results": [],
                                  "errors": [], "last_error": "", "runtime": {}})
                self._json({"ok": True, "usage": usage.status(usage.default_tag_from_config(cfg))})
            else:
                self._json({"ok": False, "error": f"未知接口: {path}"}, 404)
        except PayloadTooLarge as exc:
            self._json({"ok": False, "error": str(exc)}, 413)
        except BadRequest as exc:
            self._json({"ok": False, "error": str(exc)}, 400)
        except truetype_api.UgiApiError as exc:
            self._json({"ok": False, "error": str(exc)}, 400)
        except Exception as exc:  # noqa: BLE001
            self._json({"ok": False, "error": str(exc)}, 500)


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def main() -> int:
    global CONFIG_PATH
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, OSError):
        pass
    ap = argparse.ArgumentParser(description="UGI Font 本地 API 服务")
    ap.add_argument("--config", default=str(CONFIG_PATH))
    ap.add_argument("--host", default=None)
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--open", action="store_true", dest="open_browser")
    ap.set_defaults(open_browser=False)
    args = ap.parse_args()
    # 自定义 --config 必须同时驱动启动与每个请求，否则 GET/POST /api/config 会读写默认文件
    CONFIG_PATH = Path(args.config).resolve()

    cfg = load_config(CONFIG_PATH)
    host = args.host or cfg["api"].get("host", "127.0.0.1")
    port = args.port or int(cfg["api"].get("port", 8766))
    if host not in ("127.0.0.1", "localhost", "::1"):
        print(f"[提示] 当前绑定 {host}，仅建议在受信任网络中使用")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.settimeout(0.35)
        if probe.connect_ex(("127.0.0.1" if host == "localhost" else host, port)) == 0:
            print(f"[错误] 端口 {port} 已被占用。可改用 --port 8767")
            return 1
    ensure_dirs(cfg, create=True)
    url = f"http://{host}:{port}/"
    print("=" * 68)
    print("  UGI Font · 标题字 text-mask 生成器")
    print("=" * 68)
    print(f"  设置界面 : {url}")
    print(f"  本地 API : {url}api")
    print(f"  Key      : {cfg['api'].get('ugi_key')}  ({license_info(cfg['api'].get('ugi_key'))['label']})")
    print(f"  UGI-API  : {cfg['api'].get('ugi_endpoint')}")
    print(f"  输出目录 : {cfg['output_dir']}（平铺，不建子目录）")
    print(f"  字体策略 : {FONT_MODE_LABELS.get(cfg.get('font_mode'), cfg.get('font_mode'))}"
          f" · 留边 {cfg.get('mask_margin')}px")
    print(f"  Pillow   : {'已就绪' if PILLOW_OK else '未安装 → ' + PILLOW_HINT}")
    print("  启动任务：自动下载云端字体清单 + 构建本档 mtag 白名单…")
    print("=" * 68)
    threading.Thread(target=startup_tasks, args=(cfg,), name="ugi-startup", daemon=True).start()
    if args.open_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        srv = Server((host, port), Handler)
        srv.serve_forever()
    except OSError as exc:
        print(f"[错误] 服务启动失败: {exc}")
        return 1
    except KeyboardInterrupt:
        print("\n服务已停止。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
