#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""平台付费技能的无界面渲染入口。

与本地工作台的区别：不启动 127.0.0.1 服务、不扫描本机字体目录、不读取
config.json 里的 d:\\ 路径、不依赖 UI。只走 UGI-API 云通道，渲染结果直接
以 PNG 字节 / base64 返回，适合在平台托管的运行环境里被调用。

契约：一行文本 × N 个字体 = N 张 32 位 RGBA 白字透明底 text-mask PNG。
响应里**同时回传次数与时间**（``usage``：已用 / 月上限 / 剩余 / 剩余天数 /
首次使用时间 / 最近活动时间 / 周期标识），平台侧其他 skill 调完一次就能
把「图 + 额度」一起拿到，不必再查一次。
订阅权限、计费与结算由平台负责；本模块不做鉴权、不联网上报，
只按实际出图张数把次数累计到 ``assets/zwcnt.pkl``（次数与时间同一个文件）。

用法：
  python scripts/paid_entry.py --text "标题字" --fonts "字体A,字体B" --json
  python scripts/paid_entry.py --text "标题字" --fonts "字体A" --out-dir ./out
  echo '{"text":"标题字","fonts":["字体A"]}' | python scripts/paid_entry.py --stdin --json
"""
from __future__ import annotations

import argparse
import base64
import io
import json
import os
import re
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import truetype_api  # noqa: E402
import usage as usage_mod  # noqa: E402
from ugi_core import BUILTIN_KEY, load_mtag_raw, norm_font_id, resolve_tagfile  # noqa: E402

# =============================================================================
#  ⬇⬇⬇  版本发布占位（各档次发布 / 改版时，只改这一块）  ⬇⬇⬇
#  现在「产品名 / 定位 / 月费 / 月上限」都由 mtag 清单**自动确定**，
#  本文件只剩一件事必须改：EDITION_MTAG 指到本档次的授权清单文件（或目录）。
#    1) EDITION_MTAG     —— 本档次的授权字体清单（pkl / json / 目录）。
#                           不同档次用不同文件 -> 白名单不同 -> 档次不同。
#    2) EDITION_ID/NAME  —— 由清单记录数自动定档后写入；下方常量只是
#                           清单读不到时的兜底值，正常情况下不用手改。
#    3) EDITION_KEY_HINT —— 默认 Key 提示（实际 Key 走环境变量 UGI_FONT_KEY）
#  改版流程：复制整个技能目录 -> 替换 assets 下对应 mtag 文件 -> 重新打包上架。
# =============================================================================
EDITION_MTAG = "assets/zwfnt26mtag_v1x.pkl"   # 本档次授权清单（白名单 + 定档依据）
EDITION_KEY_HINT = "ugi-free-2026-12-12（仅供本机自检；正式 Key 用 UGI_FONT_KEY）"
EDITION_FALLBACK_ID = "ugi-font1700"          # 清单缺失时的兜底档位
EDITION_FALLBACK_NAME = "UGI 字库 1700+"

# 产品身份：按 mtag 清单的记录数自动定档（2 / 20 / 100 / 500 / 900 / 1700+）
PRODUCT = usage_mod.detect_product({"tag_file": EDITION_MTAG})
EDITION_ID = PRODUCT["sku"] or EDITION_FALLBACK_ID
EDITION_NAME = PRODUCT["display_name"] or EDITION_FALLBACK_NAME
# =============================================================================

_SEP = re.compile(r"[,，;；、\s]+")


def load_edition_whitelist() -> set[str]:
    """读取本档次 mtag 授权清单，返回归一化字体 id 集合（白名单）。"""
    raw = load_mtag_raw(resolve_tagfile(EDITION_MTAG))
    return {norm_font_id(k) for k in raw}


def split_fonts(value) -> list[str]:
    """把人工输入的字体名按逗号 / 分号 / 顿号 / 空白拆开。"""
    if isinstance(value, (list, tuple, set)):
        parts: list[str] = []
        for item in value:
            parts.extend(_SEP.split(str(item or "")))
    else:
        parts = _SEP.split(str(value or ""))
    seen: set[str] = set()
    out: list[str] = []
    for p in parts:
        p = p.strip()
        if p and p not in seen:
            seen.add(p)
            out.append(p)
    return out


def build_cfg(size: int = 160, margin: int = 3, endpoint: str = "",
              key: str = "", timeout: float = 40.0) -> dict:
    """构造最小运行配置，完全不触碰本地目录与 config.json。"""
    return {
        "channel": "cloud",
        "font_size": max(1, int(size)),
        "mask_margin": max(0, min(16, int(margin))),
        "char_gap": 0,
        "font_interval": 0.1,          # 每张图之间固定 0.1s（与工作台一致）
        "api": {
            "ugi_endpoint": endpoint or truetype_api.DEFAULT_ENDPOINT,
            "ugi_key": key or os.environ.get("UGI_FONT_KEY") or BUILTIN_KEY,
            "ugi_fg": "FFFFFF",
            "ugi_bg": "000000",
            "ugi_output_format": "file",
            "ugi_timeout": float(timeout),
            "ugi_insecure": False,
            "ugi_denoise": True,
        },
    }


def usage_tag() -> str:
    """本档次的 SKU：次数与时间都记在 assets/zwcnt.pkl 的这一个 key 下。"""
    return usage_mod.resolve_tag(EDITION_ID)


def render(text: str, fonts: list[str], cfg: dict) -> tuple[list[dict], list[str]]:
    """逐字体渲染，返回 (PNG 字节与尺寸列表, 被白名单过滤掉的字体名)。

    只渲染本档次白名单（mtag 授权）内的字体；非授权字体被跳过，不报错，
    以保证「每个档次只能使用白名单当中的字体」。
    """
    endpoint = str(cfg["api"]["ugi_endpoint"])
    key = str(cfg["api"]["ugi_key"])
    whitelist = load_edition_whitelist()
    try:
        font_gap = max(0.0, float(cfg.get("font_interval", 0.01) or 0))
    except (TypeError, ValueError):
        font_gap = 0.01
    images: list[dict] = []
    skipped: list[str] = []
    for font in fonts:
        if whitelist and norm_font_id(font) not in whitelist:
            skipped.append(font)
            continue
        # 不同字体之间输出间隔（秒）：第一张不等，之后每换一个字体等 font_gap
        if images and font_gap > 0:
            time.sleep(font_gap)
        img = truetype_api.render_mask(endpoint, text, font, cfg, key).convert("RGBA")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        images.append({"font": font, "width": img.width, "height": img.height,
                       "png": buf.getvalue()})
    return images, skipped


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="UGI Font 平台付费入口：文本 × 字体 -> 透明 PNG")
    ap.add_argument("--text", default="", help="单行文本；行内换行写 \\n")
    ap.add_argument("--fonts", default="", help="字体名，逗号 / 分号 / 顿号 / 空白分隔")
    ap.add_argument("--stdin", action="store_true", help="从 stdin 读 JSON：text / fonts / size / margin")
    ap.add_argument("--size", type=int, default=160, help="基准字号")
    ap.add_argument("--margin", type=int, default=3, help="裁边后四周留边 px（0-16）")
    ap.add_argument("--key", default="", help="UGI-API Key；默认取环境变量 UGI_FONT_KEY")
    ap.add_argument("--endpoint", default="", help="UGI-API 渲染端点")
    ap.add_argument("--timeout", type=float, default=40.0)
    ap.add_argument("--out-dir", default="", help="把 PNG 写到目录；不传则用临时目录")
    ap.add_argument("--json", action="store_true", help="stdout 输出含 png_base64 的 JSON")
    return ap


def main() -> int:
    args = build_parser().parse_args()
    payload: dict = {}
    if args.stdin:
        try:
            payload = json.loads(sys.stdin.read() or "{}")
        except json.JSONDecodeError as exc:
            print(json.dumps({"ok": False, "error": f"stdin JSON 解析失败: {exc}"},
                             ensure_ascii=False), file=sys.stdout)
            return 1
        if not isinstance(payload, dict):
            print(json.dumps({"ok": False, "error": "stdin 需要 JSON 对象"},
                             ensure_ascii=False))
            return 1

    text = str(payload.get("text") or args.text or "").strip()
    raw_fonts = payload.get("fonts") if payload.get("fonts") else args.fonts
    fonts = split_fonts(raw_fonts) or [truetype_api.DEFAULT_FONT]
    size = int(payload.get("size") or args.size)
    margin = int(payload.get("margin") if payload.get("margin") is not None else args.margin)

    if not text:
        print(json.dumps({"ok": False, "error": "缺少文本：传 --text 或 stdin 的 text"},
                         ensure_ascii=False))
        return 1

    cfg = build_cfg(size, margin, args.endpoint, args.key, args.timeout)
    tag = usage_tag()
    # 额度闸门：只看是否超出「110% + 1 张」硬上限（租期由平台负责，这里不判到期）
    gate = usage_mod.can_render(tag)
    if not gate["allowed"]:
        print(json.dumps({"ok": False, "error": gate["message"],
                          "edition": EDITION_ID, "edition_name": EDITION_NAME,
                          "usage": gate["status"]}, ensure_ascii=False))
        return 2
    t0 = time.time()
    try:
        images, skipped = render(text, fonts, cfg)
    except Exception as exc:  # noqa: BLE001 - 平台入口统一以结构化错误返回
        print(json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}",
                          "edition": EDITION_ID, "edition_name": EDITION_NAME,
                          "usage": usage_mod.status(tag)}, ensure_ascii=False))
        return 1
    elapsed = round(time.time() - t0, 2)
    # 按实际出图张数计入本月次数；次数与时间同源写在 assets/zwcnt.pkl
    try:
        quota = usage_mod.record(tag, len(images))
    except Exception:  # noqa: BLE001 - 计数失败不吞掉已出的图
        quota = usage_mod.status(tag)
    # 平台侧（其他 skill 调用本技能）一次调用就能拿到：mask + 次数 + 时间 + 产品身份
    meta = {"edition": EDITION_ID, "edition_name": EDITION_NAME,
            "product": PRODUCT,
            "text": text, "count": len(images), "skipped": skipped,
            "elapsed": elapsed, "usage": quota}

    if args.json:
        print(json.dumps({
            "ok": True, "channel": "ugi-api", **meta,
            "images": [{"font": im["font"], "width": im["width"], "height": im["height"],
                        "png_base64": base64.b64encode(im["png"]).decode("ascii")}
                       for im in images],
        }, ensure_ascii=False))
        return 0

    out_dir = Path(args.out_dir or tempfile.mkdtemp(prefix="ugi-paid-"))
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    for i, im in enumerate(images, 1):
        p = out_dir / f"{i:03d}.png"
        p.write_bytes(im["png"])
        paths.append(str(p))
    print(json.dumps({"ok": True, "channel": "ugi-api", **meta,
                      "out_dir": str(out_dir), "files": paths}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
