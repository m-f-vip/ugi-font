#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tag pools built from the mtag authorization file (``assets/zwfnt26mtag_v1x.pkl``).

The pool file describes ~1700 fonts across 7 dimensions (书体类别 / 骨架结构 /
笔画形态 / 中宫重心 / 质感装饰 / 情绪性格 / 应用场景), each with cn_tag and
en_tag lists. This module builds an inverted index normalised_tag -> font_ids,
plus three-level font-id maps (exact / stem / series) so cloud font names with
an ``F`` variant can still match tag-pool entries that only have the ``J``
variant of the same design.

Matching is fully offline: exact hit > substring hit > series expansion.
"""
from __future__ import annotations

import json
import re
import threading
from collections import Counter, defaultdict
from functools import lru_cache
from pathlib import Path

from ugi_core import ASSETS_DIR, norm_font_id, font_id_variants

DIMENSION_WEIGHT = {
    "应用场景": 1.45,
    "情绪性格": 1.35,
    "书体类别": 1.25,
    "质感装饰": 1.15,
    "笔画形态": 1.0,
    "骨架结构": 1.0,
    "中宫重心": 1.0,
}

# The tag file uses a very specific vocabulary. Users, however, type scene
# words like 霓虹 / 赛博朋克 / 水墨 which simply do not exist in the pool.
# This bridge maps those words onto real pool terms (used as SECONDARY queries
# at a discounted weight) so 智能tag模式 actually returns sensible fonts.
TAG_ALIASES: dict[str, list[str]] = {
    "赛博朋克": ["未来感", "科技感", "数字质感", "数字故障质感", "机械感", "像素质感", "3d"],
    "赛博": ["科技感", "未来感", "数字质感", "机械感"],
    "霓虹": ["发光边缘", "未来感", "科技感", "像素质感", "潮流", "锐利"],
    "科技": ["科技感", "未来感", "数字", "机械感"],
    "科技感": ["科技感", "未来感"],
    "未来": ["未来感", "科技感"],
    "故障": ["数字故障质感", "破碎", "digital glitch", "像素化", "裂纹"],
    "glitch": ["digital glitch", "数字故障质感", "破碎质感", "像素化"],
    "国风": ["传统", "复古", "书法", "墨色渐变", "毛笔质感"],
    "水墨": ["墨色渐变", "书法", "传统", "毛笔质感", "手绘质感"],
    "书法": ["书法", "毛笔", "传统"],
    "古风": ["复古", "传统", "书法"],
    "中国风": ["传统", "书法", "复古"],
    "中秋": ["传统", "复古", "装饰", "圆润"],
    "春节": ["传统", "复古", "装饰", "喜庆"],
    "节日": ["装饰", "传统", "童趣"],
    "可爱": ["圆润", "童趣", "卡通", "柔和", "气球"],
    "萌": ["圆润", "童趣", "卡通"],
    "圆体": ["圆润", "气球", "柔和"],
    "儿童": ["童趣", "卡通", "圆润", "活泼"],
    "字幕": ["标题", "简约", "清晰", "现代", "无衬线"],
    "综艺": ["装饰", "立体", "气球", "动感", "醒目"],
    "花字": ["装饰", "立体", "艺术字", "创意", "气球"],
    "片头": ["标题", "动感", "科技感", "未来感"],
    "金属": ["金属", "质感", "锐利"],
    "立体": ["立体", "3d", "三维", "浮雕"],
    "3d": ["3d", "立体", "三维"],
    "极简": ["极简", "简约", "现代"],
    "简约": ["简约", "极简", "现代"],
    "品牌": ["品牌", "logo", "标识"],
    "logo": ["logo", "标识", "品牌"],
    "电商": ["品牌", "创意", "醒目"],
    "游戏": ["游戏", "像素", "机械", "锐利"],
    "电竞": ["游戏", "锐利", "力量感", "机械感", "动感"],
    "二次元": ["卡通", "童趣", "像素", "手绘"],
    "涂鸦": ["涂鸦", "街头", "手绘"],
    "手写": ["手写", "手绘", "毛笔质感"],
    "复古": ["复古", "怀旧", "传统"],
    "怀旧": ["怀旧", "复古"],
    "优雅": ["优雅", "柔和", "曲线"],
    "治愈": ["柔和", "宁静", "圆润"],
    "温暖": ["柔和", "圆润", "童趣"],
    "力量": ["力量感", "硬朗", "锐利"],
    "硬朗": ["硬朗", "力量感", "锐利"],
    "暗黑": ["神秘感", "锐利", "破碎"],
    "恐怖": ["破碎", "裂纹", "神秘感", "锐利"],
    "冰雪": ["雪花", "裂纹", "镂空"],
    "火焰": ["锐利", "动感", "力量感", "破碎"],
    "粒子": ["像素", "颗粒", "点"],
    "渐变": ["渐变", "墨色渐变"],
    "镭射": ["潮流", "未来感", "装饰"],
    "毛玻璃": ["镂空", "柔和", "极简"],
    "金箔": ["金属", "质感", "装饰"],
    "像素": ["像素", "像素化"],
    "破碎": ["破碎", "裂纹", "断裂"],
    "几何": ["几何", "抽象"],
    "抽象": ["抽象", "艺术"],
    "艺术": ["艺术", "创意"],
    "海报": ["海报", "创意设计", "标题"],
    "标题": ["标题", "海报标题"],
    "标题字": ["标题", "艺术字", "装饰"],
    "装饰": ["装饰", "艺术字"],
    "速度": ["动感", "锐利", "力量感"],
    "运动": ["动感", "力量感", "硬朗"],
    "商务": ["简约", "品牌", "现代"],
    "高级感": ["极简", "优雅", "简约"],
    "奢华": ["装饰", "金属", "传统"],
    "浪漫": ["柔和", "优雅", "曲线"],
    "神秘": ["神秘感", "抽象", "锐利"],
    "街头": ["街头", "涂鸦"],
    "潮流": ["潮流", "街头", "创意"],
    "黑体": ["黑体", "无衬线", "现代"],
    "宋体": ["衬线", "传统", "宋"],
    "衬线": ["衬线", "传统"],
    "粗体": ["粗", "力量感", "硬朗"],
    "手写体": ["手写", "手绘"],
    "文艺": ["柔和", "优雅", "手绘"],
    "国潮": ["传统", "复古", "装饰"],
    "禅意": ["极简", "柔和", "宁静"],
}

_PUNCT = re.compile(r"[\s_\-/\\.,;:!?()\[\]{}'\"，。、；：！？（）【】「」《》·]+")


def norm_tag(value: str) -> str:
    return _PUNCT.sub(" ", str(value or "").strip().lower()).strip()


_TAG_SEP = re.compile(r"[,，;；\n\t]+")


def split_tags(value) -> list[str]:
    if isinstance(value, (list, tuple, set)):
        raw: list[str] = []
        for item in value:
            raw.extend(_TAG_SEP.split(str(item or "")))
    else:
        raw = _TAG_SEP.split(str(value or ""))
    out, seen = [], set()
    for x in raw:
        n = norm_tag(x)
        if n and n not in seen:
            seen.add(n)
            out.append(n)
    return out


_INPUT_SEP = re.compile(r"[,，;；、\s]+")


def input_tags(value) -> str:
    """手输 tag 框的分隔符：逗号 / 中文逗号 / 分号 / 顿号 / 空白，统一回逗号串。"""
    if isinstance(value, (list, tuple, set)):
        parts: list[str] = []
        for item in value:
            parts.extend(_INPUT_SEP.split(str(item or "")))
    else:
        parts = _INPUT_SEP.split(str(value or ""))
    return ",".join(x.strip() for x in parts if x.strip())


class TagPools:
    def __init__(self, path: str | Path | None = None):
        self.path = Path(path) if path else (ASSETS_DIR / "zwfnt26mtag_v1x.pkl")
        self.raw: dict = {}
        self.font_tags: dict[str, dict[str, list[str]]] = {}
        self.tag_index: dict[str, set[str]] = defaultdict(set)
        self.tag_dim: dict[str, Counter] = defaultdict(Counter)
        self.tag_display: dict[str, str] = {}
        self.tag_lang: dict[str, str] = {}
        self.stem_index: dict[str, list[str]] = defaultdict(list)
        self.series_index: dict[str, list[str]] = defaultdict(list)
        self.dimensions: list[str] = []
        self.loaded = False
        self.error = ""
        self._keys_cache: list[str] | None = None

    # ------------------------------------------------------------------ load
    def load(self) -> "TagPools":
        if self.loaded:
            return self
        if not self.path.is_file():
            self.error = f"tag 标签文件不存在：{self.path}"
            return self
        try:
            if self.path.suffix.lower() == ".pkl":
                import pickle
                with self.path.open("rb") as fh:
                    self.raw = pickle.load(fh)
            else:
                with self.path.open("r", encoding="utf-8-sig") as fh:
                    self.raw = json.load(fh)
        except (OSError, ValueError, ImportError, EOFError, pickle.UnpicklingError) as exc:
            self.error = f"tag 标签文件读取失败：{exc}"
            return self

        dims: Counter = Counter()
        for fid, body in self.raw.items():
            if not isinstance(body, dict):
                continue
            key = norm_font_id(fid)
            per_dim: dict[str, list[str]] = {}
            for dim, obj in body.items():
                if dim == "id" or not isinstance(obj, dict):
                    continue
                dims[dim] += 1
                tags: list[str] = []
                for lang in ("cn_tag", "en_tag"):
                    for t in (obj.get(lang) or []):
                        n = norm_tag(t)
                        if not n:
                            continue
                        tags.append(n)
                        self.tag_index[n].add(key)
                        self.tag_dim[n][dim] += 1
                        self.tag_lang.setdefault(n, "cn" if lang == "cn_tag" else "en")
                        self.tag_display.setdefault(n, str(t).strip())
                per_dim[dim] = tags
            self.font_tags[key] = per_dim
            variants = font_id_variants(key)
            if len(variants) > 1:
                self.stem_index[variants[1]].append(key)
            if len(variants) > 2:
                self.series_index[variants[2]].append(key)
        self.dimensions = [d for d, _ in dims.most_common()]
        self.loaded = True
        self._keys_cache = list(self.tag_index.keys())
        return self

    # ------------------------------------------------------------------ stats
    def stats(self) -> dict:
        self.load()
        cn = sum(1 for k, v in self.tag_lang.items() if v == "cn")
        return {
            "ok": self.loaded, "file": str(self.path), "error": self.error,
            "fonts": len(self.font_tags), "dimensions": self.dimensions,
            "unique_tags": len(self.tag_index),
            "cn_tags": cn, "en_tags": len(self.tag_index) - cn,
            "series": len(self.series_index), "aliases": len(TAG_ALIASES),
            "bytes": self.path.stat().st_size if self.path.is_file() else 0,
        }

    def tags_of(self, font_value: str) -> list[str]:
        self.load()
        body = self.font_tags.get(norm_font_id(font_value))
        if not body:
            return []
        out, seen = [], set()
        for tags in body.values():
            for t in tags:
                d = self.tag_display.get(t, t)
                if d not in seen:
                    seen.add(d)
                    out.append(d)
        return out

    # ------------------------------------------------------------------ search
    @lru_cache(maxsize=512)
    def _substring_keys(self, tag: str) -> tuple[str, ...]:
        """Candidate index keys sharing a substantial substring with ``tag``."""
        keys = self._keys_cache or list(self.tag_index.keys())
        if len(tag) < 2:
            return tuple(k for k in keys if k == tag)
        hits = []
        for k in keys:
            if k == tag:
                hits.append((k, 3.0))
            elif tag in k:
                hits.append((k, 2.0 * len(tag) / max(1, len(k))))
            elif len(k) >= 2 and k in tag:
                hits.append((k, 1.8 * len(k) / max(1, len(tag))))
        hits.sort(key=lambda x: -x[1])
        return tuple(k for k, _ in hits[:80])

    def expand_alias(self, tag: str) -> list[str]:
        """Secondary pool queries for a user scene word (semantic bridge)."""
        t = norm_tag(tag)
        if t in TAG_ALIASES:
            return list(TAG_ALIASES[t])
        out: list[str] = []
        for key, values in TAG_ALIASES.items():
            k = norm_tag(key)
            if (len(t) >= 2 and t in k) or (len(k) >= 2 and k in t):
                out.extend(values)
        return list(dict.fromkeys(out))

    def match(self, tags, top_n: int = 12, weight_dims: bool = True,
              expand_series: bool = True) -> dict:
        """Return ranked font ids for the given tags.

        Each user tag is scored directly AND through its scene-word aliases at
        a discounted weight, so words like 霓虹 / 赛博朋克 still reach the
        pool terms that actually exist (未来感 / 科技感 / 数字质感 ...).
        Fonts hit by several tags accumulate score, i.e. intersection wins.
        """
        self.load()
        wanted = split_tags(tags)
        scores: Counter = Counter()
        matched: list[dict] = []
        unmatched: list[str] = []
        if not wanted or not self.loaded:
            return {"fonts": [], "scores": {}, "matched_tags": [],
                    "unmatched_tags": wanted, "candidates": 0,
                    "error": self.error or ""}

        for tag in wanted:
            aliases = self.expand_alias(tag)
            queries = [(tag, 1.0)] + [(norm_tag(a), 0.68) for a in aliases]
            seen_q: set[str] = set()
            exact = bool(self.tag_index.get(tag))
            hit_fonts: set[str] = set()
            for query, qw in queries:
                if query in seen_q:
                    continue
                seen_q.add(query)
                direct = self.tag_index.get(query)
                keys = [(query, 3.0)] if direct else []
                keys += [(k, s) for k, s in
                         ((k, self._score_key(query, k)) for k in self._substring_keys(query))
                         if k != query and s > 0.35]
                for key, strength in keys[:45]:
                    dims = self.tag_dim.get(key) or {}
                    w = max((DIMENSION_WEIGHT.get(d, 1.0) * c for d, c in dims.items()),
                            default=1.0) if weight_dims else 1.0
                    for fid in self.tag_index.get(key, ()):
                        scores[fid] += strength * w * qw
                        hit_fonts.add(fid)
            if hit_fonts:
                matched.append({"tag": tag, "exact": exact,
                                "display": self.tag_display.get(tag, tag),
                                "fonts": len(hit_fonts), "aliases": aliases})
            else:
                unmatched.append(tag)

        # Expand to F/J variant siblings of the same series.
        if expand_series and scores:
            bonus: Counter = Counter()
            for fid, s in list(scores.items()):
                variants = font_id_variants(fid)
                for v in variants[1:]:
                    for sib in (self.stem_index.get(v) or []) + (self.series_index.get(v) or []):
                        if sib != fid:
                            bonus[sib] = max(bonus[sib], s * 0.35)
            for fid, s in bonus.items():
                scores[fid] = max(scores[fid], s)

        ranked = [f for f, _ in scores.most_common(max(1, int(top_n)))]
        return {
            "fonts": ranked,
            "scores": {f: round(s, 2) for f, s in scores.most_common(max(1, int(top_n)))},
            "matched_tags": matched, "unmatched_tags": unmatched,
            "candidates": len(scores),
            "error": self.error or "",
        }

    @staticmethod
    def _score_key(tag: str, key: str) -> float:
        if key == tag:
            return 3.0
        if tag in key:
            return 2.0 * len(tag) / max(1, len(key))
        if len(key) >= 2 and key in tag:
            return 1.8 * len(key) / max(1, len(tag))
        return 0.0

    def suggest(self, query: str, limit: int = 14) -> list[str]:
        """Autocomplete for the tag text boxes (Chinese tags first).

        The literal pool contains 13k academic descriptors but none of the
        colloquial scene words users actually type (霓虹 / 赛博朋克 / 水墨 …).
        Those live in TAG_ALIASES and expand inside match(), so they must also
        be offered here, otherwise the 指定tag box gives no suggestion at all.
        """
        self.load()
        q = norm_tag(query)
        scene = [a for a in TAG_ALIASES if not q or q in norm_tag(a)]
        scene.sort(key=lambda a: (0 if q and norm_tag(a).startswith(q) else 1, len(a)))
        keys = self._keys_cache or []
        out = []
        for k in keys:
            if q and q not in k:
                continue
            out.append(k)
        out.sort(key=lambda k: (0 if self.tag_lang.get(k) == "cn" else 1,
                               0 if q and k.startswith(q) else 1,
                               -len(self.tag_index[k]), len(k)))
        scene_top = scene[:min(6, max(0, limit // 2))]
        extras: list[str] = []
        if q:
            # Show which real pool tags a scene word expands into, e.g.
            # 霓虹 -> 发光边缘 / 未来感 / 科技感 …
            for a in scene_top:
                for v in self.expand_alias(a)[:5]:
                    if v not in extras:
                        extras.append(v)
        candidates = scene_top + extras[:max(0, limit // 3)] + [
            self.tag_display.get(k, k) for k in out]
        result: list[str] = []
        for item in candidates:
            if item not in result:
                result.append(item)
            if len(result) >= limit:
                break
        return result

    def tag_cloud(self, limit: int = 60) -> list[dict]:
        self.load()
        rows = [{"tag": self.tag_display.get(k, k), "count": len(v),
                 "lang": self.tag_lang.get(k, "cn")}
                for k, v in self.tag_index.items()]
        rows.sort(key=lambda x: -x["count"])
        return rows[:limit]

    # ------------------------------------------------------------------ ranking
    def rank_available(self, tags, available: list[dict], top_n: int = 12) -> list[dict]:
        """Rank the *currently usable* catalogue records by tag relevance.

        Ranking all 1733 pool fonts first and then intersecting with the 25
        fonts installed on this machine almost always returns nothing. Instead
        we score each available font directly against the query tags (plus
        their scene aliases). Fonts with no tag data inherit their series
        siblings' tags. Zero-score records are appended last so smart_tag mode
        still yields a usable list instead of silently falling back to random.
        """
        self.load()
        wanted = split_tags(tags)
        qw_map: dict[str, float] = {}
        for t in wanted:
            for q, qw in [(t, 1.0)] + [(norm_tag(a), 0.68) for a in self.expand_alias(t)]:
                if self.tag_index.get(q):
                    qw_map[q] = max(qw_map.get(q, 0.0), 3.0 * qw)
                for k, s in ((k, self._score_key(q, k))
                             for k in self._substring_keys(q)[:45]):
                    if k != q and s > 0.35:
                        qw_map[k] = max(qw_map.get(k, 0.0), s * qw)
        scored: list[tuple[float, dict]] = []
        for rec in available:
            fid = norm_font_id(rec.get("value", "") or rec.get("name", ""))
            own: set[str] = set()
            body = self.font_tags.get(fid)
            if body:
                for arr in body.values():
                    own.update(arr)
            else:
                variants = font_id_variants(fid)
                if len(variants) > 2:
                    for sib in (self.series_index.get(variants[2]) or [])[:6]:
                        for arr in (self.font_tags.get(sib) or {}).values():
                            own.update(arr)
            score = 0.0
            for k, w in qw_map.items():
                if k in own:
                    score += w
                else:
                    for o in own:
                        if len(k) >= 2 and (k in o or o in k):
                            score += w * 0.35 * min(len(k), len(o)) / max(len(k), len(o))
                            break
            scored.append((round(score, 3), rec))
        scored.sort(key=lambda x: (-x[0], str(x[1].get("name") or "")))
        return [r for _, r in scored[:max(1, int(top_n))]]

    # ------------------------------------------------------------------ mapping
    def resolve_to_available(self, font_ids: list[str], available: list[dict],
                             limit: int | None = None, tags=None) -> list[dict]:
        """Map tag-pool ids onto the real merged catalogue (cloud + local).

        Three passes: exact id -> same stem (F/J variant) -> same series.
        """
        by_exact: dict[str, list[dict]] = defaultdict(list)
        by_stem: dict[str, list[dict]] = defaultdict(list)
        by_series: dict[str, list[dict]] = defaultdict(list)
        for rec in available:
            v = font_id_variants(rec.get("value", ""))
            if v[0]:
                by_exact[v[0]].append(rec)
            if len(v) > 1:
                by_stem[v[1]].append(rec)
            if len(v) > 2:
                by_series[v[2]].append(rec)
        out, seen = [], set()

        def add(records):
            for r in records:
                k = (r.get("source"), r.get("value"))
                if k not in seen:
                    seen.add(k)
                    out.append(r)
                    if limit and len(out) >= limit:
                        return True
            return False

        for fid in font_ids:
            v = font_id_variants(fid)
            if add(by_exact.get(v[0], [])):
                break
            if len(v) > 1 and add(by_stem.get(v[1], [])):
                break
            if len(v) > 2 and add(by_series.get(v[2], [])):
                break
        # When the top-ranked pool fonts are not installed here, fall back to
        # ranking the installed fonts directly by tag relevance. Without this,
        # smart_tag mode would silently degrade to a random font.
        want = int(limit or min(max(1, len(font_ids)), max(1, len(available))))
        if len(out) < want and tags:
            for r in self.rank_available(tags, available, min(len(available), want * 2)):
                k = (r.get("source"), r.get("value"))
                if k not in seen:
                    seen.add(k)
                    out.append(r)
                    if len(out) >= want:
                        break
        return out


# --------------------------------------------------------------------------- singleton
_POOLS: TagPools | None = None
_LOCK = threading.Lock()


def get_pools(path: str | Path | None = None) -> TagPools:
    global _POOLS
    with _LOCK:
        if _POOLS is None:
            _POOLS = TagPools(path)
        _POOLS.load()
        return _POOLS


def pools_from_config(cfg: dict) -> TagPools:
    raw = str(cfg.get("tag_file") or "assets/zwfnt26mtag_v1x.pkl")
    p = Path(raw)
    if not p.is_absolute():
        p = ASSETS_DIR.parent / raw
    return get_pools(p)
