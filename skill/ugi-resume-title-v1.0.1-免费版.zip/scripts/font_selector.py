#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Four font-selection modes for UGI Font Pro.

  smart_tag  -- DEFAULT. merge 智能tag + 指定tag, match against tag-pools,
                take the ranked font list, and pick one per image.
  random     -- a fresh random font for every image ("每次自动替换字体").
  specified  -- use the explicitly specified font list, rotating per image.

  In every mode the UI's ``work-fonts`` column (``work_fonts``) takes priority:
  it is the pool the user actually sees and edits. When it is non-empty the
  selector ranks from it first, so the work-fonts refresh / tag auto-sync have a real
  effect on rendering instead of being cosmetic.

All modes return the same plan shape so the render engine needs no branching
"""
from __future__ import annotations

import os
import random
from typing import Iterable

from ugi_core import FONT_MODE_LABELS, norm_font_id
from tag_pools import split_tags, input_tags

# Local/offline records used when both catalogues are empty (first run).
EMERGENCY_RECORDS = [
    {"value": "CLAY3_黏土体系列/zw.CLAY3_001F", "name": "zw.CLAY3_001F",
     "group": "内置离线清单", "source": "cloud", "path": "", "stem": "zw.CLAY3_001F"},
    {"value": "zw.FAT4_003J", "name": "zw.FAT4_003J",
     "group": "内置离线清单", "source": "cloud", "path": "", "stem": "zw.FAT4_003J"},
]


def _norm(value: str) -> str:
    return norm_font_id(value)


class FontSelector:
    def __init__(self, cfg: dict, catalog_records: list[dict], pools, seed=None):
        self.cfg = cfg
        self.records = list(catalog_records or [])
        self.pools = pools
        self.rng = random.Random(seed)

    # ------------------------------------------------------------------ pools
    @staticmethod
    def _usable(r: dict, channel: str) -> bool:
        """A cloud record carries only a font id (no ``path``). It must never
        leak into the LOCAL pool, otherwise Pillow cannot load the file and the
        whole batch fails. The cloud channel accepts any record because it only
        needs the id."""
        if channel != "local":
            return True
        p = str(r.get("path") or "")
        return bool(p) and os.path.isfile(p)

    def _renderable(self, records: Iterable[dict], channel: str) -> list[dict]:
        return [r for r in records if self._usable(r, channel)]

    def pool(self, channel: str | None = None) -> list[dict]:
        ch = channel or str(self.cfg.get("channel") or "local")
        wanted = [r for r in self.records if r.get("source") == ch]
        wanted = self._renderable(wanted, ch) or wanted
        if not wanted:
            wanted = [r for r in self.records if r.get("source") != ch]
            wanted = self._renderable(wanted, ch) or wanted
        if not wanted:
            wanted = self._renderable(EMERGENCY_RECORDS, ch) or list(EMERGENCY_RECORDS)
        return wanted

    def work_pool(self, channel: str | None = None) -> list[dict]:
        """Records for the visible ``work-fonts`` column (current selection).

        Match the CURRENT channel first. The merged catalogue also carries cloud
        rows with the same font ids; if one of those claims a key first,
        ``_match_records`` skips the local row and ``_renderable`` later drops
        the cloud row (no ``path``) -- silently losing selected fonts.
        """
        ch = channel or str(self.cfg.get("channel") or "local")
        vals = [str(v) for v in (self.cfg.get("work_fonts") or
                                 self.cfg.get("selected_fonts") or []) if str(v).strip()]
        if not vals:
            return []
        current = [r for r in self.records if r.get("source") == ch]
        found = self._match_records(vals, current)
        if len(found) < len(vals):
            matched = {_norm(str(r.get("value") or r.get("name") or r.get("stem")))
                       for r in found}
            rest = [v for v in vals if _norm(str(v)) not in matched]
            found += self._match_records(rest, self.records or self.pool(ch))
        return self._renderable(found, ch) or found

    def _match_records(self, wanted: Iterable[str], pool: list[dict]) -> list[dict]:
        keys = {_norm(str(w)) for w in wanted if str(w).strip()}
        out = []
        for r in pool:
            cand = {_norm(r.get("value", "")), _norm(r.get("name", "")), _norm(r.get("stem", ""))}
            if keys & cand:
                out.append(r)
                keys -= cand
        return out

    # ------------------------------------------------------------------ plan
    def plan(self, line_text: str = "", index: int = 0, smart_tag: str | None = None) -> dict:
        cfg = self.cfg
        mode = str(cfg.get("font_mode") or "smart_tag")
        if mode not in FONT_MODE_LABELS:
            mode = "smart_tag"
        channel = str(cfg.get("channel") or "local")
        pool = self.pool(channel)
        work = self.work_pool(channel)
        notes: list[str] = []
        smart = cfg.get("smart_tag", "") if smart_tag is None else smart_tag
        tags = split_tags([input_tags(smart), input_tags(cfg.get("specified_tag", ""))])
        match_info: dict = {"fonts": [], "matched_tags": [], "unmatched_tags": []}
        per_item = True
        fonts: list[dict] = []

        if mode == "smart_tag":
            if work:
                # work-fonts 非空时独占渲染字体池；不设数量上限，
                # tag_top_n 只用于 tag 匹配挑字，不截断用户当前选择。
                fonts = list(work)
                notes.append(f"work-fonts 优先：仅使用当前选择 {len(fonts)} 个字体")
                if tags:
                    n = max(1, int(cfg.get("tag_top_n") or 12))
                    m = self.pools.match(tags, top_n=n,
                                         weight_dims=bool(cfg.get("tag_dimension_weight", True)))
                    match_info = m
                    if m.get("unmatched_tags"):
                        notes.append("未命中 tag：" + ",".join(m["unmatched_tags"]))
            elif tags:
                n = max(1, int(cfg.get("tag_top_n") or 12))
                m = self.pools.match(tags, top_n=n,
                                     weight_dims=bool(cfg.get("tag_dimension_weight", True)))
                match_info = m
                # Exact hits first, then fonts actually installed/usable on this
                # machine ranked by tag relevance. The global pool top-N is
                # usually NOT installed, so ranking the pool alone is not enough.
                exact = self.pools.resolve_to_available(
                    m["fonts"], self.records or pool, limit=n, tags=tags)
                ranked = self.pools.rank_available(tags, self.records or pool, n * 2)
                seen = {(r.get("source"), r.get("value")) for r in exact}
                merged = list(exact) + [r for r in ranked
                                        if (r.get("source"), r.get("value")) not in seen]
                same = [r for r in merged if r.get("source") == channel]
                fonts = self._renderable(same, channel) or self._renderable(merged, channel) or merged
                fonts = fonts[:n]
                if m.get("unmatched_tags"):
                    notes.append("未命中 tag：" + ",".join(m["unmatched_tags"]))
                notes.append(f"tag-pools 命中 {m.get('candidates', 0)} 个候选，"
                             f"按当前字库相关度取前 {len(fonts)} 个")
            if not fonts:
                notes.append("work-fonts 为空且 tag 未匹配到字体，已自动回退随机模式")
                fonts = [self.rng.choice(pool)]
                per_item = True
        elif mode == "specified":
            explicit = list(cfg.get("specified_fonts") or [])
            # 指定模式：显式指定字体优先；未指定时直接用 work-fonts；都没有才回退。
            wanted = explicit or [r["value"] for r in work] or list(cfg.get("selected_fonts") or [])
            fonts = self._match_records(wanted, pool)  # current channel, renderable only
            if not fonts and explicit:
                fonts = self._match_records(wanted, self.records or pool)
                if fonts:
                    names = ",".join(str(w) for w in wanted[:3])
                    channel_label = "本地 API" if channel == "local" else "云 API"
                    notes.append(f"指定字体（{names}）不在当前{channel_label}字库中，已回退到当前通道可用字体")
            if fonts:
                notes.append(f"指定字体 {len(fonts)} 个，逐张轮换")
            else:
                notes.append("指定字体为空或未找到，已回退随机模式")
                fonts = [self.rng.choice(pool)]
            per_item = True
        else:  # random
            fonts = [self.rng.choice(work or pool)]
            notes.append("随机模式：每张图自动替换字体"
                         + ("（限 work-fonts）" if work else ""))

        return {
            "mode": mode, "label": FONT_MODE_LABELS[mode], "channel": channel,
            "work_pool": work,
            "fonts": fonts, "per_item": per_item,
            "tags": tags, "match": match_info, "notes": notes,
            "pool_size": len(pool), "index": index,
            "font_label": fonts[0].get("name") if fonts else "—",
        }

    def pick(self, plan: dict, index: int) -> dict:
        """Resolve the concrete font(s) for image #index."""
        mode, channel = plan["mode"], plan["channel"]
        fonts = list(plan["fonts"])
        if not fonts:
            fonts = [self.rng.choice(self.pool(channel))]
        if mode == "random" and plan["per_item"]:
            fonts = [self.rng.choice(plan.get("work_pool") or self.pool(channel))]
        elif mode == "smart_tag" and len(fonts) > 1:
            wp = plan.get("work_pool") or []
            # work-fonts 有多个时按顺序轮换，保证每个选中的字体都真正出图，
            # 而不是随机落回 tag 排名里的其他字体。
            fonts = [wp[index % len(wp)]] if wp else [self.rng.choice(fonts)]
        elif mode == "specified" and len(fonts) > 1:
            fonts = [fonts[index % len(fonts)]]
        return {"fonts": fonts,
                "font_label": fonts[0].get("name", "—"),
                "font_value": fonts[0].get("value", ""),
                "source": fonts[0].get("source", channel)}
