#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UGI Font 白名单字库目录（v2 新架构）。

启动初始化：
  1. 下载 UGI-API 云端字体清单；
  2. 读取本版本 mtag 授权清单（pkl / json，各档次不同文件）；
  3. mtag 授权清单是各档次的「白名单来源」（差异化核心），与云端可达取交集
     -> 本档次真正可展示 / 可使用的「白名单字库」；
  4. 界面仅展示、仅可使用白名单字库内的字体，本地字库已移除。

注意：mtag 决定「你能用哪些字体」（分层），云端决定「当前哪些字体可达」。
因此有效白名单 = mtag ∩ 云端可达；启动时会显示白名单总数与云端可达数。
"""
from __future__ import annotations

import re
import threading
import time
from pathlib import Path

from ugi_core import load_mtag_raw, norm_font_id, resolve_tagfile
from truetype_api import DEFAULT_LISTFONTS, FALLBACK_FONTS, fetch_fonts

# 「字体家族名称」：font-pool 默认只显示 / 搜索这一层，不展开具体字体文件。
_STYLE_SUFFIX = re.compile(
    r"(?i)[ _\-](bold|italic|regular|light|medium|heavy|black|thin|bd|bi|it|rg|"
    r"oblique|semibold|demibold|condensed|narrow|normal|mt|ps|std|ui)$")


def font_family(rec: dict) -> str:
    """Derive a readable family name from a catalogue record."""
    base = str(rec.get("stem") or rec.get("name") or rec.get("value") or "")
    base = base.replace("\\", "/").split("/")[-1]
    base = re.sub(r"\.(ttf|otf|ttc)$", "", base, flags=re.I)
    base = re.sub(r"[_\-]\d{2,4}[A-Za-z]?$", "", base)
    for _ in range(2):
        base = _STYLE_SUFFIX.sub("", base).strip(" _-")
    return base or str(rec.get("name") or rec.get("value") or "字体")


CACHE: dict = {
    "ready": False, "running": False, "ts": 0.0, "elapsed": 0.0,
    "cloud": {}, "merged": [], "groups": {}, "notes": [],
    "tag_coverage": 0,
    "whitelist_total": 0, "whitelist_reachable": 0,
    "mtag_file": "", "mtag_fonts": 0,
}
LOCK = threading.RLock()


def _cloud_records(meta: dict) -> list[dict]:
    out = []
    for f in meta.get("fonts") or []:
        value = str(f.get("value") or f.get("name") or "").strip()
        if not value:
            continue
        out.append({"value": value, "name": str(f.get("name") or value),
                    "group": str(f.get("group") or "云端字库"), "source": "cloud",
                    "path": "", "stem": value.split("/")[-1], "size_mb": 0, "ext": ""})
    return out


def _build(cfg: dict, allow_cloud: bool) -> dict:
    started = time.time()
    notes: list[str] = []

    api = cfg.get("api") or {}
    url = str(api.get("ugi_listfonts") or DEFAULT_LISTFONTS)
    cloud_meta: dict = {"ok": False, "fonts": [], "source": "未启用"}
    if allow_cloud:
        try:
            cloud_meta = fetch_fonts(
                url, timeout=float(api.get("cloud_timeout") or 10),
                key=str(api.get("ugi_key") or ""), refresh=True,
                insecure=bool(api.get("ugi_insecure") or False))
            notes.append(f"云端字库下载完成：{cloud_meta.get('total', 0)} 个字体 · 来源 {cloud_meta.get('source')}")
            if cloud_meta.get("warning"):
                notes.append(str(cloud_meta["warning"]))
            if not cloud_meta.get("key_used"):
                notes.append("云端接口未接受当前 Key，已自动以空 Key 重试")
        except Exception as exc:  # noqa: BLE001
            notes.append(f"云端字库下载失败：{exc}")
            cloud_meta = fetch_fonts(url, offline=True)
    else:
        cloud_meta = fetch_fonts(url, offline=True)
        notes.append("已跳过云端下载（auto_fetch_cloud=false），使用内置离线清单")

    cloud = _cloud_records(cloud_meta)
    cloud_names = {norm_font_id(r["value"]) for r in cloud}

    # ---- 白名单（mtag 授权清单，各档次差异化核心）----
    mtag_path = resolve_tagfile(cfg.get("tag_file"))
    mtag = load_mtag_raw(mtag_path)
    # 白名单以 mtag 为主名单：一条授权记录 = 一款字体。两处去重要同时做对：
    # 1) key 可能是别名（新格式里 zwdzj 的真身是 id=字王大藏经开源字库zwdzj01），
    #    必须按记录的 id 字段归一，否则别名与真身会被当成两款；
    # 2) 云端同一字体可能有多条路径（CLAY3_黏土体系列/zw.CLAY3_001J 与
    #    ugi-fonts/zw.clay3_001J），也要收敛成一条，否则数目虚高。
    def _mtag_id(k, body) -> str:
        if isinstance(body, dict):
            real = body.get("id")
            if real:
                return norm_font_id(real)
            if not body:
                return ""  # 空占位（如 zwfnt26mtag00: {}）不是字体
        return norm_font_id(k)

    mtag_keys = [k for k in dict.fromkeys(_mtag_id(k, v) for k, v in mtag.items()) if k]
    mtag_fonts = len(mtag_keys)
    whitelist_names = set(mtag_keys)

    # 云端记录按归一化 id 去重，每个 id 只留一条代表（优先纯 ASCII 的 ugi-fonts 路径，
    # 渲染取字更稳；中文家族路径只作兜底）。
    cloud_by_norm: dict[str, dict] = {}
    for r in cloud:
        k = norm_font_id(r["value"])
        if not k:
            continue
        old = cloud_by_norm.get(k)
        if old is None or str(r["value"]).isascii():
            cloud_by_norm[k] = r

    # 以 mtag 顺序驱动：每个授权字体只出现一次，且仅当云端可达时才展示。
    reachable = [cloud_by_norm[k] for k in mtag_keys if k in cloud_by_norm]

    merged = reachable
    for r in merged:
        r["family"] = font_family(r)
    groups: dict[str, int] = {}
    for r in merged:
        groups[r["group"]] = groups.get(r["group"], 0) + 1

    # How many catalogue fonts have an exact entry in the tag pool?
    coverage = 0
    try:
        from tag_pools import pools_from_config
        pools = pools_from_config(cfg)
        pools.load()
        known = set(pools.font_tags.keys())
        coverage = sum(1 for r in merged if norm_font_id(r["value"]) in known)
    except Exception:  # noqa: BLE001
        pass

    return {
        "ready": True, "running": False, "ts": time.time(),
        "elapsed": round(time.time() - started, 2),
        "cloud": {"ok": bool(cloud_meta.get("ok")), "total": len(cloud),
                  "source": cloud_meta.get("source", ""),
                  "endpoint": cloud_meta.get("endpoint", url),
                  "groups": cloud_meta.get("groups", {}),
                  "warning": cloud_meta.get("warning", ""),
                  "key_used": bool(cloud_meta.get("key_used"))},
        "merged": merged, "groups": groups,
        "notes": notes, "tag_coverage": coverage,
        "totals": {"cloud": len(cloud), "local": 0, "all": len(merged)},
        "whitelist_total": len(whitelist_names), "whitelist_reachable": len(reachable),
        "mtag_file": str(mtag_path), "mtag_fonts": mtag_fonts,
    }


def prepare_catalog(cfg: dict, force: bool = False, allow_cloud: bool | None = None,
                    background: bool = False) -> dict:
    """Build (or return) the whitelist catalogue.

    ``background=True`` starts a daemon thread and immediately returns the
    current snapshot -- used by the server at startup so it never blocks.
    """
    with LOCK:
        if CACHE.get("ready") and not force:
            return dict(CACHE)
        if CACHE.get("running"):
            return dict(CACHE)
        CACHE["running"] = True
        CACHE["ready"] = False

    do_cloud = bool(cfg.get("api", {}).get("auto_fetch_cloud", True)) if allow_cloud is None else allow_cloud

    def run():
        try:
            result = _build(cfg, do_cloud)
        except Exception as exc:  # noqa: BLE001
            result = {"ready": True, "running": False, "ts": time.time(),
                      "elapsed": 0, "cloud": {"ok": False, "total": 0, "source": ""},
                      "merged": [], "groups": {},
                      "notes": [f"目录构建失败：{exc}"], "tag_coverage": 0,
                      "totals": {"cloud": 0, "local": 0, "all": 0},
                      "whitelist_total": 0, "whitelist_reachable": 0,
                      "mtag_file": "", "mtag_fonts": 0}
        with LOCK:
            CACHE.clear()
            CACHE.update(result)

    if background:
        threading.Thread(target=run, name="ugi-catalog", daemon=True).start()
        with LOCK:
            return dict(CACHE)
    run()
    with LOCK:
        return dict(CACHE)


def get_catalog() -> dict:
    with LOCK:
        return dict(CACHE)


def status() -> dict:
    with LOCK:
        return {
            "ready": bool(CACHE.get("ready")), "running": bool(CACHE.get("running")),
            "ts": CACHE.get("ts", 0), "elapsed": CACHE.get("elapsed", 0),
            "totals": CACHE.get("totals", {"cloud": 0, "local": 0, "all": 0}),
            "cloud": CACHE.get("cloud", {}), "notes": CACHE.get("notes", []),
            "tag_coverage": CACHE.get("tag_coverage", 0),
            "whitelist_total": CACHE.get("whitelist_total", 0),
            "whitelist_reachable": CACHE.get("whitelist_reachable", 0),
            "mtag_file": CACHE.get("mtag_file", ""),
            "mtag_fonts": CACHE.get("mtag_fonts", 0),
        }


def fonts_for(channel: str) -> list[dict]:
    """白名单字库不区分本地 / 云：返回当前档次的白名单字体。

    ``channel`` 参数保留以兼容旧调用，但新架构恒返回白名单（云端可达的授权字体）。
    """
    with LOCK:
        return list(CACHE.get("merged") or [])
