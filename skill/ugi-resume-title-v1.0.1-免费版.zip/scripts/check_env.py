#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UGI Font 环境自检（可选自动安装 Pillow）。"""
from __future__ import annotations

import argparse
import importlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import font_spec  # noqa: E402
import usage  # noqa: E402
from ugi_core import (  # noqa: E402
    DEFAULT_CONFIG_PATH, ensure_dirs, inspect_png, license_info, list_fonts,
    load_config, load_font, load_mtag_raw, render_mask_image, resolve_tagfile,
    single_font_matrix,
)


def main() -> int:
    ap = argparse.ArgumentParser(description="UGI Font 环境自检")
    ap.add_argument("--config", default=str(DEFAULT_CONFIG_PATH))
    ap.add_argument("--install", action="store_true", help="缺少依赖时自动安装")
    ap.add_argument("--selftest", action="store_true", help="渲染测试 mask 并校验留边")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, OSError):
        pass

    report: dict = {"python": sys.version.split()[0], "python_exe": sys.executable,
                    "edition": "ugi-font1700"}
    try:
        import PIL
        from PIL import features
        report["pillow"] = PIL.__version__
        report["freetype"] = features.check("freetype2")
    except ImportError:
        report["pillow"] = None
        if args.install:
            print("正在安装 Pillow …")
            r = subprocess.run([sys.executable, "-m", "pip", "install", "pillow"],
                               capture_output=True, text=True)
            report["pip_install"] = r.returncode == 0
            if r.returncode == 0:
                import PIL
                importlib.reload(importlib.import_module("ugi_core"))
                report["pillow"] = PIL.__version__
                report["freetype"] = True
            else:
                report["hint"] = "自动安装失败，请手动运行: python -m pip install pillow"
        else:
            report["hint"] = "运行 python scripts/check_env.py --install 自动安装"
    for mod in ("numpy", "jieba"):
        try:
            m = importlib.import_module(mod)
            report[mod] = getattr(m, "__version__", "available")
        except ImportError:
            report[mod] = None
            if args.install:
                print(f"正在安装 {mod} …")
                r = subprocess.run([sys.executable, "-m", "pip", "install", mod],
                                   capture_output=True, text=True)
                if r.returncode == 0:
                    try:
                        report[mod] = getattr(importlib.import_module(mod), "__version__", "available")
                    except ImportError:
                        pass
                else:
                    report.setdefault("pip_errors", {})[mod] = (r.stderr or r.stdout or "").strip()[-400:]
    report["jieba_note"] = ("已装 jieba 时用快速分词(HMM 关)+项目用户词典；"
                            "未装时自动降级内置 DAG 分词（零依赖）")

    cfg = load_config(args.config)
    report["font_mode_default"] = cfg.get("font_mode")
    report["mask_margin"] = cfg.get("mask_margin")
    report["config"] = str(Path(args.config).resolve())
    report["dirs"] = ensure_dirs(cfg, create=True)
    report["license"] = license_info(cfg["api"].get("ugi_key"))
    fonts = list_fonts(cfg["font_dir"], cfg.get("recursive_fonts", True))
    report["font_count"] = len(fonts)
    # 字库走云通道：本机不再存字体文件，白名单来自 mtag 授权清单
    try:
        # 按记录 id 去重后的真实字体数（别名 key、空占位不计）
        report["whitelist_count"] = usage._count_fonts_in(
            load_mtag_raw(resolve_tagfile(cfg.get("tag_file"))))
    except Exception:  # noqa: BLE001 - 自检不因清单异常中断
        report["whitelist_count"] = 0
    report["font_names"] = [f["name"] for f in fonts[:8]]
    root = Path(__file__).resolve().parent.parent
    tag_file = resolve_tagfile(cfg.get("tag_file"))
    report["tag_file"] = {"path": str(tag_file), "exists": tag_file.is_file(),
                          "bytes": tag_file.stat().st_size if tag_file.is_file() else 0}
    logo = root / "assets" / "ugi-logo-512.jpg"
    report["logo"] = {"exists": logo.is_file()}
    report["spec_file"] = font_spec.stats()

    if args.selftest and report.get("pillow"):
        fpath = fonts[0]["path"] if fonts else ""
        if not fpath and sys.platform == "win32":
            import os
            cand = Path(os.environ.get("WINDIR", "C:\\Windows")) / "Fonts" / "simhei.ttf"
            fpath = str(cand) if cand.is_file() else ""
        if fpath:
            tmp = Path(tempfile.gettempdir())
            spec = font_spec.spec_for(fpath, int(cfg.get("font_index", 0)))
            report["selftest_spec"] = {"probe": spec.get("probe"), "face": spec.get("face"),
                                       "optical": spec.get("optical"), "side": spec.get("side")}
            scale = max(1.0, min(1.2, float(spec.get("optical") or 1.0)))
            size = int(round(int(cfg.get("font_size", 160)) * scale))
            f = load_font(fpath, size, int(cfg.get("font_index", 0)))
            job = dict(cfg)
            job["font_size"] = size
            margin = int(cfg.get("mask_margin", 3))

            png = tmp / "ugi-font-selftest.png"
            render_mask_image(single_font_matrix(f, ["UGI"]), ["UGI"], job).save(png, format="PNG")
            s = inspect_png(png)
            s["passed"] = (s["mode"] == "RGBA" and min(s["corner_alpha"]) == 0
                           and s["alpha_max"] == 255)
            report["selftest_png"] = s

            # 「一」：细横笔画最容易在裁边 / 缩放时被切或拉变形
            one = render_mask_image(single_font_matrix(f, ["一"]), ["一"], job)
            one_path = tmp / "ugi-font-selftest-one.png"
            one.save(one_path, format="PNG")
            o = inspect_png(one_path)
            iw, ih = o["ink"]
            o.update({"margin": margin, "pad_ok": o["pad"] == [margin] * 4,
                      "horizontal": ih > 0 and iw / ih >= 3.0,
                      "not_clipped": ih >= max(3, int(size * 0.03))})
            o["passed"] = o["pad_ok"] and o["horizontal"] and o["not_clipped"]
            report["selftest_one"] = o

            png.unlink(missing_ok=True)
            one_path.unlink(missing_ok=True)

    report["ok"] = (bool(report.get("pillow")) and report["tag_file"]["exists"]
                    and report["logo"]["exists"]
                    and report.get("selftest_one", {}).get("passed", True))
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("=== UGI Font 环境自检 ===")
        print(f"Python      : {report['python']}")
        print(f"Pillow      : {report.get('pillow') or '未安装'}")
        print(f"numpy       : {report.get('numpy') or '未安装（可选）'}")
        print(f"jieba       : {report.get('jieba') or '未安装 → 内置 DAG 分词'}")
        print(f"Key         : {report['license']['label']}")
        print(f"字体策略    : {report['font_mode_default']} · 留边 {report['mask_margin']}px")
        for key, cn in (("output_dir", "输出目录"),):
            d = report["dirs"][key]
            print(f"{cn:<10}: {d['path']}  {'[存在]' if d['exists'] else '[不存在]'}")
        print(f"白名单字体  : {report.get('whitelist_count', 0)} 个（mtag 授权清单，云通道取字）")
        print(f"字体基准    : {report['spec_file']['fonts']} 个 / "
              f"{report['spec_file']['usable']} 个可用")
        print(f"tag 文件    : {'[存在]' if report['tag_file']['exists'] else '[缺失]'} "
              f"{report['tag_file']['bytes']} bytes")
        print(f"logo        : {'[存在]' if report['logo']['exists'] else '[缺失]'}")
        if "selftest_one" in report:
            o = report["selftest_one"]
            s = report["selftest_png"]
            print(f"自测 mask   : {s['mode']} / {s['bits_per_pixel']}bit / "
                  f"角落alpha={s['corner_alpha']} → {'通过' if s['passed'] else '失败'}")
            print(f"自测「一」 : {o['size'][0]}×{o['size'][1]} / 墨迹 {o['ink'][0]}×{o['ink'][1]} / "
                  f"留边 {o['pad']} → {'通过' if o['passed'] else '失败'}")
        print(f"结论        : {'环境就绪' if report['ok'] else '需要处理上面的问题'}")
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
