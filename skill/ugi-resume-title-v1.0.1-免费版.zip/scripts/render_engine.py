#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UGI Font 渲染管线 —— 文本 → 字体方案（3 种策略）→ text-mask（云 UGI-API）。

v2 新架构：本地字库已移除，所有渲染走 UGI-API 云通道；字体范围由本版本
mtag 授权清单（白名单）与云端字体清单取交集决定。
"""
from __future__ import annotations

import os
import random
import time
from pathlib import Path

from PIL import Image

import catalog
import font_spec
import truetype_api
from font_selector import FontSelector
from smart_tag import tags_for_text
from tag_pools import input_tags, pools_from_config, split_tags
from ugi_core import (
    DEFAULT_CONFIG, FONT_MODES, OUTPUT_MODE_LABELS, PILLOW_HINT, PILLOW_OK,
    build_render_jobs, crop_to_ink, effective_key, join_lines, load_font,
    make_filename, norm_font_id, parse_text,
    render_mask_image, resolve_output_modes, save_rgba, single_font_matrix,
)


# --------------------------------------------------------------------------- runtime

def prepare_runtime(cfg: dict, force: bool = False) -> dict:
    """三步启动准备，全部离线容错。"""
    cat = catalog.prepare_catalog(cfg, force=force)
    pools = pools_from_config(cfg)
    pools.load()
    return {
        "catalog": cat,
        "catalog_status": catalog.status(),
        "tag_pools": pools.stats(),
        "pillow_ok": PILLOW_OK,
    }


# --------------------------------------------------------------------------- canvas

def _apply_canvas(img: Image.Image, cfg: dict) -> Image.Image:
    """云端回图已按墨迹裁好，这里套用与本地一致的留边规则（四边恒等 mask_margin）。"""
    edge = max(0, int(cfg.get("mask_margin", 3)))
    return crop_to_ink(img.convert("RGBA"), edge)


def _system_fallback_path() -> str:
    """合并字库里没有可用本地文件时的兜底字体。"""
    candidates = [
        r"C:\Windows\Fonts\msyhbd.ttc", r"C:\Windows\Fonts\msyh.ttc",
        r"C:\Windows\Fonts\simhei.ttf", r"C:\Windows\Fonts\simsun.ttc",
        "/System/Library/Fonts/PingFang.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for p in candidates:
        if os.path.isfile(p):
            return p
    return ""


def optical_size(path: str, cfg: dict) -> int:
    """按字体基准的字面率做光学校正，让不同字体在同一字号下视觉一致。"""
    base = int(cfg.get("font_size", 160))
    if not cfg.get("optical_fit", True) or not path:
        return base
    try:
        scale = font_spec.optical_scale(path, int(cfg.get("font_index", 0)))
    except Exception:  # noqa: BLE001 - 基准失败不该阻断出图
        return base
    return max(1, int(round(base * max(1.0, min(1.2, scale)))))


def _local_mask(lines, pick, cfg, rng) -> tuple[Image.Image, str, int]:
    findex = int(cfg.get("font_index", 0))
    paths = [str(r.get("path") or "") for r in pick["fonts"] if r.get("path")
             and os.path.isfile(str(r["path"]))]
    if not paths:
        fallback = _system_fallback_path()
        if not fallback:
            raise ValueError("所选记录没有本地字体文件路径，请切换到「云 API 字库」或勾选本地字体")
        paths = [fallback]
    size = optical_size(paths[0], cfg)
    job_cfg = dict(cfg)
    job_cfg["font_size"] = size
    fonts = [load_font(p, size, findex) for p in paths]
    matrix = single_font_matrix(fonts[0], lines)
    return render_mask_image(matrix, lines, job_cfg), paths[0], size


def _cloud_mask(lines, pick, cfg, rng, key: str) -> tuple[Image.Image, str, int]:
    endpoint = str(cfg.get("api", {}).get("ugi_endpoint") or truetype_api.DEFAULT_ENDPOINT)
    value = str(pick.get("font_value") or (pick["fonts"][0].get("value") if pick["fonts"] else ""))
    img = truetype_api.render_mask(endpoint, join_lines(lines), value, cfg, key)
    return _apply_canvas(img, cfg), value, int(cfg.get("font_size", 160))


def render_item(lines, pick, cfg, rng, key: str) -> tuple[Image.Image, dict]:
    if str(cfg.get("channel") or "local") == "cloud":
        base, used, size = _cloud_mask(lines, pick, cfg, rng, key)
        source = "ugi-api"
    else:
        if not PILLOW_OK:
            raise RuntimeError(PILLOW_HINT)
        base, used, size = _local_mask(lines, pick, cfg, rng)
        source = "local"
    return base.convert("RGBA"), {"source": source, "font_used": used,
                                  "width": base.width, "height": base.height,
                                  "font_size": size,
                                  "optical": round(size / max(1, int(cfg.get("font_size", 160))), 3)}


# --------------------------------------------------------------------------- work fonts

def matrix_work_records(cfg: dict, selector: FontSelector, channel: str,
                        log=None, skipped: list | None = None) -> list[dict]:
    """矩阵输出真正可用的 work-font 记录。

    本地通道逐体验证能否加载——磁盘上存在但内容损坏的字体会到第 N 张才抛
    ``unknown file format``，这里提前剔除并记警告，不让一张坏字体拖垮整批。
    被剔除的字体名会追加到 ``skipped``，供界面提示。
    """
    work = selector.work_pool(channel)
    if channel != "local":
        return work

    def probe(records: list[dict]) -> list[dict]:
        usable: list[dict] = []
        for r in records:
            path = str(r.get("path") or "")
            if not path or not os.path.isfile(path):
                if skipped is not None:
                    skipped.append(str(r.get("name") or path or "—"))
                continue
            try:
                load_font(path, 8, int(cfg.get("font_index", 0)))
            except Exception as exc:  # noqa: BLE001
                if log:
                    log(f"警告：字体 {r.get('name') or path} 无法加载（{exc}），已跳过")
                if skipped is not None:
                    skipped.append(str(r.get("name") or path))
                continue
            usable.append(r)
        return usable

    # 矩阵任务只出「当前选择字体」；没有可用字体时交上层报错，不偷偷换一批字体出图
    return probe(work)


def rank_fonts_by_tag(cfg: dict, tags: str, available: list[dict],
                      top_n: int = 12) -> list[dict]:
    """按「智能tag + 指定tag」从白名单可达字体里挑 top_n 个。

    ``/api/work-fonts``（界面「当前选择字体」）与 ``smart_tag`` 策略共用这一
    个口径，保证界面看到的字体就是实际出图的字体。顺序：tag 索引精确命中 →
    同系列映射 → 按相关度补齐；tag 全未命中时也不空手，按目录顺序取前 N。
    """
    top_n = max(1, int(top_n or 12))
    if not available:
        return []
    tags = ",".join(split_tags([input_tags(tags or "")]))
    if not tags:
        return list(available[:top_n])
    pool = pools_from_config(cfg)
    out: list[dict] = []
    seen: set[tuple] = set()

    def add(rows) -> bool:
        for r in rows:
            key = (str(r.get("source") or ""), str(r.get("value") or ""))
            if key not in seen:
                seen.add(key)
                out.append(r)
            if len(out) >= top_n:
                return True
        return False

    try:
        matched = pool.match(tags, top_n=max(top_n * 4, 40))
        if add(pool.resolve_to_available(matched.get("fonts") or [], available,
                                         limit=top_n, tags=tags)):
            return out
        add(pool.rank_available(tags, available, len(available)))
    except Exception:  # noqa: BLE001 - tag 池异常不该阻断出图
        pass
    return (out or list(available[:top_n]))[:top_n]


def manual_font_ids(cfg: dict) -> set[str]:
    """字库池「手动加入」的字体 id —— 权限最高，任何自动同步 / 策略都不能剔除。

    同时保留原始 value 与归一化 id：配置里的字体名可能带路径 / 扩展名 /
    大小写差异，两种都收进来才能稳定命中。
    """
    out: set[str] = set()
    for v in (cfg.get("manual_fonts") or []):
        raw = str(v).strip()
        if not raw:
            continue
        out.add(raw)
        out.add(norm_font_id(raw))
    return out


def matrix_font_plan(cfg: dict, selector: FontSelector, channel: str,
                     text: str = "", log=None, skipped: list | None = None,
                     rng: random.Random | None = None) -> dict:
    """按「字体策略」把「当前选择字体」展开成本次要出的字体序列。

    v2 口径：生成恒为「当前文本行」× 字体序列，每个字体各 1 张 mask。
    三种策略都出「当前选择字体」全集，区别只在顺序与自动重算时机：

      smart_tag -- 默认。其余字体按「智能tag + 指定tag」相关度排序，切行时自动重算
      random    -- 其余字体随机打乱，每次生成顺序不同
      specified -- 全部保持当前顺序，不做自动重算

    **手动加入权限最高**：字库池「加入 →」的字体（``cfg.manual_fonts``）恒置顶、
    恒出图。以前 smart_tag 从整个白名单另挑一批、random 只抽 ``tag_top_n`` 个，
    手动加入的（尤其是与 tag 无关的）字体因此连出图都会被漏掉。

    返回 ``{"records", "mode", "note"}``；``records`` 为空时由上层报错。
    """
    rng = rng or random.Random()
    work = matrix_work_records(cfg, selector, channel, log, skipped)
    mode = str(cfg.get("font_mode") or "smart_tag")
    if mode not in FONT_MODES:
        mode = "smart_tag"
    if not work:
        return {"records": [], "mode": mode, "note": "当前选择字体为空"}
    try:
        top_n = max(1, int(cfg.get("tag_top_n") or 12))
    except (TypeError, ValueError):
        top_n = 12

    manual = manual_font_ids(cfg)

    def is_pinned(r: dict) -> bool:
        v = str(r.get("value") or "")
        return v in manual or norm_font_id(v) in manual

    pinned = [r for r in work if is_pinned(r)]
    rest = [r for r in work if not is_pinned(r)]
    pin_note = f"手动加入 {len(pinned)} 个优先保留" if pinned else "无手动加入"

    if mode == "specified":
        records = pinned + rest
        return {"records": records, "mode": mode,
                "note": f"指定：{len(records)} 个当前选择字体，每个各 1 张；{pin_note}"}

    if mode == "smart_tag":
        tags = ",".join(split_tags([
            input_tags(cfg.get("smart_tag") or ""),
            input_tags(cfg.get("specified_tag") or "")]))
        if not tags:
            tags = str(text or "").strip()      # 没填 tag 时用当前文本行兜底
        # 与 /api/work-fonts 共用同一套挑选口径，但只用它给「非手动」字体排序，
        # 不再从白名单另挑一批，保证界面所见（含手动加入）即出图所用。
        full = list(catalog.get_catalog().get("merged") or work)
        ranked = rank_fonts_by_tag(cfg, tags, full, min(len(full) or top_n, 200))
        order = {norm_font_id(str(r.get("value") or "")): i
                 for i, r in enumerate(ranked)}
        rest_sorted = sorted(
            rest, key=lambda r: order.get(
                norm_font_id(str(r.get("value") or "")), 9999))
        records = pinned + rest_sorted
        return {"records": records, "mode": mode,
                "note": f"智能tag「{tags}」：{pin_note}，其余 {len(rest)} 个按 tag "
                        f"相关度排序，共 {len(records)} 张"}

    if mode == "random":
        records = pinned + rng.sample(rest, len(rest))
        return {"records": records, "mode": mode,
                "note": f"随机：{pin_note}，其余 {len(rest)} 个打乱顺序，共 {len(records)} 张"}

    # 未知策略已在上面归一到 smart_tag；这里兜底不丢字体
    return {"records": pinned + rest, "mode": mode,
            "note": f"{mode}：{len(work)} 个当前选择字体，每个各 1 张；{pin_note}"}

# --------------------------------------------------------------------------- batch

def _gap_sleep(seconds: float, should_stop=None) -> bool:
    """可打断的间隔睡眠：返回 False 表示期间收到了结束请求。

    直接 ``time.sleep(0.1)`` 会让「结束」最多晚 100ms，看起来像按钮没反应；
    这里切成 30ms 一片，逐片检查取消位。
    """
    end = time.time() + max(0.0, float(seconds or 0))
    while True:
        left = end - time.time()
        if left <= 0:
            return True
        if should_stop and should_stop():
            return False
        time.sleep(min(0.03, left))


def batch_render(text: str, cfg: dict, out_dir: str | Path | None = None,
                 progress=None, logger=None, should_stop=None,
                 should_pause=None) -> dict:
    groups = parse_text(text)
    jobs = build_render_jobs(text, cfg)
    if not jobs:
        raise ValueError("文本框为空：请至少输入一行文字")
    out_root = Path(out_dir or cfg.get("output_dir") or DEFAULT_CONFIG["output_dir"])
    out_root.mkdir(parents=True, exist_ok=True)
    started = time.time()
    results, errors, notes = [], [], []
    failed_fonts: list[str] = []      # 结构化：出图失败 / 缺字的字体 value，供前端给替换建议
    done = 0
    used_names: set[str] = set()
    stopped = False
    rng = random.Random()

    def log(msg):
        if logger:
            logger(msg)

    runtime = prepare_runtime(cfg)
    cs = runtime["catalog_status"]
    ps = runtime["tag_pools"]
    log(f"运行时准备：白名单字库 {cs.get('whitelist_reachable', 0)} 套"
        f"（授权 {cs.get('whitelist_total', 0)} 套）· "
        f"tag-pools {ps.get('fonts', 0)} 字体 / {ps.get('unique_tags', 0)} 标签")
    for n in cs.get("notes", []):
        log("目录 · " + n)
    if ps.get("error"):
        log("tag-pools 警告：" + ps["error"])

    pools = pools_from_config(cfg)
    records = catalog.get_catalog().get("merged") or []
    selector = FontSelector(cfg, records, pools)
    tags_info = tags_for_text(text, topk=6, follow=bool(cfg.get("auto_tag_follow", True)))
    log(f"智能tag（首行「{tags_info['first_line']}」）：{tags_info['smart_tag']} "
        f"· 引擎 {tags_info['engine']}")

    key = effective_key(cfg)
    channel = str(cfg.get("channel") or "local")
    matrix = bool(cfg.get("render_matrix"))
    skipped: list[str] = []
    work_records: list[dict] = []
    font_plan = {"mode": "smart_tag", "note": ""}
    if matrix:
        # 字体策略在这里真正参与决策：决定本次用哪些字体、出几张
        font_plan = matrix_font_plan(cfg, selector, channel, text, log, skipped, rng)
        work_records = font_plan["records"]
        if not work_records:
            raise ValueError("work-fonts 为空或没有可用的字体文件，请先在左侧选择字体")
    # 首次使用的字体在这里一次性建立「国」字基准并落盘
    if matrix and channel == "local":
        font_spec.ensure([r.get("path") for r in work_records],
                         int(cfg.get("font_index", 0)), log)

    tasks = [(j, rec) for j in jobs for rec in (work_records or [None])]
    total = len(tasks)
    modes = resolve_output_modes(cfg)
    log(f"按组输出：{len(groups)} 组 × "
        + " / ".join(OUTPUT_MODE_LABELS.get(m, m) for m in modes)
        + f" = {len(jobs)} 个输出单元"
        + (f" × {len(work_records)} 个字体 = {total} 张" if work_records
           else f" = {total} 张"))
    log(f"字体策略：{font_plan['mode']} · {font_plan['note']} · 通道：{channel} · "
        f"字距 {cfg.get('char_gap', 0)}px · 留边 {cfg.get('mask_margin', 3)}px · 光学校正 "
        f"{'开' if cfg.get('optical_fit', True) else '关'}")
    log(f"开始批量生成：{total} 张 → {out_root}")

    # 单张图间隔（秒）：相邻两张图之间固定等待，避免同一时刻密集请求云端 / 密集落盘。
    try:
        img_gap = max(0.0, float(cfg.get("font_interval", 0.1) or 0))
    except (TypeError, ValueError):
        img_gap = 0.1

    for job_no, (job, forced_font) in enumerate(tasks):
        cur_font = ""
        idx, lines = job["group"], job["lines"]
        if should_stop and should_stop():
            stopped = True
            log("已收到结束请求，提前结束")
            break
        if should_pause and should_pause():
            log("任务已中断（暂停），等待继续…")
            while should_pause and should_pause():
                if should_stop and should_stop():
                    stopped = True
                    break
                time.sleep(0.15)
            if stopped:
                log("暂停中收到结束请求，提前结束")
                break
            if should_stop and should_stop():
                # 点「结束」会同时清掉暂停位，暂停循环会「正常」退出，
                # 所以这里要再判一次，否则会白多出一张图。
                stopped = True
                log("暂停中收到结束请求，提前结束")
                break
            log("任务已继续")
        # 第一张不等；之后每张之间固定 0.1s。间隔用切片睡眠，
        # 点「结束」最多等 30ms 就生效，不必等这一觉睡完。
        if job_no > 0 and img_gap > 0 and not _gap_sleep(img_gap, should_stop):
            stopped = True
            log("已收到结束请求，提前结束")
            break
        label = " / ".join(l.strip() for l in lines)
        line_smart = (tags_info["lines"][idx]["smart_tag"]
                      if idx < len(tags_info["lines"]) else tags_info["smart_tag"])
        try:
            if forced_font is not None:
                plan = {"mode": font_plan["mode"], "tags": [], "notes": [],
                        "label": font_plan["mode"]}
                pick = {
                    "fonts": [forced_font],
                    "font_label": str(forced_font.get("name") or forced_font.get("stem")
                                      or forced_font.get("value") or "—"),
                    "font_value": str(forced_font.get("value") or ""),
                    "source": forced_font.get("source", channel),
                }
            else:
                plan = selector.plan(label, idx, smart_tag=line_smart)
                pick = selector.pick(plan, idx)
            cur_font = str(pick.get("font_value") or pick.get("font_label") or "")
            base, meta = render_item(lines, pick, cfg, rng, key)
            # 云端缺字时可能返回全透明图（不报错、但一个字都没有）：
            # 视为缺字失败，不落盘，交给前端按 tag + 白名单推荐替换字体。
            if base.convert("RGBA").getchannel("A").getbbox() is None:
                raise ValueError("云端返回空白 mask：该字体缺字或无法渲染这段文字")

            name_cfg = dict(cfg)
            tpl = str(cfg.get("filename") or DEFAULT_CONFIG["filename"])
            if "{split}" not in tpl:
                tpl += "_{split}"
            name_cfg["filename"] = tpl
            name_cfg["_output_mode"] = job["mode"]
            fname = make_filename(name_cfg, job_no + 1, pick["font_label"],
                                  lines, used_names, ".png")
            target = out_root / fname
            rec = save_rgba(base, target, "PNG")
            rec.update({"format": "PNG", "frames": 1, "font": pick["font_label"],
                        "text": label, "index": job_no + 1, "font_mode": plan["mode"],
                        "tags": ",".join(plan["tags"]), "group": idx + 1,
                        "mode": job["mode"], "unit": job["unit"] + 1,
                        "mask_margin": int(cfg.get("mask_margin", 3)), **meta})
            results.append(rec)
            log(f"[{job_no + 1}/{total}] 第{idx + 1}组 · "
                f"{OUTPUT_MODE_LABELS.get(job['mode'], job['mode'])} · "
                f"{pick['font_label']} → {fname} ({rec['width']}×{rec['height']})")
        except Exception as exc:  # noqa: BLE001
            msg = f"[{job_no + 1}/{total}] 生成失败 {label}: {exc}"
            log(msg)
            errors.append(msg)
            if cur_font and cur_font not in failed_fonts:
                failed_fonts.append(cur_font)
        done += 1
        if progress:
            progress(done, total, label)

    elapsed = round(time.time() - started, 2)
    log(f"完成：成功 {len(results)} 张，失败 {len(errors)} 条，用时 {elapsed}s → {out_root}")
    if failed_fonts:
        log(f"缺字 / 不可用字体 {len(failed_fonts)} 个：{', '.join(failed_fonts[:8])}"
            + ("…" if len(failed_fonts) > 8 else ""))
    return {"ok": len(errors) == 0 and not stopped, "total": total, "done": done,
            "success": len(results), "failed": len(errors), "stopped": stopped,
            "elapsed": elapsed, "output_dir": str(out_root),
            "results": results, "errors": errors, "skipped": skipped,
            "failed_fonts": failed_fonts, "notes": notes,
            "runtime": {"catalog": cs, "tag_pools": ps}}
