#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""字体基准 —— assets/zwfnt26xsp.json

每个字体第一次参与出图时，先渲一个「国」字（缺字自动换「园」「圆」「口」「回」），
量出两件事并落盘：

1. **字面率**：字形墨迹占字号的比例。字面率偏小的字体在同字号下看着发虚，
   按基准给一个只放大不缩小的光学校正系数，让 1733 个字体在同一字号下视觉一致。
2. **四周留边**：墨迹到 em 框的上下左右距离，用来判断字形是否贴边。

之后该字体的所有 mask 都直接读这份基准：按校正后的字号渲染 → 按 alpha 墨迹
裁边 → 四周补 ``mask_margin``（默认 3px，可设置）。不必每次重新探测。
"""
from __future__ import annotations

import json
import threading
from datetime import datetime
from pathlib import Path

from PIL import Image, ImageDraw

from ugi_core import ASSETS_DIR, load_font, norm_font_id

SPEC_PATH = ASSETS_DIR / "zwfnt26xsp.json"
REF_SIZE = 160                 # 基准测量字号
PROBES = ("国", "园", "圆", "口", "回")
NOTDEF_PROBE = "\ue83f"        # 私用区码位，任何字体都没有字形
TARGET_FACE = 0.90             # 光学校正的目标字面率
MAX_SCALE = 1.20               # 光学校正上限，避免小字面字体被放大到失真

_LOCK = threading.RLock()
_CACHE: dict | None = None


# --------------------------------------------------------------------------- io

def _empty() -> dict:
    return {"version": 1, "probe": PROBES[0], "ref_size": REF_SIZE, "fonts": {}}


def _read() -> dict:
    try:
        data = json.loads(SPEC_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return _empty()
    if not isinstance(data, dict) or not isinstance(data.get("fonts"), dict):
        return _empty()
    data.setdefault("version", 1)
    data.setdefault("probe", PROBES[0])
    data.setdefault("ref_size", REF_SIZE)
    return data


def _write(data: dict) -> None:
    SPEC_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = SPEC_PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(SPEC_PATH)


def _cache() -> dict:
    global _CACHE
    with _LOCK:
        if _CACHE is None:
            _CACHE = _read()
        return _CACHE


def reload() -> dict:
    global _CACHE
    with _LOCK:
        _CACHE = _read()
        return _CACHE


# --------------------------------------------------------------------------- measure

def _glyph(font, ch: str, size: int = REF_SIZE) -> Image.Image:
    canvas = Image.new("L", (size * 4, size * 4), 0)
    ImageDraw.Draw(canvas).text((size, size * 3), ch, font=font, fill=255, anchor="ls")
    return canvas


def _same_ink(a: Image.Image, ab, b: Image.Image, bb) -> bool:
    if ab is None or bb is None:
        return ab == bb
    if (ab[2] - ab[0], ab[3] - ab[1]) != (bb[2] - bb[0], bb[3] - bb[1]):
        return False
    return a.crop(ab).tobytes() == b.crop(bb).tobytes()


def measure(path: str, index: int = 0) -> dict:
    """渲「国」字并量出字面率 / 四周留边。字体损坏或缺中文字形时如实标记。"""
    path = str(path or "")
    entry: dict = {
        "file": Path(path).name, "path": path, "ref": REF_SIZE,
        "probe": "", "probe_ok": False, "face": 0.0, "optical": 1.0,
        "ink": [0, 0, 0, 0], "side": {"l": 0, "t": 0, "r": 0, "b": 0},
        "advance": 0.0, "em": 0, "stamp": datetime.now().isoformat(timespec="seconds"),
    }
    try:
        st = Path(path).stat()
        entry["bytes"] = st.st_size
        entry["mtime"] = int(st.st_mtime)
    except OSError as exc:
        entry["error"] = f"文件不可读：{exc}"
        return entry
    try:
        font = load_font(path, REF_SIZE, index)
    except Exception as exc:  # noqa: BLE001 - 坏字体只标记，不打断整批
        entry["error"] = f"字体无法加载：{exc}"
        return entry

    notdef = _glyph(font, NOTDEF_PROBE)
    nb = notdef.getbbox()
    for ch in PROBES:
        img = _glyph(font, ch)
        bb = img.getbbox()
        if bb is None or _same_ink(img, bb, notdef, nb):
            continue                       # 无字形 / 落回 .notdef，换下一个探测字
        ascent, descent = font.getmetrics()
        advance = float(font.getlength(ch))
        ink = [bb[0] - REF_SIZE, bb[1] - REF_SIZE * 3,
               bb[2] - REF_SIZE, bb[3] - REF_SIZE * 3]
        iw, ih = ink[2] - ink[0], ink[3] - ink[1]
        face = max(iw, ih) / float(REF_SIZE)
        entry.update({
            "probe": ch, "probe_ok": True,
            "ink": ink, "advance": round(advance, 2),
            "em": ascent + descent,
            "side": {"l": max(0, ink[0]),
                     "t": max(0, ink[1] + ascent),
                     "r": max(0, int(round(advance - ink[2]))),
                     "b": max(0, descent - ink[3])},
            "face": round(face, 4),
            "optical": round(min(MAX_SCALE, TARGET_FACE / max(0.01, face)), 4)
            if face < TARGET_FACE else 1.0,
        })
        break
    return entry


# --------------------------------------------------------------------------- api

def spec_for(path: str, index: int = 0, refresh: bool = False) -> dict:
    """取某字体的基准；没有或源文件变了就现测一次并落盘。"""
    key = norm_font_id(path)
    if not key:
        return measure(path, index)
    data = _cache()
    with _LOCK:
        entry = (data.get("fonts") or {}).get(key)
        fresh = False
        if entry and not refresh:
            try:
                st = Path(path).stat()
                fresh = entry.get("bytes") == st.st_size and entry.get("mtime") == int(st.st_mtime)
            except OSError:
                fresh = False
        if fresh:
            return dict(entry)
    entry = measure(path, index)
    entry["id"] = key
    with _LOCK:
        data = _cache()
        data.setdefault("fonts", {})[key] = entry
        _write(data)
    return dict(entry)


def optical_scale(path: str, index: int = 0) -> float:
    """光学校正系数（只放大不缩小），用于按统一视觉字面率渲染。"""
    try:
        spec = spec_for(path, index)
    except Exception:  # noqa: BLE001 - 基准失败不该阻断出图
        return 1.0
    if not spec.get("probe_ok"):
        return 1.0
    return max(1.0, min(MAX_SCALE, float(spec.get("optical") or 1.0)))


def ensure(paths, index: int = 0, logger=None) -> list[dict]:
    """批量建立基准（首次使用的字体在这里一次性落盘）。返回本次新建的条目。"""
    created: list[dict] = []
    for raw in paths or []:
        p = str(raw or "")
        if not p:
            continue
        key = norm_font_id(p)
        known = key in ((_cache().get("fonts") or {}))
        spec = spec_for(p, index)
        if not known:
            created.append(spec)
            if logger:
                if spec.get("probe_ok"):
                    s = spec["side"]
                    logger(f"首次使用 {spec['file']}：已建立「{spec['probe']}」字基准 · "
                           f"字面率 {spec['face']:.2f} · 留边 左{s['l']} 上{s['t']} "
                           f"右{s['r']} 下{s['b']} · 光学校正 ×{spec['optical']:.2f}")
                else:
                    logger(f"首次使用 {spec['file']}：无法建立「国」字基准"
                           f"（{spec.get('error') or '缺少中文字形'}），按原字号渲染")
    return created


def rows(paths=None, index: int = 0) -> list[dict]:
    """给界面的基准表：只读已缓存条目，不触发新探测（除非显式给了 paths）。"""
    out: list[dict] = []
    if paths:
        for p in paths:
            out.append(spec_for(p, index))
        return out
    for key, entry in sorted((_cache().get("fonts") or {}).items()):
        row = dict(entry)
        row.setdefault("id", key)
        out.append(row)
    return out


def stats() -> dict:
    data = _cache()
    fonts = data.get("fonts") or {}
    ok = sum(1 for e in fonts.values() if e.get("probe_ok"))
    return {"path": str(SPEC_PATH), "exists": SPEC_PATH.is_file(),
            "fonts": len(fonts), "usable": ok, "probe": data.get("probe") or PROBES[0],
            "ref_size": data.get("ref_size") or REF_SIZE}
