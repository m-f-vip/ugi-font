#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UGI Font 六档订阅矩阵 + 用量计量（订阅租期版；状态文件只用 pkl）。

设计边界（重要）
----------------
* 按月订阅是**平台托管的授权租期**：到期由平台自动收回访问权限。
  Skill **不判断是否到期、不中断服务、不感知扣款方式（手动续费 / 自动扣款）**。
* Skill 唯一依赖的信号是 **服务端透传的周期标识是否变化**
  （CycleEndTime / cycle_id / 任意周期串）。
  标识变化 => 判定新周期 => 重新激活 + 计数器清零 + 初始化首次时间；
  标识不变 => 正常累计；标识缺失 => 保持现状，不做任何过期推断。
* 状态持久化只用 ``assets/zwcnt.pkl``，**不创建任何 JSON 状态文件**。
  周期标识由调用方（服务端 / 平台鉴权层）通过 /api/usage/sync 或
  /api/render 的 ``cycle`` 字段传入。

pkl 结构
--------
    {
      "tiers":  { <sku>: {"name","display_name","library","price","unit_price",
                          "monthly_cap","position"}, ... },
      "usage":  { <sku>: {"month","used","first_ts","last_active"} },  # 兼容旧版，继续写入
      "cycles": { <sku>: {
          "cycle_id": str,          # 服务端周期标识（规范化后的原始值）
          "cycle_end": float|None,  # 解析出的到期时间戳（能解析时）
          "seq": int,               # 期数，每次重新激活 +1
          "anchor": float,          # 本周期锚点（重新激活时刻）
          "used": int,
          "first_ts": float|None,
          "last_active": float|None,
          "reactivated_at": float|None,
          "month": str,             # 该记录所属自然月，跨月判定用
          "source": "server"|"local",
      }}
    }

**次数与时间是一组整体**：`used`、`first_ts`、`last_active`、`anchor`、
`reactivated_at` 在滚动/重置时一次 `save_store` 全清，不会出现「次数归零、
时间还挂着上月」的半重置（``_roll_period`` 负责这件事）。

没有周期标识时（例如纯本地自检、平台未透传），回退到旧的「自然月重置」
口径，保证离线可用；一旦平台下发过周期标识，就只按周期变化重置，
不再因跨月而误清零（这正是「同月续费不重置」那个 bug 的根因）。

产品身份（`detect_product`）
----------------------------
**产品名不写死**：数 mtag 授权清单里的字体记录数，就近落到六档之一，
再取 `TIER_MATRIX` 里的名称 / 定位 / 规模 / 月费 / 每款单价 / 月上限。
六份清单文件名相同，只有记录数不同，所以判定只看内容；文件名与目录名只作兜底。
"""
from __future__ import annotations

import math
import pickle
import re
import threading
import time
from datetime import date, datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILL_DIR = HERE.parent
ASSETS = SKILL_DIR / "assets"
CNT_PATH = ASSETS / "zwcnt.pkl"
DEFAULT_CONFIG_TAG_FILE = "assets/zwfnt26mtag_v1x.pkl"

# 六档订阅矩阵（一期口径：价格 / 每款单价 / 月上限按产品矩阵定死）
#   sku          定位    字库规模  月费   每款单价  月上限
#   ugi-free     免费版  20 款     ¥0     —         10 张   （原 ugi-buddy）
#   ugi-font2    体验版  2 款      ¥1     0.500     10 张
#   ugi-font     入门版  100 款    ¥9     0.090     100 张
#   ugi-font500  标准版  500 款    ¥39    0.078     500 张
#   ugi-font900  专业版  900 款    ¥69    0.0767    1000 张
#   ugi-font1700 旗舰版  1700+ 款  ¥129   0.0759    3000 张
TIER_MATRIX: dict[str, dict] = {
    "ugi-free":     {"name": "ugi-free",     "display_name": "UGI 字库免费版", "library": 20,   "price": 0,   "unit_price": 0.0,    "monthly_cap": 10,   "position": "免费版"},
    "ugi-font2":    {"name": "ugi-font2",    "display_name": "UGI 双字体验版", "library": 2,    "price": 1,   "unit_price": 0.5,    "monthly_cap": 10,   "position": "体验版"},
    "ugi-font":     {"name": "ugi-font",     "display_name": "UGI 字库 100",   "library": 100,  "price": 9,   "unit_price": 0.09,   "monthly_cap": 100,  "position": "入门版"},
    "ugi-font500":  {"name": "ugi-font500",  "display_name": "UGI 字库 500",   "library": 500,  "price": 39,  "unit_price": 0.078,  "monthly_cap": 500,  "position": "标准版"},
    "ugi-font900":  {"name": "ugi-font900",  "display_name": "UGI 字库 900",   "library": 900,  "price": 69,  "unit_price": 0.0767, "monthly_cap": 1000, "position": "专业版"},
    "ugi-font1700": {"name": "ugi-font1700", "display_name": "UGI 字库 1700+", "library": 1700, "price": 129, "unit_price": 0.0759, "monthly_cap": 3000, "position": "旗舰版"},
}

# 按 mtag 授权清单**内容**自动定档（不看文件名——六个档次用的是同一份文件名
# ``zwfnt26mtag_v1x.pkl``，只有记录数不同）：数出字体记录数，就近落到六档之一。
# 这样「换 pkl 就换产品」：产品名 / 定位 / 月费 / 每款单价 / 月上限全自动。
_TIER_BY_COUNT: tuple[tuple[str, int], ...] = (
    ("ugi-font2", 2), ("ugi-free", 20), ("ugi-font", 100),
    ("ugi-font500", 500), ("ugi-font900", 900), ("ugi-font1700", 1700),
)
# 文件名兜底：仅供历史测试清单（free20 / duo2 / list100 ...）继续可用
_MTAG_NAME_TIERS: tuple[tuple[str, str], ...] = (
    ("free20", "ugi-free"), ("duo2", "ugi-font2"),
    ("list100", "ugi-font"), ("list500", "ugi-font500"),
    ("list900", "ugi-font900"), ("list1700", "ugi-font1700"),
)
# 目录名兜底：ugi-sum/<sku>/zwfnt26mtag_v1x.pkl 这种「按档次分目录」的存放方式
_MTAG_DIR_TIERS: tuple[str, ...] = (
    "ugi-font1700", "ugi-font500", "ugi-font900", "ugi-font2", "ugi-font", "ugi-free",
)

DEFAULT_TAG = "ugi-free"   # 认不出档位时按最低档（最小授权）兜底，避免越权
OVERAGE_LIMIT = 1.10   # 冗余 10%：超出月上限 10% 之内照常出图（额度控制，与订阅到期无关）
OVERAGE_EXTRA = 1      # 10% 之后再宽限 1 张，用完这 1 张才停止出图
NEAR_RATIO = 0.90      # 达到 90% 提醒升级
LOCAL_CYCLE_DAYS = 30  # 平台未下发租期时，按本机首次使用起算 30 天显示倒计时（仅显示，不拦服务）

_LOCK = threading.RLock()


# --------------------------------------------------------------------- store

def _default_store() -> dict:
    return {"tiers": {k: dict(v) for k, v in TIER_MATRIX.items()},
            "usage": {}, "cycles": {}}


def load_store() -> dict:
    """读取 zwcnt.pkl；缺失/损坏时回落内置矩阵（不抛异常）。"""
    data = None
    if CNT_PATH.is_file():
        try:
            with CNT_PATH.open("rb") as fh:
                data = pickle.load(fh)
        except Exception:  # noqa: BLE001 - 内部计数器损坏不应阻断启动
            data = None
    if not isinstance(data, dict):
        data = _default_store()
    tiers = {k: dict(v) for k, v in TIER_MATRIX.items()}
    if isinstance(data.get("tiers"), dict):
        for k, v in data["tiers"].items():
            if k in tiers and isinstance(v, dict):
                # 矩阵是产品口径的唯一来源：pkl 里只补缺字段，不覆盖名称/价格/上限
                for key, val in v.items():
                    tiers[k].setdefault(key, val)
    data["tiers"] = tiers
    if not isinstance(data.get("usage"), dict):
        data["usage"] = {}
    if not isinstance(data.get("cycles"), dict):
        data["cycles"] = {}
    # 旧名迁移：ugi-buddy 已改名为 ugi-free，计数与时间原样搬过去，不丢用量
    for bucket in ("usage", "cycles"):
        old = data[bucket].pop("ugi-buddy", None)
        if isinstance(old, dict) and not isinstance(data[bucket].get("ugi-free"), dict):
            data[bucket]["ugi-free"] = old
    # 旧版 9 档遗留的 2500 / 4400 / 10000 已不在矩阵内，连同用量一起剪掉
    data["usage"] = {k: v for k, v in data["usage"].items() if k in tiers}
    data["cycles"] = {k: v for k, v in data["cycles"].items() if k in tiers}
    return data


def save_store(data: dict) -> None:
    CNT_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = CNT_PATH.with_suffix(".pkl.tmp")
    with tmp.open("wb") as fh:
        pickle.dump(data, fh)
    tmp.replace(CNT_PATH)


def init_store(force: bool = False) -> dict:
    """确保 zwcnt.pkl 存在（首次启动写入六档矩阵 + 空用量 + 空周期表）。"""
    with _LOCK:
        if force or not CNT_PATH.is_file():
            save_store(_default_store())
        return load_store()


# --------------------------------------------------------------------- tier

def _count_fonts_in(raw: dict) -> int:
    """数 mtag 授权清单里的**真实字体数**（定档依据）。

    新格式（v2.4+）每条记录是 ``{id, 书体类别, 骨架结构, ...}``，key 可能是别名
    （如 ``zwdzj`` 的真身是 ``id=字王大藏经开源字库zwdzj01``），按 ``id`` 去重才准；
    缺 ``id`` 的占位记录（如 ``zwfnt26mtag00: {}``）不计入。

    旧格式（无 ``id`` 字段）回退到按 key 模式数，排除 ``alpht`` / ``zwfnt26mtag00``
    这类别名，只认 ``*_001J`` 结尾或 ``zw.`` 开头的键。
    """
    if not raw:
        return 0
    ids: set[str] = set()
    for body in raw.values():
        if isinstance(body, dict):
            real = body.get("id")
            if real:
                ids.add(str(real).strip().lower())
    if ids:
        return len(ids)
    pat = re.compile(r"_\d{2,4}[a-z]?$", re.I)
    n = sum(1 for k in raw
            if pat.search(str(k)) or str(k).lower().startswith("zw."))
    return n or len(raw)


def mtag_font_count(cfg: dict | None = None) -> int:
    """本档 mtag 清单里的字体记录数（定档依据）。"""
    cfg = cfg or {}
    path = str(cfg.get("tag_file") or DEFAULT_CONFIG_TAG_FILE)
    try:
        from ugi_core import load_mtag_raw, resolve_tagfile
        return _count_fonts_in(load_mtag_raw(resolve_tagfile(path)))
    except Exception:  # noqa: BLE001 - 定档失败不能阻断启动
        return 0


def _tier_for_count(n: int) -> str:
    """记录数 -> SKU：在六档标准规模里取最近的一档（并列时取更大的一档）。"""
    return min(_TIER_BY_COUNT, key=lambda x: (abs(x[1] - n), -x[1]))[0]


_DETECT_CACHE: dict[str, tuple] = {}


def detect_product(cfg: dict | None = None) -> dict:
    """**按 mtag 标签文件自动确定产品**：返回 SKU、产品名、定位、规模、月费、月上限。

    判定顺序（前者为准，后两者只是兜底）：
      1. ``count``   —— 清单里的字体记录数（内容为准，与文件名无关）
      2. ``filename``—— 文件名含 free20 / duo2 / list100 / list500 / list900 / list1700
      3. ``dirname`` —— 路径里含 ugi-sum/<sku>/ 这种档次目录
      4. ``none``    —— 什么都没读到，交给 product_tag 兜底

    读清单按 (路径, 修改时间, 大小) 缓存，避免每次 HTTP 请求都解 1.5MB pkl。
    """
    cfg = cfg or {}
    raw_path = str(cfg.get("tag_file") or DEFAULT_CONFIG_TAG_FILE)
    resolved = None
    try:
        from ugi_core import resolve_tagfile
        resolved = resolve_tagfile(raw_path)
    except Exception:  # noqa: BLE001
        resolved = Path(raw_path)

    stamp = None
    try:
        st = resolved.stat()
        stamp = (str(resolved), st.st_mtime_ns, st.st_size)
    except OSError:
        stamp = (str(resolved), 0, 0)
    cached = _DETECT_CACHE.get(stamp)
    if cached:
        return dict(cached)

    raw = {}
    try:
        from ugi_core import load_mtag_raw
        raw = load_mtag_raw(resolved)
    except Exception:  # noqa: BLE001
        raw = {}
    n = _count_fonts_in(raw)

    sku, source = "", "none"
    if n > 0:
        sku, source = _tier_for_count(n), "count"
    else:
        stem = Path(raw_path).stem.lower()
        for key, cand in _MTAG_NAME_TIERS:
            if key in stem:
                sku, source = cand, "filename"
                break
        if not sku:
            parts = [p.lower() for p in Path(raw_path).parts]
            for cand in _MTAG_DIR_TIERS:
                if cand in parts:
                    sku, source = cand, "dirname"
                    break
    tier = dict(TIER_MATRIX.get(sku) or {})
    out = {
        "sku": sku,
        "source": source,
        "font_count": n,
        "tag_file": str(resolved),
        "tier_dir": Path(resolved).parent.name,
        "name": tier.get("name", ""),
        "display_name": tier.get("display_name", ""),
        "position": tier.get("position", ""),
        "library": int(tier.get("library") or 0),
        "price": tier.get("price", 0),
        "unit_price": tier.get("unit_price", 0),
        "monthly_cap": int(tier.get("monthly_cap") or 0),
    }
    if len(_DETECT_CACHE) >= 12:
        _DETECT_CACHE.clear()
    _DETECT_CACHE[stamp] = dict(out)
    return out


def infer_tier(cfg: dict | None = None) -> str:
    """按 mtag 文件自动确定产品档位；认不出返回空串，交给 product_tag 兜底。"""
    return detect_product(cfg)["sku"]


def resolve_tag(tag: str | None = None) -> str:
    """把 product_tag 归一到矩阵中的一个 SKU；未知 tag 回落 DEFAULT_TAG。"""
    raw = str(tag or "").strip().lower()
    if raw in TIER_MATRIX:
        return raw
    # 旧名兼容：ugi-buddy 已改名为 ugi-free
    aliases = {"pro": "ugi-font", "free": "ugi-free", "buddy": "ugi-free",
               "ugi-buddy": "ugi-free"}
    return aliases.get(raw, DEFAULT_TAG)


def get_tier(tag: str | None = None) -> dict:
    data = load_store()
    sku = resolve_tag(tag)
    return data["tiers"].get(sku) or dict(TIER_MATRIX[DEFAULT_TAG])


# --------------------------------------------------------------------- dates

def month_key() -> str:
    return date.today().strftime("%Y-%m")


def days_left_in_month() -> int:
    today = date.today()
    nxt = (today.replace(year=today.year + 1, month=1, day=1)
           if today.month == 12 else today.replace(month=today.month + 1, day=1))
    return max(0, (nxt - today).days)


def parse_cycle_marker(value) -> tuple[str, float | None]:
    """把服务端周期头规范化为 ``(cycle_id, cycle_end_ts|None)``。

    支持 Unix 秒 / 毫秒时间戳、ISO8601、``YYYY-MM-DD``，以及任意字符串
    周期 id（此时只比较字符串是否变化，不推断到期时间）。
    """
    if value is None:
        return "", None
    raw = str(value).strip()
    if not raw:
        return "", None
    ts: float | None = None
    if re.fullmatch(r"\d{10,13}", raw):
        v = int(raw)
        ts = v / 1000.0 if v > 10 ** 11 else float(v)
    else:
        try:
            ts = datetime.fromisoformat(raw.replace("Z", "+00:00")).timestamp()
        except ValueError:
            m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", raw)
            if m:
                try:
                    ts = datetime(int(m[1]), int(m[2]), int(m[3])).timestamp()
                except ValueError:
                    ts = None
    return raw, ts


# --------------------------------------------------------------------- cycle

def _new_cycle(marker: str, end_ts: float | None, now: float,
               source: str, seq: int = 1, reactivated: bool = False) -> dict:
    return {
        "cycle_id": marker,
        "cycle_end": end_ts,
        "seq": seq,
        "anchor": now,
        "used": 0,
        "first_ts": None,
        "last_active": None,
        "reactivated_at": now if reactivated else None,
        "source": source,
        "month": month_key(),
    }


def _reset_cycle(rec: dict, marker: str, end_ts: float | None,
                 now: float, source: str) -> dict:
    """重新激活 + 初始化：计数器清零、期数 +1、重置首次/末次时间。"""
    rec.update({
        "cycle_id": marker,
        "cycle_end": end_ts,
        "seq": int(rec.get("seq") or 0) + 1,
        "anchor": now,
        "used": 0,
        "first_ts": None,
        "last_active": None,
        "reactivated_at": now,
        "source": source,
        "month": month_key(),
    })
    return rec


def _roll_period(data: dict, sku: str, now: float) -> str:
    """把「次数 + 时间」作为一个整体滚动到新周期，并**立刻落盘**。

    这是「次数归零了、时间还挂着上月」那类半重置的根因修复点：
    以前 ``_cycle_used`` 发现跨月只在内存里返回 0，pkl 里的
    ``used`` / ``first_ts`` / ``last_active`` 原样保留，于是界面出现
    「次数 0 / 上次使用时间还是上个月」的矛盾状态。

    规则：
    * 平台托管（记录里有 ``cycle_id``）：只由 ``sync_cycle`` 的标识变化
      驱动，这里绝不插手。
    * 本地 / 自然月口径：跨月即滚动，``used`` / ``first_ts`` /
      ``last_active`` / ``anchor`` / ``reactivated_at`` 一次性全清。
    """
    rec = data["cycles"].get(sku)
    old = data["usage"].get(sku)
    if isinstance(rec, dict) and rec.get("cycle_id"):
        return ""
    if not isinstance(rec, dict) and not isinstance(old, dict):
        return ""      # 新装：没有历史可滚

    mk = month_key()
    mark = str((old or {}).get("month") or (rec or {}).get("month") or "")
    if mark == mk:
        return ""
    if not mark:
        # 旧版记录没有 month 字段：带着计数或时间才当作陈旧数据滚一次
        has_data = bool((rec or {}).get("used") or (rec or {}).get("first_ts")
                        or (old or {}).get("used") or (old or {}).get("first_ts"))
        if not has_data:
            return ""

    if not isinstance(rec, dict):
        rec = {"cycle_id": "", "cycle_end": None, "seq": 0, "anchor": None,
               "used": 0, "first_ts": None, "last_active": None,
               "reactivated_at": None, "source": "local"}
        data["cycles"][sku] = rec
    rec.update({
        "seq": int(rec.get("seq") or 0) + 1,
        "anchor": now,
        "used": 0,
        "first_ts": None,
        "last_active": None,
        "reactivated_at": now,
        "month": mk,
    })
    data["usage"][sku] = {"month": mk, "used": 0,
                          "first_ts": None, "last_active": None}
    try:
        save_store(data)
    except OSError:
        # 只读挂载（如平台沙箱）下落盘失败：内存里已经滚动好，
        # 本次 status 仍返回重置后的值，不能让查询整个 500。
        pass
    return "month_rollover"


def sync_cycle(tag: str | None = None, marker=None, source: str = "server",
               force: bool = False) -> dict:
    """周期校验入口：只比较「周期标识是否变化」，不判断到期、不关停服务。

    返回 ``{changed, reason, tag, seq, ...}``；reason 取值：
    ``activated``（首次激活）/ ``renewed``（续费新周期）/ ``same``（同期）/
    ``stale``（旧标识回退，忽略）/ ``no_marker``（平台未透传，保持现状）。
    """
    with _LOCK:
        data = load_store()
        sku = resolve_tag(tag)
        cycles = data["cycles"]
        rec = cycles.get(sku)
        mid, mts = parse_cycle_marker(marker)
        now = time.time()
        changed, reason = False, "no_marker"

        if not mid:
            # 平台没有下发周期头：自然月口径，跨月时把次数与时间一起滚动。
            # 注意仍然不推断过期、不关停服务，只做「同源清零」。
            rolled = _roll_period(data, sku, now)
            cur = data["cycles"].get(sku) or (rec if isinstance(rec, dict) else {})
            return {
                "ok": True, "changed": bool(rolled), "reason": rolled or "no_marker",
                "tag": sku,
                "cycle_id": cur.get("cycle_id", ""),
                "cycle_end": cur.get("cycle_end"),
                "seq": int(cur.get("seq") or 0),
                "status": status(sku),
            }
        elif not isinstance(rec, dict):
            cycles[sku] = _new_cycle(mid, mts, now, source)
            changed, reason = True, "activated"
        elif force:
            _reset_cycle(rec, mid, mts, now, source)
            changed, reason = True, "renewed"
        elif rec.get("cycle_id") == mid:
            reason = "same"
        else:
            local_end = rec.get("cycle_end")
            # 旧周期 / 时钟回拨：能解析时间且新值更早时不重置（防止误清零）
            if mts and local_end and mts < float(local_end) - 1:
                reason = "stale"
            else:
                _reset_cycle(rec, mid, mts, now, source)
                changed, reason = True, "renewed"

        if changed:
            # 同步写回旧 usage 字段，避免外部旧消费者读到残留计数
            data["usage"][sku] = {"month": month_key(), "used": 0,
                                  "first_ts": None, "last_active": None}
            save_store(data)
        cur = cycles.get(sku) or {}
        return {
            "ok": True, "changed": changed, "reason": reason, "tag": sku,
            "cycle_id": cur.get("cycle_id", ""),
            "cycle_end": cur.get("cycle_end"),
            "seq": int(cur.get("seq") or 0),
            "status": status(sku),
        }


def reactivate(tag: str | None = None, marker=None, source: str = "local") -> dict:
    """手动重新激活（平台未透传周期头时的运维 / 本地自检入口）。

    注意：正式上架后应由平台周期头驱动 ``sync_cycle``；这里只是显式给出
    「新周期标识」，不做支付校验——支付与租期由平台负责。
    """
    mid, mts = parse_cycle_marker(marker)
    if not mid:
        mid = f"local-{int(time.time())}"
    return sync_cycle(tag, mid, source=source, force=True)


def _cycle_used(data: dict, sku: str) -> tuple[int, float | None, float | None, bool]:
    """返回 (已用, 首次时间, 末次时间, 是否由周期标识托管)。

    时间与次数**必须来自同一份记录**：托管时只读 ``cycles``，自然月口径
    只读``usage``，且要求 month 匹配。不做「一边 0、一边回退旧值」的混读。
    """
    rec = data["cycles"].get(sku)
    if isinstance(rec, dict) and rec.get("cycle_id"):
        return (int(rec.get("used") or 0), rec.get("first_ts"),
                rec.get("last_active"), True)
    # 无周期标识：自然月口径
    mk = month_key()
    old = data.get("usage", {}).get(sku)
    if not isinstance(old, dict) or old.get("month") != mk:
        return 0, None, None, False
    return (int(old.get("used") or 0), old.get("first_ts"),
            old.get("last_active"), False)


# --------------------------------------------------------------------- status

def status(tag: str | None = None) -> dict:
    """用量快照：已用 / 上限 / 剩余 / 10%+1 冗余 / 剩余时间 / 提醒标记。

    不含任何「到期停用」判断——租约到期由平台处理。
    """
    with _LOCK:
        data = load_store()
        sku = resolve_tag(tag)
        now = time.time()
        rolled = _roll_period(data, sku, now)   # 跨月时次数与时间一起落盘清零
        tier = data["tiers"].get(sku) or dict(TIER_MATRIX[DEFAULT_TAG])
        cyc = data["cycles"].get(sku) if isinstance(data["cycles"].get(sku), dict) else {}
        used, first_ts, last_active, cycled = _cycle_used(data, sku)
        cap = int(tier.get("monthly_cap") or 0)
        # 硬上限 = 月上限 × 110% 再多给 1 张，用完这 1 张才停：
        #   10 张档 -> 11 + 1 = 12；100 -> 110 + 1 = 111；3000 -> 3300 + 1 = 3301
        hard = int(round(cap * OVERAGE_LIMIT)) + OVERAGE_EXTRA
        remaining = cap - used
        buffer_left = max(0, hard - used)
        near = cap > 0 and used >= int(round(cap * NEAR_RATIO))
        over = cap > 0 and used >= hard

        if over:
            level, msg = "blocked", (f"本月额度已用尽（月上限 {cap} 张 + 10% 冗余 + {OVERAGE_EXTRA} 张，"
                                     f"共 {hard} 张），请升级档位后继续使用")
        elif used >= cap:
            level, msg = "over", (f"已超出月上限 {cap} 张，仍可在 {buffer_left} 张内继续"
                                  f"（10% 冗余 + {OVERAGE_EXTRA} 张），请尽快升级档位")
        elif near:
            level, msg = "near", (f"已用 {used}/{cap} 张，接近月上限，"
                                  f"建议升级档位解锁更多额度")
        else:
            level, msg = "ok", ""

        # 剩余时间：一律以「一个周期 30 天」为分母展示（默认 1 个月）。
        #   1) cycle  —— 平台下发了租期结束时间，分母取「锚点→到期」的实际天数
        #   2) anchor —— 平台没下发时，按**本周期首次出图时刻**起算 30 天倒计时，
        #                天数随时间递减；重置/跨月后回到 30/30
        #   3) idle   —— 还没出过图，本周期尚未开始消耗，显示满额 30/30
        # 三种都只是展示，到期停服仍由平台负责。
        end_ts = cyc.get("cycle_end")
        expired = bool(end_ts) and float(end_ts) <= now
        anchor = cyc.get("anchor")
        period_end = None
        period_days = LOCAL_CYCLE_DAYS
        if end_ts and not expired:
            period_end = float(end_ts)
            period_days = max(1, int(math.ceil((period_end - float(anchor or now)) / 86400)))
            days_source = "cycle"
        elif anchor:
            period_end = float(anchor) + LOCAL_CYCLE_DAYS * 86400
            days_source = "anchor" if period_end > now else "expired"
        else:
            days_source = "idle"
        days_left = (max(0, math.ceil((period_end - now) / 86400)) if period_end
                     else period_days)

        return {
            "tag": sku,
            "tier": {
                "name": tier.get("name", sku),
                "display_name": tier.get("display_name") or tier.get("name", sku),
                "library": int(tier.get("library") or 0),
                "price": tier.get("price", 0),
                "unit_price": tier.get("unit_price", 0),
                "monthly_cap": cap,
                "position": tier.get("position", ""),
            },
            "month": month_key(),
            "used": used,
            "cap": cap,
            "hard_cap": hard,
            "remaining": max(0, remaining),
            "buffer_left": buffer_left,
            "days_left": days_left,
            "days_left_source": days_source,
            "period_start": anchor,
            "period_end": period_end,
            "period_days": period_days,
            "first_ts": first_ts,
            "last_active": last_active,
            "rolled": rolled,
            "cycle_id": cyc.get("cycle_id", ""),
            "cycle_end": cyc.get("cycle_end"),
            "cycle_expired": expired,
            "cycle_seq": int(cyc.get("seq") or 0),
            "cycle_anchor": cyc.get("anchor"),
            "reactivated_at": cyc.get("reactivated_at"),
            "cycle_source": cyc.get("source", "local"),
            "cycled": cycled,
            "near_limit": near,
            "over_limit": over,
            "level": level,
            "message": msg,
            "overage_limit": OVERAGE_LIMIT,
            "overage_extra": OVERAGE_EXTRA,
        }


def can_render(tag: str | None = None) -> dict:
    """渲染前校验：只看额度是否超出「110% + 1 张」硬上限，不因时间/租期拦截。"""
    s = status(tag)
    return {"allowed": not s["over_limit"], "status": s, "message": s["message"]}


def record(tag: str | None = None, count: int = 1) -> dict:
    """累计本周期已用张数；只有周期标识变化才清零（见 sync_cycle）。"""
    n = max(0, int(count))
    with _LOCK:
        data = load_store()
        sku = resolve_tag(tag)
        now = time.time()
        rec = data["cycles"].get(sku)
        mk = month_key()
        if isinstance(rec, dict) and rec.get("cycle_id"):
            if not rec.get("first_ts"):
                rec["first_ts"] = now
            rec["used"] = int(rec.get("used") or 0) + n
            rec["last_active"] = now
            rec["month"] = mk
            data["usage"][sku] = {"month": mk, "used": rec["used"],
                                  "first_ts": rec["first_ts"], "last_active": now}
        else:
            # 无周期标识：自然月口径；跨月时次数与时间一起从零开始
            old = data["usage"].get(sku)
            if not isinstance(old, dict) or old.get("month") != mk:
                old = {"month": mk, "used": 0, "first_ts": None, "last_active": None}
                data["usage"][sku] = old
            if not old.get("first_ts"):
                old["first_ts"] = now
            old["used"] = int(old.get("used") or 0) + n
            old["last_active"] = now      # 与次数同源落盘：时间参数一次都给全
            if not isinstance(rec, dict):
                rec = {"cycle_id": "", "cycle_end": None, "seq": 0, "anchor": now,
                       "used": 0, "first_ts": None, "last_active": None,
                       "reactivated_at": None, "source": "local"}
                data["cycles"][sku] = rec
            rec.update({"used": old["used"], "first_ts": old["first_ts"],
                        "last_active": now, "month": mk})
            if not rec.get("anchor"):
                rec["anchor"] = old["first_ts"]
        save_store(data)
    return status(sku)


def reset(tag: str | None = None, hard: bool = False) -> dict:
    """把「次数 + 时间」一起清零，写在同一个 ``assets/zwcnt.pkl`` 里。

    这是与 ``/api/reset``（只清任务进度）区分开的计数器重置入口：
    ``used=0``、``first_ts=None``、``last_active=None``、``anchor=now``
    一次落盘，不会出现「次数清了、时间还挂着」的半重置。
    ``hard=True`` 连周期标识与期数一起清（等同新装）。
    """
    with _LOCK:
        data = load_store()
        sku = resolve_tag(tag)
        now = time.time()
        mk = month_key()
        rec = data["cycles"].get(sku)
        data["usage"][sku] = {"month": mk, "used": 0,
                              "first_ts": None, "last_active": None}
        if hard or not isinstance(rec, dict):
            data["cycles"][sku] = {
                "cycle_id": "", "cycle_end": None, "seq": 0, "anchor": now,
                "used": 0, "first_ts": None, "last_active": None,
                "reactivated_at": now, "source": "local", "month": mk,
            }
        else:
            rec.update({
                "used": 0, "first_ts": None, "last_active": None,
                "anchor": now, "reactivated_at": now,
                "seq": int(rec.get("seq") or 0) + 1, "month": mk,
            })
        save_store(data)
    return status(sku)


def default_tag_from_config(cfg: dict | None = None) -> str:
    """产品 tag：**优先按 mtag 授权清单自动定档**，认不出才回落 product_tag。"""
    cfg = cfg or {}
    sku = detect_product(cfg)["sku"]
    return sku or resolve_tag(cfg.get("product_tag") or DEFAULT_TAG)


def main(argv: list[str] | None = None) -> int:
    """命令行自检：按 mtag 清单看「自动定成哪个产品」。

      python scripts/usage.py --detect                        # 按 config.json 的 tag_file
      python scripts/usage.py --detect D:/.../ugi-sum/ugi-font500
      python scripts/usage.py --scan  D:/.../ugi-sum          # 扫一个目录下所有档次
    """
    import argparse
    import json

    ap = argparse.ArgumentParser(description="按 mtag 标签文件自动确定产品档位")
    ap.add_argument("--detect", nargs="?", const="", default=None,
                    help="指定 mtag 文件 / 目录 / 档次目录；留空则读 config.json")
    ap.add_argument("--scan", default="", help="扫描目录下的每个子目录，逐档定档")
    args = ap.parse_args(argv)

    def load_cfg() -> dict:
        try:
            import ugi_core
            return ugi_core.load_config(ugi_core.DEFAULT_CONFIG_PATH)
        except Exception:  # noqa: BLE001
            return {}

    if args.scan:
        root = Path(args.scan)
        rows = []
        for sub in sorted(p for p in root.iterdir() if p.is_dir()):
            rows.append(detect_product({"tag_file": str(sub)}))
        print(json.dumps({"ok": True, "root": str(root), "tiers": rows},
                         ensure_ascii=False, indent=2))
        return 0

    cfg = load_cfg()
    if args.detect is not None:
        cfg = dict(cfg)
        if args.detect:
            cfg["tag_file"] = args.detect
    d = detect_product(cfg)
    d["resolved"] = default_tag_from_config(cfg)
    print(json.dumps(d, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
