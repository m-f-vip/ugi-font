#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Lightweight, fully offline NLP keyword extraction for the 智能tag box.

Pipeline (progressive, never fails the render pipeline):
  1. **先用「结巴」专业分词库分词** (``quick_cut``): jieba ``cut(HMM=False)``
     when available, otherwise a zero-dependency prefix-dict + DAG + DP
     segmenter (关闭 HMM 新词发现 = 结巴「快速版」). Tokenising BEFORE
     scoring removes cross-boundary garbage such as 友们兔 / 心不喜 at source.
  2. **再用 jieba.analyse 提取关键词**: TF-IDF (``extract_tags``) + TextRank
     (``textrank``) 给出词级权重，作为打分信号；jieba 不可用时降级到内置
     n-gram 统计，绝不让渲染失败。
  3. Score each token: domain-word hit > jieba 关键词 > dictionary word >
     generic word, with repeat / leading-position boosts.
  4. Suppress overlapping fragments, filter stopwords / numbers / dangling
     function-character tails.
输出恒为**分词后的词**，不再把整句塞成一个 tag（旧版短句会输出
「愿你三餐四季温柔有趣」这种整句，导致 tag-pools 全员 0 分、智能选字失效）。
"""
from __future__ import annotations

import re
from collections import Counter
from pathlib import Path

from ugi_core import ASSETS_DIR

_URL = re.compile(r"https?://\S+|www\.\S+", re.I)
_MENTION = re.compile(r"[@#][\w\u4e00-\u9fff]+")
_KEEP = re.compile(r"[^\u4e00-\u9fffA-Za-z0-9 ]+")
_CN = re.compile(r"[\u4e00-\u9fff]+")
_EN = re.compile(r"[A-Za-z][A-Za-z0-9]*")
_NUM = re.compile(r"^\d+$")

# Single characters that nearly never carry meaning inside a Chinese bigram.
_FUNCTION_CHARS = set("的了是在和与及或有这那我你他她它们个也很都就而为之以其于把被让从对给到"
                      "上下中里外不无没更最又再还只才但并且啊呀呢吧哦嗯么什谁怎样如若因所以"
                      "一二三四五六七八九十第将把被让使")
_EN_STOP = {"the", "and", "for", "with", "this", "that", "you", "are", "from",
            "font", "text", "title", "image", "png", "gif", "a", "an", "of", "to"}

# 明显是虚词/助词拼出的半截残块，作为「字体风格 tag」无检索价值。
# 注意：不要过度拉黑普通实词（如 一切/继续/世界），否则短句会提取不出任何 tag。
_LOW_VALUE_WORDS = {
    "的交", "剩下", "们的", "是的", "来的", "分的", "得的", "着呢",
    "了的", "而在", "其为", "与之", "所有", "这个", "那个",
}

# Scene vocabulary used by design / PPT / short-video / subtitle workflows.
# A hit here is a strong signal for the tag pools (应用场景 / 情绪性格).
DOMAIN_WORDS = [
    "赛博朋克", "赛博", "霓虹", "科技感", "未来感", "国风", "水墨", "书法", "手写",
    "复古", "怀旧", "极简", "简约", "可爱", "萌系", "圆润", "圆体", "粗体", "黑体",
    "宋体", "衬线", "涂鸦", "手绘", "卡通", "儿童", "综艺", "花字", "标题字",
    "海报", "封面", "字幕", "片头", "片尾", "卡点", "转场", "vlog", "短视频",
    "品牌", "logo", "商标", "包装", "电商", "直播", "游戏", "电竞", "二次元",
    "春节", "中秋", "圣诞", "新年", "婚礼", "节日", "国潮", "古风", "禅意",
    "机械", "金属", "立体", "3d", "像素", "故障", "glitch", "渐变", "粒子",
    "光效", "发光", "荧光", "火焰", "冰雪", "液态", "毛玻璃", "镭射", "全息",
    "文艺", "治愈", "温暖", "高级感", "奢华", "商务", "正式", "活泼", "俏皮",
    "力量感", "硬朗", "锐利", "柔和", "优雅", "浪漫", "神秘", "暗黑", "恐怖",
    "抽象", "艺术", "几何", "装饰", "创意", "潮流", "街头", "运动", "速度",
    "描边", "阴影", "浮雕", "镂空", "质感", "纹理", "金箔", "大理石",
]

_TAG_PRESETS = [
    {"name": "赛博霓虹 · 科技海报", "text": "赛博朋克霓虹标题字 科技感海报主视觉",
     "hint": "匹配 应用场景/情绪性格 中的科技、霓虹、海报类字体"},
    {"name": "国风水墨 · 中秋", "text": "国风水墨书法 中秋海报标题",
     "hint": "匹配 书体类别/质感装饰 中的书法、水墨、古风类字体"},
    {"name": "可爱圆体 · 儿童字幕", "text": "可爱圆体手写 儿童节短视频字幕",
     "hint": "匹配 情绪性格/笔画形态 中的圆润、可爱、手写类字体"},
    {"name": "故障电竞 · 片头", "text": "故障风 glitch 电竞游戏片头动效字",
     "hint": "匹配 质感装饰 中的故障、破碎、机械类字体"},
    {"name": "极简品牌 · logo", "text": "极简现代无衬线 品牌 logo 标准字",
     "hint": "匹配 书体类别 中的黑体、几何、无衬线类字体"},
    {"name": "金属立体 · 综艺花字", "text": "金属质感立体3D 综艺花字标题",
     "hint": "匹配 质感装饰/骨架结构 中的金属、三维、装饰类字体"},
]

_STOPWORDS_CACHE: set[str] | None = None


def _load_stopwords() -> set[str]:
    global _STOPWORDS_CACHE
    if _STOPWORDS_CACHE is not None:
        return _STOPWORDS_CACHE
    words = {"这个", "那个", "一个", "一些", "我们", "你们", "他们", "可以", "进行",
             "使用", "生成", "制作", "标题", "字体", "文字", "图片", "效果", "内容",
             "什么", "怎么", "如何", "请帮", "帮我", "谢谢", "以及", "还有", "就是"}
    f = ASSETS_DIR / "stopwords.txt"
    if f.is_file():
        try:
            for line in f.read_text(encoding="utf-8").splitlines():
                w = line.strip()
                if w and not w.startswith("#"):
                    words.add(w)
        except OSError:
            pass
    _STOPWORDS_CACHE = words
    return words


def clean_text(text: str) -> str:
    s = str(text or "")
    s = _URL.sub(" ", s)
    s = _MENTION.sub(" ", s)
    return _KEEP.sub(" ", s).strip()


def _jieba_keywords(text: str, topk: int) -> list[tuple[str, float]] | None:
    try:
        import jieba.analyse  # type: ignore
    except Exception:
        return None
    try:
        out: dict[str, float] = {}
        for i, w in enumerate(jieba.analyse.extract_tags(text, topK=topk * 2)):
            out[w] = max(out.get(w, 0), 10.0 - i)
        try:
            for i, w in enumerate(jieba.analyse.textrank(text, topK=topk)):
                out[w] = out.get(w, 0) + 6.0 - i * 0.4
        except Exception:
            pass
        return sorted(out.items(), key=lambda x: -x[1])
    except Exception:
        return None


def _ngram_candidates(text: str) -> dict[str, float]:
    scores: dict[str, float] = {}
    for block in _CN.findall(text):
        L = len(block)
        for n in (2, 3, 4):
            if L < n:
                continue
            for i in range(L - n + 1):
                gram = block[i:i + n]
                bad = sum(1 for ch in gram if ch in _FUNCTION_CHARS)
                if bad >= max(1, n - 1):
                    continue
                weight = (n - 1) * (1.0 - 0.25 * bad)
                scores[gram] = scores.get(gram, 0) + weight
    # Reward fragments that actually repeat in the input.
    for gram in list(scores):
        scores[gram] += (text.count(gram) - 1) * 1.5
    return scores


def _overlap(a: str, b: str) -> bool:
    """True when two candidates share a meaningful Chinese fragment."""
    if a in b or b in a:
        return True
    if len(set(a) & set(b)) >= 2:
        return True
    return any(a[i:i + 2] in b for i in range(max(0, len(a) - 1)))


def _merge_fragments(scores: dict[str, float]) -> dict[str, float]:
    """Suppress n-gram fragments such as 克霓虹标 that straddle word
    boundaries: a stronger, already-kept keyword sharing the same characters
    wins. Domain words all score 9, so they survive while raw n-grams (~3)
    are dropped."""
    ranked = sorted(scores.items(), key=lambda x: (-x[1], -len(x[0]), x[0]))
    kept: dict[str, float] = {}
    for word, sc in ranked:
        if any(other != word and _overlap(word, other) and osc >= sc * 0.72
               for other, osc in kept.items()):
            continue
        kept[word] = sc
    return kept


def extract_keywords(text: str, topk: int = 6,
                     tokens: list[str] | None = None) -> tuple[list[str], str]:
    """Return (keywords, engine).

    提取流程（先分词、再提取关键词，两阶段都走专业 NLP 模块）：

      1. **分词**：``quick_cut.cut`` → jieba 精确模式（``HMM=False``）；未安装
         jieba 时降级为内置零依赖的结巴式 DAG + DP 快速分词。
      2. **关键词提取**：``jieba.analyse`` 的 TF-IDF（``extract_tags``）与
         TextRank（``textrank``）给出词级权重；jieba 不可用时降级为内置
         n-gram 统计。权重只对「分词得到的词」加成，不引入新碎片。
      3. 词级打分（领域词 > 关键词 > 词典词 > 普通词）→ 重叠抑制 → 取 topk。

    输出恒为**分词后的词**，不再把整句塞成一个 tag：旧版短句会输出
    「愿你三餐四季温柔有趣」这类整句，在 tag-pools 里全员 0 分、智能选字失效。

    ``tokens`` 为可选项：工作台「分词栏」手工编辑后把词序列传进来，后续打分
    完全复用；未传时仍走自动分词，因此不改变既有调用方。
    """
    import quick_cut

    cleaned = clean_text(text)
    if not cleaned:
        return [], quick_cut.engine()
    stop = _load_stopwords()
    seg_engine = quick_cut.engine()

    # 1) 专业分词库分词（jieba / 内置 DAG 兜底）
    words = ([str(w).strip() for w in tokens if str(w).strip()]
             if tokens else quick_cut.cut(cleaned))
    low = cleaned.lower()
    domain_hits = [w for w in DOMAIN_WORDS if w in low]
    domain_set = set(domain_hits)
    freq = quick_cut._dict()[0]

    # 2) jieba 关键词提取（TF-IDF + TextRank）；缺库则 n-gram 统计降级
    jieba_kw = _jieba_keywords(cleaned, topk)
    if jieba_kw:
        kw_weights = {str(w).strip().lower(): float(sc) for w, sc in jieba_kw}
        kw_engine = "jieba.analyse(TF-IDF+TextRank)"
    else:
        kw_weights = {w.lower(): sc for w, sc in _ngram_candidates(cleaned).items()}
        kw_engine = "builtin-ngram"
    engine = f"{seg_engine} + {kw_engine}"

    # 3) 词级打分：领域词 > 关键词 > 词典词 > 普通词；重复出现加权；长词略优先。
    candidates: dict[str, float] = {}
    for idx, w in enumerate(words):
        lw = str(w).strip().lower()
        if len(lw) < 2 or lw in stop or _NUM.match(lw):
            continue
        if lw in _EN_STOP or all(ch in _FUNCTION_CHARS for ch in lw):
            continue
        if lw in domain_set or any(d in lw or lw in d for d in domain_hits):
            score = 10.0
        elif freq.get(w) or quick_cut.has_word(w):
            # 词典命中的整词（如 兔年大吉 / 真心喜欢 / 赛博朋克）
            score = 7.0 + min(2.0, len(lw) * 0.25)
        elif re.match(r"[A-Za-z]", lw):
            score = 5.0
        else:
            score = 3.0
        # 被 jieba 判定为关键词的词优先输出（权重越高加成越大，上限 +3）
        if lw in kw_weights:
            score += 1.0 + min(2.0, kw_weights[lw] / 6.0)
        score += (cleaned.count(w) - 1) * 1.2          # 重复出现加权
        score += 0.6 if idx < len(words) * 0.4 else 0  # 靠前位置略优先
        candidates[lw] = max(candidates.get(lw, 0), score)

    for w in _EN.findall(cleaned):
        lw = w.lower()
        if lw not in _EN_STOP and len(lw) >= 2:
            candidates[lw] = max(candidates.get(lw, 0), 5.5)

    for w in domain_hits:
        candidates[w] = max(candidates.get(w, 0), 10.0)

    # jieba.analyse 提取到的关键词只作**补充**：短句里分词常只切出单字
    # （所/行/皆/坦途），词级打分会只剩 1 个 tag。仅当主候选不足时补入，
    # 权重恒低于分词主候选，避免「脚下/眼中」被「有路/有光」挤掉。
    _WEAK_HEAD = set("所皆之而其亦又更最很都就才但并愿把被让从对给到上下中不无没有")
    if len(candidates) < min(topk, 3):
        for kw, sc in (jieba_kw or []):
            lw = str(kw).strip().lower()
            if len(lw) < 2 or lw in stop or _NUM.match(lw) or lw in _EN_STOP:
                continue
            if lw in candidates:
                continue
            if lw[0] in _WEAK_HEAD and len(lw) <= 2:
                continue
            if all(ch in _FUNCTION_CHARS for ch in lw):
                continue
            candidates[lw] = 3.8 + min(1.2, sc / 12.0)
            if len(candidates) >= topk:
                break

    # 用重叠抑制去掉跨词碎片（如「主视」被「主视觉」吞并）。
    merged = _merge_fragments(candidates)
    strong = sum(1 for s in merged.values() if s >= 7)
    filtered: list[str] = []
    for w, s in sorted(merged.items(), key=lambda x: (-x[1], -len(x[0]), x[0])):
        if w in stop or _NUM.match(w) or len(w) < 2:
            continue
        # 尾字是虚词且词很短 -> 「的交 / 级的 / 剩下」这类半截残块，无 tag 价值。
        # 例外：已在分词词典 / 被 jieba 判为关键词的正常词（脚下 / 眼中）不误杀。
        is_real = bool(freq.get(w) or quick_cut.has_word(w) or w in kw_weights)
        if w[-1] in _FUNCTION_CHARS and len(w) <= 3 and not is_real:
            continue
        if all(ch in _FUNCTION_CHARS for ch in w):
            continue
        if w in _LOW_VALUE_WORDS:
            continue
        if s < 5 and strong >= topk:
            break
        filtered.append(w)
        if len(filtered) >= topk:
            break
    # 兜底：极端短句/纯虚词文本被过滤空时，退回长度≥2 的最佳候选，绝不空手。
    if not filtered:
        for w, _s in sorted(merged.items(), key=lambda x: (-x[1], -len(x[0]), x[0])):
            if len(w) >= 2 and w not in stop and not _NUM.match(w) \
                    and not all(ch in _FUNCTION_CHARS for ch in w):
                filtered.append(w)
                if len(filtered) >= min(topk, 3):
                    break
    return filtered, engine


def smart_tag_string(text: str, topk: int = 6) -> str:
    """Keywords joined by a comma -- the exact format of the 智能tag box."""
    return ",".join(extract_keywords(text, topk)[0])


def tags_for_text(text: str, topk: int = 6, follow: bool = True,
                  tokens: list[str] | None = None) -> dict:
    """Analyse a multi-line text box.

    ``smart_tag`` always uses the FIRST non-empty line (the box's displayed
    value). When ``follow`` is on, every line also gets its own keyword set so
    the renderer can swap fonts per line at runtime.

    ``tokens`` overrides the segmentation of the FIRST line only, so an edited
    分词栏 can drive tag extraction without changing per-line runtime behaviour.
    """
    lines = [l.strip() for l in str(text or "").replace("\r\n", "\n").split("\n") if l.strip()]
    first = lines[0] if lines else ""
    kw, engine = extract_keywords(first, topk, tokens)
    per_line = []
    for line in lines:
        if follow and line != first:
            lkw, _ = extract_keywords(line, topk)
        else:
            lkw = kw
        per_line.append({"text": line, "smart_tag": ",".join(lkw), "keywords": lkw})
    return {"first_line": first, "smart_tag": ",".join(kw), "keywords": kw,
            "engine": engine, "follow": bool(follow), "lines": per_line}


def tag_presets() -> list[dict]:
    return [dict(c) for c in _TAG_PRESETS]


def domain_words() -> list[str]:
    return list(DOMAIN_WORDS)
