# 本机 API 参考

服务地址 `http://127.0.0.1:8766`，仅监听回环地址。所有接口返回 JSON（图片接口返回二进制），字段 `ok` 表示成败。

## GET

| 接口 | 说明 |
| --- | --- |
| `/api/health` | 版本、Pillow 状态、Python 版本、授权信息、**自动识别出的产品档位 `product`** |
| `/api/config` | 完整配置 + 目录状态 + 授权 + 字库状态 + tag-pools + 字体基准统计 |
| `/api/catalog-status` | 字库准备进度；`ready` 为 true 即就绪 |
| `/api/catalog?refresh=1` | 触发字库刷新（后台线程），返回当前目录快照 |
| `/api/fonts?channel=local\|cloud` | 字体清单 |
| `/api/tag-pools` | tag-pools 统计与维度 |
| `/api/tags?q=&limit=` | tag 联想 |
| `/api/tag-presets` | 6 个智能tag 预设（`name` / `text` / `hint`） |
| `/api/hot-lines` | 内置语句池 |
| `/api/segment?text=` | 分词结果 |
| `/api/smart-tag?text=&topk=&follow=` | 智能 tag 提取 |
| `/api/font-spec?paths=&rebuild=1` | 字体基准；`rebuild=1` 全量重建字体基准 |
| `/api/license` | 授权信息 |
| `/api/state` | 任务状态、进度、日志、结果、错误、被剔除字体 |
| `/api/check` | 环境检查 |
| `/api/preview?file=<绝对路径>` | 输出目录内的 PNG；越界返回 **403** |
| `/api/docs?name=` | 文档 Markdown |
| `/api/open-folder?which=font\|output` | 在资源管理器打开目录 |

## POST

| 接口 | 请求体 | 说明 |
| --- | --- | --- |
| `/api/config` | `{config: {...}}` | 深合并后写盘，返回回读结果 + 目录状态 |
| `/api/catalog` | `{cloud: bool}` | 强制刷新字库 |
| `/api/work-fonts` | `{tags, specified_tag, channel, top_n}` | 按 tag 匹配当前选择字体；`specified_tag` 强制并入 `tags`（省略时用配置值），返回合并后的 `tags` |
| `/api/tag-match` | `{tags, top_n}` | tag 匹配详情（含扩展词与排序结果） |
| `/api/segment` | `{text}` | 分词（长文本走 body） |
| `/api/smart-tag` | `{text, topk, follow, tokens}` | 智能 tag 提取 |
| `/api/font-spec` | `{paths: [...], rebuild: bool, font_index}` | 建 / 重建基准，返回 `created` 与 `rows` |
| `/api/probe` | `{text, font, size, key, timeout, endpoint}` | 测试云接口，返回 base64 预览，不写文件 |
| `/api/render` | `{text, options, render_matrix}` | 启动渲染任务 |
| `/api/pause` | `{paused: bool}` | 中断 / 继续（任务正在结束中返回 409） |
| `/api/stop` | — | 结束当前任务，立即返回 `{stopping, usage}` |
| `/api/reset` | — | 清空任务状态（**不动次数与时间**） |
| `/api/usage/reset` | `{tag?, hard?}` | **计数器整体重置**：`used` 与本周期 `first_ts`/`last_active` 一次清零并落盘；`hard=true` 连周期标识一起清 |

### 产品档位怎么自动确定（`product`）

`GET /api/health` 与 `paid_entry.py` 都会回传 `product`：`sku / display_name / position / library / price / unit_price / monthly_cap / font_count / source / tag_file`。

六个 SKU 的 mtag 清单**文件名相同**（`zwfnt26mtag_v1x.pkl`），只有**记录数**不同，所以定档只看内容：

| 记录数 | 落档 | 定位 | 月费 | 每款单价 | 月上限 |
| --- | --- | --- | --- | --- | --- |
| ≤ 10 | `ugi-font2` | 体验版 | ¥1 | 0.500 | 10 张 |
| 11 ～ 59 | `ugi-free` | 免费版 | ¥0 | — | 10 张 |
| 60 ～ 299 | `ugi-font` | 入门版 | ¥9 | 0.090 | 100 张 |
| 300 ～ 699 | `ugi-font500` | 标准版 | ¥39 | 0.078 | 500 张 |
| 700 ～ 1299 | `ugi-font900` | 专业版 | ¥69 | 0.0767 | 1000 张 |
| ≥ 1300 | `ugi-font1700` | 旗舰版 | ¥129 | 0.0759 | 3000 张 |

`source` 记录这次是怎么认出来的：`count`（按内容，正常路径）/ `filename`（文件名含 free20、duo2、list100…）/ `dirname`（路径含 `ugi-sum/<sku>/`）/ `none`（清单读不到，回落 `product_tag`）。

`tag_file` 可以直接写**目录**（如 `../ugi-sum/ugi-font500`），会自动取目录里那份 `zwfnt26mtag*.pkl`。

命令行自检：

```bash
python scripts/usage.py --detect                              # 按 config.json 当前 tag_file
python scripts/usage.py --detect ../ugi-sum/ugi-font500    # 指定档次
python scripts/usage.py --scan   ../ugi-sum                # 六档一次列全
```

`GET /api/usage` 的 `tier` 里同时给出 `position`（定位）与 `unit_price`（每款单价），界面顶栏的 `title` 提示就是这组字段拼的。

### 计数器的清零时机

次数与时间同属 `assets/zwcnt.pkl` 的 `cycles[sku]`，**任何一次归零都是整组一起清**：

| 触发 | 入口 | 结果 |
| --- | --- | --- |
| 平台下发新周期标识 | `GET /api/usage?cycle=…` / `POST /api/usage/sync` / `/api/render` 的 `cycle` | `used=0`，两个时间置空，`seq+1`，`reason=renewed` |
| 未透传标识且跨自然月 | 任意一次读用量（`/api/usage`、`/api/state`、`paid_entry`） | `used=0`，时间置空，`rolled="month_rollover"`，读时即落盘 |
| 手动重置 | `POST /api/usage/reset`（**界面不设按钮**，供平台运维/自检调用） | 同上 |

`cycle_end` 已过而平台未下发新标识时：`cycle_expired=true`，**次数保留**（到期收回权限是平台的事），剩余天数仍按 30 天口径展示，不会卡在 0 天。

### 剩余时间怎么算（`days_left / period_days`）

头部固定显示 **`剩余时间：{days_left} / {period_days} 天`**，默认 `30 / 30 天`：

| `days_left_source` | 场景 | 计算 |
| --- | --- | --- |
| `idle` | 还没出过图 | 满额 `30 / 30`（本周期尚未开始消耗） |
| `anchor` | 本机首次出图后 | 锚点（首次出图时刻）+ 30 天倒计时，天数递减；跨月/重置后回到 `30 / 30` |
| `cycle` | 平台下发了 `cycle_end` | 按平台租期算，分母 = 锚点→到期的实际天数 |
| `expired` | 本机 30 天窗口已过且平台未下发新周期 | 显示 `0 / 30`，不停服、不拦出图 |

三种来源都只影响显示，**到期停服仍由平台负责**。

### 结束 / 中断的时序

| 步骤 | 服务端 | 界面 |
| --- | --- | --- |
| 点「结束」 | `CANCEL` 置位、`PAUSE` 清位、`stopping=true`，**立刻**回 `{ok, stopping, usage}` | 中断按钮立即回到「中断」并禁用、结束按钮禁用、状态标签变「正在结束」，不等最后一张图 |
| 收尾 | 正在渲染的那 1 张跑完即停（间隔改成 30ms 切片睡眠，最多等 30ms）；按**已出图张数**记账后先把结果落 `STATE`，随后 `stopping=false` | 轮询到 `status != running` 后：生成按钮恢复、状态标签回「空闲」、toast 显示「已结束 · 已出 N 张 · 本月已用 X/Y 张」 |
| 超时兜底 | — | 15s 仍未确认（卡在一次云端请求里）则前端强制复位，允许重新生成 |

中止**不回退**次数：出了几张就记几张，剩余次数同拍减少。

### POST /api/render

```json
{
  "text": "富贵吉祥\n一",
  "render_matrix": true,
  "options": {
    "font_size": 160, "mask_margin": 3, "optical_fit": true,
    "channel": "local", "font_mode": "smart_tag", "smart_tag": "国风,书法",
    "specified_tag": "屌丝，躺平",
    "output_modes": ["single"],
    "work_fonts": ["zw.DESIGNER7_002F.ttf"],
    "manual_fonts": ["zw.DESIGNER7_002F.ttf"], "output_dir": "d:\\ugi-out"
  }
}
```

返回（已带用量快照）：

```json
{ "ok": true, "status": "running", "total": 14, "groups": 2,
  "font_mode": "smart_tag", "work_fonts": 1, "render_matrix": true,
  "mask_margin": 3, "output_modes": ["single"], "output_dir": "d:\\ugi-out",
  "usage": { "tag": "ugi-font1700", "used": 3, "cap": 3000, "remaining": 2997,
             "days_left": 30, "period_days": 30, "days_left_source": "anchor",
             "tier": {"display_name": "UGI 字库 1700+"} } }
```

`GET /api/state` 同样带 `usage` 与 `stopping`：一个轮询就能同时刷新进度、按钮与次数。

`total` = 输出单元数 × 可用字体数（`render_matrix` 为 true 时）。张数的唯一事实源是 `ugi_core.build_render_jobs()`，服务端、命令行与渲染主循环共用。

界面固定传 `output_modes: ["single"]`（整行一张）；`skipped` 是本次任务里预检不通过、被剔除的字体名。

智能 tag 筛选强制并入「指定 tag」（界面可编辑，默认 `屌丝，躺平`）：`/api/work-fonts` 用 `split_tags` 合并后返回 `tags`，`font_selector.plan()` 的 `tags` 同样是「识别 tag + 指定 tag」。两个 tag 栏的人工输入支持英文逗号、中文逗号、分号、顿号与空格分隔，服务端先用 `tag_pools.input_tags()` 归一化为逗号串再拆。

### 参数 ↔ UGI-API 字段

`options` 里的渲染参数与 UGI-API 的 GET 参数一一对应：

| 界面字段 | options 键 | 说明 |
| --- | --- | --- |
| 字号 `s` | `font_size` | 基准字号，所有字体都用它 |
| 字色 `tc` | `api.ugi_fg` | 6 位 hex，默认 `FFFFFF` |
| 底色 `bc` | `api.ugi_bg` | 6 位 hex，默认 `000000` |
| 输出格式 `o` | `api.ugi_output_format` | `png` / `b64`（界面显示 png，传给接口仍是 `o=file`，接口只认 `file` / `b64`） |
| 文本 `t` | `text` 与 `current_text` | 文本池每行一组；「当前文本行」可直接编辑，光标切行时智能 tag 同步 |
| 排版方向 `d` | — | 隐含固定 `ltr`，不可配置 |
| mask 留边 | `mask_margin` | 本机裁边补边像素，默认 3 |
| 字距 | `char_gap` | 本机切列插入像素，默认 **0**；汉字和英文、标点混用会有切分 bug，建议 0 px |


### GET /api/state 的结果项

```json
{ "file": "d:\\ugi-out\\001_zw.DESIGNER7_002F.ttf_富贵吉祥_single.png",
  "width": 605, "height": 151, "bytes": 4512,
  "mode": "RGBA", "bits_per_pixel": 32, "format": "PNG", "frames": 1,
  "font": "zw.DESIGNER7_002F.ttf", "font_used": "d:\\ugi-fonts\\zw.DESIGNER7_002F.ttf",
  "source": "local", "text": "富贵吉祥", "index": 1, "group": 1,
  "mode": "single", "unit": 1, "font_mode": "specified", "tags": "",
  "mask_margin": 3, "font_size": 190, "optical": 1.188 }
```

> `mode` 在图像属性里表示 `RGBA`；任务对象里的 `mode` 表示输出方式（`single` / `char` / `multi`），两者同名不同层。

`pad` 不在结果里、由像素决定：用 `GET /api/preview` 取图后按 alpha 边界测量，或用 `render_cli.py --inspect` 校验，正常等于 `[mask_margin] × 4`。

## 平台调用（无界面入口 `scripts/paid_entry.py`）

平台侧其他 skill 调 UGI 时走这个入口：一次调用同时拿回 **mask + 次数 + 时间**，
不用再查一次额度。

```bash
python scripts/paid_entry.py --text "富贵吉祥" --fonts "组名/zw.CLAY3_001J" --json
echo '{"text":"富贵吉祥","fonts":["组名/zw.CLAY3_001J"]}' | python scripts/paid_entry.py --stdin --json
```

返回（`--json` 时图片在 `images[].png_base64`；不带 `--json` 时落盘到 `out_dir` / `files`）：

```json
{
  "ok": true, "channel": "ugi-api",
  "edition": "ugi-font1700", "edition_name": "UGI 字库 1700+",
  "product": {"sku": "ugi-font1700", "source": "count", "font_count": 20,
              "position": "旗舰版", "library": 1700, "price": 129,
              "unit_price": 0.0759, "monthly_cap": 3000},
  "text": "富贵吉祥", "count": 2, "skipped": [],
  "elapsed": 1.55,
  "usage": {
    "tag": "ugi-font1700", "month": "2026-11",
    "used": 55, "cap": 3000, "remaining": 2945, "hard_cap": 3301, "buffer_left": 3246,
    "days_left": 30, "period_days": 30, "days_left_source": "anchor",
    "first_ts": 1794712525.06, "last_active": 1794715040.86,
    "rolled": "", "cycle_expired": false,
    "cycle_id": "", "cycle_end": null, "cycle_seq": 0, "cycle_source": "local",
    "level": "ok", "message": "", "overage_limit": 1.1, "overage_extra": 1,
    "tier": {"name": "ugi-font1700", "display_name": "UGI 字库 1700+",
             "library": 1700, "price": 129, "unit_price": 0.0759,
             "monthly_cap": 3000, "position": "旗舰版"}
  },
  "images": [{"font": "组名/zw.CLAY3_001J", "width": 444, "height": 118, "png_base64": "..."}]
}
```

要点：

- **产品身份**：`edition` / `edition_name` / `product` 由 mtag 清单的记录数自动定档（见上一节），
  `paid_entry.py` 里只需把 `EDITION_MTAG` 指到本档清单，不用逐档改代码。
- **计次**：按实际出图张数累加，非白名单字体计入 `skipped` 且不出图；额度超「110% + 1 张」时才返回 `ok:false` 并附 `usage`
  （退出码 2），不会出图。
- **时间**：`first_ts`（本周期首次使用）/ `last_active`（最近一次出图）/ `days_left` + `period_days`（默认 `30 / 30 天`，
  平台有租期按租期，否则按首次出图起算 30 天倒计时），全部与 `used` 同源写在 `assets/zwcnt.pkl`。**三者与 `used` 整组同清**：
  跨月（`rolled="month_rollover"`）、平台下发新周期、手动重置时一起归零，不会出现「次数 0、时间还是上月」，
  也不会出现「剩余时间永远是个常量」。
- **到期**：`cycle_end` 已过而平台未发新标识 → `cycle_expired=true`，次数保留、天数仍按 30 天口径，不停服也不钉死 0 天。
- **间隔**：每张之间固定 0.1s，与工作台一致。
- 命令行渲染器 `render_cli.py` 同样计次并打印 `usage`；本机预览 / 自检加 `--no-count` 只读快照不计次。

## 鉴权与安全

- 服务只绑定 `127.0.0.1`；`/api/preview` 只放行输出目录内的 `.png`，其余返回 403。
- 请求体上限 30MB，超出返回 413。
- 授权 Key 只在本机校验，不上传，也不阻断渲染。
