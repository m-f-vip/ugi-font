# UGI Font 文档索引

| 文档 | 内容 |
| --- | --- |
| [新手操作手册](user-guide.md) | 界面逐区说明、第一次出图流程、常见问题 |
| [命令行速查](cli-cheatsheet.md) | `render_cli.py` / `check_env.py` 全部参数与示例 |
| [API 接口参考](api_reference.md) | 本机 8766 服务全部接口与字段 |
| [版权与授权声明](copyright.md) | 作品登记证书、唯一官方 API、盗版判定 |
| [上架自检清单](release-checklist.md) | 发布前逐项核对 |

界面右上「保存设置」写回 `config.json`；`assets/zwfnt26xsp.json` 是字体基准缓存（「国」字量出的字面率与四周留边），首次使用自动生成、后台完成、界面不占位，需要查看或重建时用 `render_cli.py --font-spec`。

Markdown 中的图片在弹窗内自适应渲染。
