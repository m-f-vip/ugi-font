# 命令行速查

无需启动服务，直接出图。

## 最常用

```bash
# 列出字库
python scripts/render_cli.py --list-fonts

# 按当前配置里的文本与字体出图（默认智能tag + 遍历当前选择字体）
python scripts/render_cli.py --json

# 指定文本，只出单行
python scripts/render_cli.py --text "会挣钱的智能体" --split-mode single

# 单字输出，留边 5px
python scripts/render_cli.py --text "富贵吉祥" --split-mode char --margin 5

# 智能tag 策略（默认）：先分词再按 tag 选字
python scripts/render_cli.py --text "元字库" --mode smart_tag --json

# 只出指定字体、不遍历当前选择字体
python scripts/render_cli.py --text "富贵吉祥" --work-fonts "zw.DESIGNER7_002F.ttf" --no-matrix

# 换输出目录
python scripts/render_cli.py --text "富贵吉祥" --out d:\ugi-out\test
```

## 字体基准

```bash
# 查看已缓存基准（字面率 / 四周留边 / 光学校正）
python scripts/render_cli.py --font-spec --json

# 重建基准并落盘 assets/zwfnt26xsp.json
# 云通道下本机无字体文件，--rebuild 会提示跳过；基准按首次渲染自动生成
python scripts/render_cli.py --font-spec --rebuild
```

## 参数

| 参数 | 说明 |
| --- | --- |
| `--config` | 配置文件，默认根目录 `config.json` |
| `--text` | 文本；每行一组，行内换行写 `\n` |
| `--in-file` | 从 .txt 读取文本（自动 utf-8 / gbk） |
| `--channel` | 固定 `cloud`：字库与渲染走 UGI-API 云通道 |
| `--mode smart_tag\|random\|specified` | 字体策略，默认 `smart_tag` |
| `--split-mode multi\|single\|char` | 只出这一种输出方式 |
| `--smart-tag` / `--specified-tag` | 直接给 tag（逗号分隔）；不传 `--specified-tag` 时用配置的 `specified_tag`，默认 屌丝，躺平 |
| `--specified-fonts` / `--work-fonts` | 指定字体清单 / 当前选择字体（逗号分隔） |
| `--font` | 追加指定字体，可重复 |
| `--tag-top-n` | tag 匹配返回数量，默认 12 |
| `--size` | 基准字号 |
| `--margin` | 裁边后四周留边 px，默认 3（0–16） |
| `--no-optical` | 关闭光学校正 |
| `--no-matrix` | 只按字体策略出一张，不遍历当前选择字体 |
| `--out` | 输出目录 |
| `--key` / `--endpoint` / `--timeout` | 覆盖云接口参数 |
| `--list-fonts` / `--catalog` | 列字库 / 强制刷新字库 |
| `--tag-match` / `--tag-stats` | 测试 tag 匹配 / 查看 tag-pools 统计 |
| `--font-spec` / `--rebuild` | 查看 / 重建字体基准 |
| `--probe` | 测试云接口，不写文件 |
| `--inspect` | 校验一张 PNG 的 alpha、墨迹尺寸与四周留边 |
| `--dry-run` | 只算张数 |
| `--json` | JSON 输出 |

## 档位自检（按 mtag 清单自动定产品）

```bash
# 按 config.json 当前的 tag_file 看会落哪一档
python scripts/usage.py --detect

# 指定某个档次的清单 / 目录
python scripts/usage.py --detect ../ugi-sum/ugi-font500

# 一次列出 ugi-sum 下六档各自落档结果
python scripts/usage.py --scan ../ugi-sum
```

输出含 `sku` / `display_name` / `position` / `library` / `price` / `unit_price` / `monthly_cap` / `font_count` / `source`。
`source=count` 表示按清单记录数认出（正常路径）。

## 自检与校验

```bash
# 环境自检 + 出图自测（含「一」的留边与横细笔画校验）
python scripts/check_env.py --selftest --json

# 校验单张 PNG
python scripts/render_cli.py --inspect d:\ugi-out\001_xxx.png --json
```

`--inspect` 会返回 `ink`（墨迹宽高）与 `pad`（上下左右留边），正常应等于 `mask_margin` 的四倍值，例如 `[3,3,3,3]`。
