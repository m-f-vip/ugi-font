# 上架自检清单

## 一、功能

- [ ] `python scripts/server.py --port 8766 --open` 能自检、启动服务并打开界面。
- [ ] 界面只有单任务工作台：字库池 ‖ 当前字体、文本 ‖ 智能 tag 两组等高并列卡片，下面是进度与结果。
- [ ] 设置区只有两个 Tab：参数设置（含输出目录） / API 设置。
- [ ] 字体策略默认是「智能tag」。
- [ ] 字库池能列出本档白名单字体（数量 = 清单记录数），并按字体家族分组；云端清单可热刷新。
- [ ] 勾选字体 →「加入 →」→ 右栏出现该项；点 × 能移除。
- [ ] 文本修改、参数修改、智能 tag / 指定 tag 修改都能持久化到 `config.json`。
- [ ] 「指定 tag」默认 屌丝，躺平；编辑后按 tag 同步与渲染筛选都会强制并入。
- [ ] 「生成 text-mask」能出图，进度条与结果缩略图正常刷新。
- [ ] 「中断」可暂停、「继续」可恢复、「结束」能保留已完成结果；「结束」后中断按钮当拍复位。
- [ ] 顶栏显示 `剩余时间：xx / 30 天` 与 `可用次数：n / 上限 张`；次数与时间同源，重置时整组清零。
- [ ] 额度用到「月上限 ×110% + 1 张」才拒绝出图（10 张档 = 12 张），此前只提醒不拦。

## 二、字体基准与裁边

- [ ] 首次使用某字体时会在 `assets/zwfnt26xsp.json` 生成该字体的「国」字基准（`face` / `side` / `optical`）。
- [ ] 基准只建一次：第二次出图不再重测（可用 `--font-spec` 查看 `mtime` 未变化）。
- [ ] 每张 mask 四周留边严格相等，默认 `[3,3,3,3]`。
- [ ] 留边可设为 0 与 16，实测 `pad` 随之变化。
- [ ] 「一」输出为细长横条，未见变形、未见笔画断裂。
- [ ] 成品尺寸 = 墨迹尺寸 + 2×mask 留边，四边数据一致。
- [ ] 字体换版（文件大小 / mtime 变化）后基准会自动重测。

## 三、清理项

- [ ] 界面没有 style / effect / 背景 / 前景 / case 等入口。
- [ ] 界面没有「国」字基准面板。
- [ ] 代码里没有特效 / 动效 / 案例 / 九宫格相关模块与素材目录。
- [ ] 文案没有版本注解类内容。
- [ ] 收费口径统一为「本档 ¥0/月，平台按月订阅」，不出现 9.9 / 原价 / 2 折 / 限时字样。

## 四、环境与安全

- [ ] `python scripts/check_env.py --selftest --json` 返回 `ok: true`。
- [ ] `python -m py_compile scripts/*.py` 全部通过。
- [ ] 服务只监听 `127.0.0.1`。
- [ ] `/api/preview` 传输出目录之外的路径返回 403。
- [ ] 授权 Key 只在本机校验，未联网上报。
- [ ] 内置 Key 文案统一为「仅供本机功能自检、禁止商用」，界面 pill 同步显示该口径，不出现时间限制类表述。

## 五、文档

- [ ] `SKILL.md` 的 description 与实际能力一致（只出 text-mask）。
- [ ] 字库规模表述一致：20 款 / 二期计划 5000 款 / 三期计划 10000 款 / 国标二级 / tag 池 20 个字体。
- [ ] 已写明「付费前先体验免费版 ugi-free（原 ugi-buddy）」及两版差别（20 款 vs 20 款、tag 智能标签完整 vs 精简、free 不可商用），免费版链接有效。
- [ ] 商品描述与授权文档已如实披露「本档 ¥0/月 / 订阅者自身使用 / 每月维护内容」。
- [ ] `README.md` 界面说明与真实界面一致。
- [ ] `doc/user-guide.md` 两个设置 Tab 的字段齐全。
- [ ] `doc/api_reference.md` 与 `server.py` 路由一致。
- [ ] `doc/cli-cheatsheet.md` 与 `render_cli.py` 参数一致。
- [ ] `doc/copyright.md` 的证书图片可正常显示，且发布包不含平台白名单外的文件。

## 六、平台付费发布包

- [ ] zip 根目录直接是 `SKILL.md`，无外层文件夹，且整包 ≤3MB。
- [ ] 只含白名单扩展名（.md .txt .json .yaml .yml .js .cjs .mjs .ts .py .sh .html .css .csv .toml .png .jpg .svg **.pkl**），无 .bat / .ttf / .pdf / .exe。
- [ ] ⚠️ 确认开放平台允许技能包内携带 `.pkl` 数据文件（mtag 授权清单）；若平台拒绝 `.pkl`，须改为 `.json` 或走 base64 内联。
- [ ] `display_name` 仅中英文数字与连字符；frontmatter 六项必填齐全。
- [ ] 不同档次只有两处必须改：① `assets/` 下 mtag 授权清单（内容不同 = 白名单不同 = 档位不同）；② `SKILL.md` frontmatter 的展示文案（display_name / summary / description* / commercial_license_price / edition）。
- [ ] 产品名 / 定位 / 字库规模 / 月费 / 每款单价 / 月上限由清单自动定档：`python scripts/usage.py --detect` 结果与上架档位一致（`source=count`）。
- [ ] `scripts/paid_entry.py` 的 `EDITION_MTAG` 指向本档清单，`edition` / `edition_name` 与清单自动推出的一致。
- [ ] `scripts/paid_entry.py --text ... --json` 返回 PNG base64，且不依赖本机字库文件与本地服务。
- [ ] 后台付费方式选「按月付费」、金额填 129 元；付费方式发布后不可更改，改价次数每年有限（次年 1 月 1 日重置），免费资产也不能转付费。
