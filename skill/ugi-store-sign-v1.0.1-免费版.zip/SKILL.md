---
name: ugi-store-sign
slug: ugi-store-sign
display_name: "门店招牌字（免费）"
display_name_en: "门店招牌字（免费）"
displayName: "门店招牌字（免费）"
summary: "门店招牌字免费做：门头橱窗出 3 组稳重透明字。"
description: "实体店想换门头招牌？把店名或活动语输进来，免费出 3 组稳重透明字，交给广告物料就能用。适合实体店主、门店运营做门头与橱窗。门店招牌、门头大字、橱窗贴字、线下物料都能用。20 款字体仅个人学习评估、不可商用；商用订阅 Font 900。"
description_zh: "实体店想换门头招牌？把店名或活动语输进来，免费出 3 组稳重透明字，交给广告物料就能用。适合实体店主、门店运营做门头与橱窗。门店招牌、门头大字、橱窗贴字、线下物料都能用。20 款字体仅个人学习评估、不可商用；商用订阅 Font 900。"
description_en: "Turn a short Chinese line into transparent title-mask PNGs: smart-tag font matching, 32-bit RGBA white-on-transparent output, per-font 国-glyph optical baseline and exact 3px margin, 3 skeleton-difference variants by default. For free creators; input a Chinese phrase, output ready-to-overlay transparent title assets. Use when the user mentions cover titles, headline text, text masks, short-video covers, Guochao or handwriting styles. Free tier opens 20 faces (20 font records / 675 tags), free of charge, 10 images/month. Free for personal, non-commercial evaluation only. Subscription, authentication and billing are handled by the platform."
examples_zh:
  - "「拾光咖啡」做成门店招牌大字，稳重点"
  - "这家店的门头字出 3 组透明备选"
  - "把开业活动语做成橱窗贴字"
examples_en:
  - "Make 'Times Cafe' a steady storefront sign text"
  - "Give me 3 door-head sign variants for my shop"
  - "Turn the opening promo into transparent window text"
version: 1.0.1
author: "zw"
category: "设计多媒体"
platforms: "workbuddy"
tags: [cover-word, headline, 门店招牌字]
keywords: 门店招牌, 店铺招牌字, 门头大字, 橱窗贴字, 线下物料, 稳重, 透明底, 字图
license: "Free for non-commercial use (see LICENSE.txt)"
allowed-tools: "Bash, Read, Write"
compatibility: "Python 3.9+ / Pillow (required), numpy & jieba (optional), Windows/macOS/Linux. 字库与渲染走 UGI-API 云通道。"
edition: ugi-store-sign
scene_profile: "门店招牌字"
preset: "P4 报告稳重"
upsell: "ugi-font900"
builtin_key: "ugi-free-2026-12-12"
builtin_key_note: "仅供本机功能自检，禁止商用"
commercial_license_price: "免费 ¥0 / 每月 10 张"
documentation: "doc/README.md"
---

# 门店招牌字（免费） · 免费引流

**唯一任务：把文本渲染成 text-mask。** 产物是 **PNG / RGBA / 8bit×4 = 32 位 / 纯白文字 / 背景 alpha=0** 的透明图，直接进设计、短视频、字幕、封面流程。

> **产物是 mask，不是成品图。** UGI 只输出**纯白文字 + 透明背景的文字蒙版（mask）**，属于中间素材；后期需要在设计工具（PS / AE / 剪映 / 前端或自有渲染管线）里叠加材质、光影、渐变、描边、动效等特效，才能得到最终画面。

## 本版说明（门店招牌字（免费））

**一句话定位**：实体店想换门头招牌？把店名或活动语输进来，免费出 3 组稳重透明字，交给广告物料就能用。

**三步上手**（在本技能目录运行）：
1. `python scripts/check_env.py --selftest --json` —— 自检环境
2. `python scripts/server.py --port 8766 --open` —— 启动界面
3. 粘贴中文短句 → 选风格 tag → 导出透明 PNG 叠到线下门店物料

**适合**：实体店主；门店运营；要门头橱窗字。

**不适合**：要印刷安装；要商业授权；要整套门店设计。

**授权说明**：随包 20 款字体仅限个人学习评估、不可商用，出组不改变授权边界；需要商用请订阅 Font 900。免费额度按平台账户统一计量（日 3 次、每月 10 张）。

## 快速开始

1. 在技能目录运行 `python scripts/server.py --port 8766 --open`：自检环境 → 启动本地服务并打开界面（`http://127.0.0.1:8766/`）。
2. 「工作台」页左侧「字库池」勾选字体 → 点「加入 →」，右侧「当前选择字体」就是真正参与渲染的清单。建议先「按 tag 同步」再手动加入：手动加入权限最高，可加入与智能tag 无关的字体，后续任何自动同步都不会把它冲掉。
3. 「工作台」页下方「文本池」输入文本（每行一组，单行 ≤ 50 字）；点任一行即切换「当前文本行」，智能 tag 会自动跟着变。点「生成 text-mask」——**生成时只出当前文本行** × 字体策略给出的字体序列，每个字体各 1 张 mask。
4. 到 `d:\ugi-out` 取图。白字透明底在白色查看器里像空白，贴到深色底即可看清。

## 平台调用入口

平台托管环境不需要本地界面与服务，用 `scripts/paid_entry.py` 直接出图：

```
python scripts/paid_entry.py --text "标题字" --fonts "字体A,字体B" --json
```

返回 `{"ok":true,"count":N,"elapsed":1.55,"images":[{"font":...,"width":...,"height":...,"png_base64":...}],"usage":{...}}`；一行文本 × N 个字体 = N 张 32 位 RGBA 透明 PNG。渲染走官方 UGI-API 云通道，云接口 Key 取环境变量 `UGI_FONT_KEY`。订阅权限由平台控制，入口不做鉴权、不结算账单、不落盘用户数据。

**一次调用同时回传次数与时间**（平台侧其他 skill 拿 mask 时顺手就有额度，不用再查一次）：

| 字段 | 含义 |
| --- | --- |
| `usage.used` / `cap` / `remaining` | 本周期已用 / 月上限 / 剩余张数 |
| `usage.hard_cap` / `buffer_left` | 含 10% 冗余 + 1 张的硬上限 / 还能再出几张 |
| `usage.first_ts` / `last_active` | 本周期首次出图时间 / 最近一次出图时间（Unix 秒）；与 `used` **同源同一次落盘**，清零时一起变空 |
| `usage.days_left` / `period_days` | 剩余天数 / 周期长度；界面固定显示 **`剩余时间：{days_left} / {period_days} 天`**，默认 `30 / 30 天` |
| `usage.days_left_source` | `idle` = 还没出图（满额 30/30）、`anchor` = 本机首次使用起算 30 天倒计时、`cycle` = 平台下发的租期、`expired` = 本机 30 天窗口已过（等待平台下发新周期，不影响出图） |
| `usage.period_start` / `period_end` | 本周期锚点（首次出图 / 重置 / 跨月滚动时刻）、推算的周期结束时间 |
| `usage.cycle_id` / `cycle_seq` / `cycle_end` | 平台周期标识 / 期数 / 到期时间戳 |
| `usage.rolled` / `cycle_expired` | 本次读取是否刚触发过周期滚动（`month_rollover`）；平台租期是否已到期（到期不停服，天数回落自然月） |
| `usage.tier` | 档位名、展示名、定位、字库规模、月费、每款单价、月上限 |
| `usage.level` / `message` | `ok` / `near`（≥90%）/ `over`（满额）/ `blocked`（≥110% + 1 张，本次直接拒绝出图、退出码 2） |

出图张数按实际成功数累计；非白名单字体进 `skipped`，不计数、不出图。每张之间固定 0.1s。

## 字库资源

- 开放 **20 款**个性化中文字库（clay 粘土体 + fat 肥仔体两家族），免费体验。
- 本包 `assets/zwfnt26mtag_v1x.pkl` 收录 20 个字体 / 675 个 tag，供智能 tag 选字；一个字库家族可含多个字重或变体，故字体记录数多于开放套数。
- 字库范围 = 本版本 mtag 授权清单（各档次不同文件）与云端 UGI-API 字体清单取交集，渲染统一走官方 UGI-API 云通道。

## 出图规则

- **矩阵渲染**：生成时**只出当前文本行**（`output_modes` 固定 `single`），总张数 = 1 × 当前选择字体数（没有数量上限）。默认「智能tag」策略按当前文本行分词提取关键词，把「当前选择字体」按 tag 相关度排序后**全部出图**；每个输出单元强制使用**单个**字体，不做行内混搭；无法加载的字体在启动前预检剔除并写日志，不拖垮整批。
- **默认出组（推荐工作流，不改引擎）**：默认在随包 20 款里挑**骨架差异最大的 3 款**（按「稳 / 强 / 变」分工，跨 clay 与 fat 两家族各取一款），一次生成同批回传 3 组 mask 供挑。出图前明示「本次用 3 张、本月共 10 张」并提供"只出 1 张"选项；免费版仅限个人学习评估、不可商用，出组不改变授权边界。用户想要更少时，手动减少「当前选择字体」即可（减到 1 款即退回单张）。
- **单张图间隔**：相邻两张图之间固定等待 **0.1s**（`font_interval`，可配 0 关闭），避免同一时刻密集请求云端 / 密集落盘。
- **统一自动裁边**：每张 mask 渲完按 alpha 通道求墨迹边界裁到最紧，再新建画布在四周**精确补齐** `mask_margin` 像素（默认 **3px**，可设 0–16）。补边是新建画布外扩，不是原图内缩，所以四边留边永远相等，贴边字形也不会被切笔画。
- **「一」不变形**：裁边只按 alpha 求边界、不缩放笔画，横细笔画不会被拉伸；成品尺寸恒等于墨迹尺寸 + 2×留边。
- **光学校正**：按该字体的「国」字字面率把字号放大到统一视觉大小（≤1.20 倍，只放大不缩小）；结果里带 `optical` 倍数，可随时关闭。
- **字距**：参数页「字距 px」= `char_gap`（默认 **0px**，可设 0–60）。UGI-API 一次接收整行文字且参数里没有字距项，因此在本地按字数把 mask 均分成字格，在相邻字格之间插入 `char_gap` 像素透明列，**不增加任何云端请求**；成品宽度 = 原墨迹宽 + `char_gap` ×（字数 − 1）。**汉字和英文、标点混用时按字数均分切列会有切分误差，建议保持 0 px**（参数页 label 旁已标注）。

### 中断 / 结束 / 计次

- **中断（暂停）**：停止推进新图片，已出的图保留；再点「继续」从下一张接上，状态标签显示「已中断」（按钮变「继续」并高亮）。
- **结束**：立即中断任务。**中断按钮在同一拍就复位**（回到「中断」、去高亮、禁用），状态标签变「正在结束」→「已结束」，不等最后一张图跑完；正在渲染的那 1 张会跑完（云端请求无法中途掐断），间隔等待改成 30ms 切片，最多多等 30ms。15s 仍未收尾则前端强制复位，允许重新生成。
- **计次口径**：**按已出图张数计，中止不回退、不清零**。记账发生在任务落状态之前，所以界面看到「已结束」的那一拍，顶栏次数已经是新值（`/api/state` 直接带 `usage`，不靠二次请求读旧值）；toast 会写明「已结束 · 已出 N 张 · 本月已用 X/Y 张」。
- 结束后再点「中断」不会生效（服务端 409、前端直接忽略），避免按钮状态来回跳。
- **清零口径（次数与时间必须同拍）**：`used`、`first_ts`、`last_active`、`anchor`、`reactivated_at` 属于同一份记录，**任何一次归零都是整组一起清**，不存在「次数归零、时间还挂着上月」的半重置，也不存在「剩余时间永远不动」的常量。触发归零只有三种：① 平台下发的周期标识变化（新订阅周期 / 首次激活）；② 平台未透传周期标识时跨自然月（`month_rollover`，读取用量即自动判定并落盘）；③ 显式调用 `POST /api/usage/reset`（接口保留，界面不设按钮）。

## 订阅周期与用量计数器 assets/zwcnt.pkl

按月订阅是**平台托管的授权租期**：到期由平台自动收回访问权限。Skill 不判断是否到期、不中断服务、也不感知手动续费或自动扣款——唯一依赖的信号是**服务端下发的周期标识是否变化**。

- 状态**只用 `assets/zwcnt.pkl`**（六档矩阵 + 每档用量 + 周期记录），不创建任何 JSON 状态文件。**次数计算器（`used` / 剩余次数）与时间计算器（`first_ts` / `last_active` / `anchor` / `cycle_end` / `reactivated_at` / 剩余天数）都读写同一个 pkl 的 `cycles[sku]`，不存在第二个计数或计时文件**；logo 右侧「剩余时间：xx / 30 天」「可用次数：剩余 / 上限 张」两个 pill 来自 `/api/usage`，同时也随 `/api/state`（渲染中/结束那一拍）一起下发，保证状态与次数同步刷新。
- **次数与时间同源同清**：`cycles[sku]` 内 `used` 与 `first_ts` / `last_active` 是同一组字段，滚动或重置时**一次 `save_store` 全清**。`usage[sku]` 是给旧消费者的镜像，同样带 `month` / `used` / `first_ts` / `last_active`，与 `cycles` 始终一致。
- **自然月滚动**：平台未透传周期标识时，读用量即比较 `month`；跨月则整组清零（`used=0`、两个时间置空、`anchor`/`reactivated_at`=now、`seq`+1），字段名 `rolled: "month_rollover"`。只用「是否跨月」判定，不做任何过期推断。
- 周期标识（`CycleEndTime` / `cycle_id`）由平台透传，三种接法：`GET /api/usage?cycle=…`、`POST /api/usage/sync {"cycle":"…"}`、`POST /api/render` body 的 `cycle` 字段；前端会自动读取页面 URL 的 `cycle` 参数并透传。
- 标识**首次下发** → 激活（seq=1、计数器与时间归零）；标识**变化且更晚** → 判定新周期 → **重新激活 + 初始化**（`used=0`、`first_ts`/`last_active` 清空、seq+1、记 `reactivated_at`）；标识**不变** → 正常累计；**旧标识回退 / 未透传** → 不重置、不做过期推断。
- **剩余时间按 30 天周期倒计时**：头部 pill 固定显示 `剩余时间：{剩余} / {周期} 天`，默认 **`30 / 30 天`**。平台下发 `cycle_end` 时按平台租期算（分母取锚点→到期的实际天数）；没下发时按**本周期首次出图时刻**起算 30 天，天数随时间递减（如用了一周变 `23 / 30 天`），跨月滚动或重置后回到 `30 / 30 天`；还没出图时显示 `30 / 30 天`（本周期尚未开始消耗）。三种来源都只是显示，不停服、不拦出图。
- **租期到期不停服**：`cycle_end` 已过而平台未下发新标识时，`cycle_expired=true`，次数保留（到期由平台收回权限），剩余天数仍按 30 天口径展示，不会卡在 0 天。
- **显式重置**：`POST /api/usage/reset`（body 可选 `tag`、`hard`）把次数与时间一起清零；`hard=true` 连周期标识与期数一起清（等同新装）。**界面不设重置按钮**，该接口供平台运维 / 自检调用；注意与 `/api/reset`（只清任务进度、不动用量）区分。
- 只有「超出月上限 110% + 1 张」才由 Skill 中断服务（额度控制，与租期无关）；达到 90% 给升级提醒。

## 字体基准 assets/zwfnt26xsp.json

每个字体**首次参与出图**时，先渲一个「国」字（缺字自动换「园」「圆」「口」「回」；再缺就与 `.notdef` 对比判定为无中文字形），量出并落盘：

| 字段 | 含义 |
| --- | --- |
| `probe` / `probe_ok` | 实际探测用的字、是否成功 |
| `face` | 字面率（墨迹长边 / 字号） |
| `side{l,t,r,b}` | 墨迹到 em 框的上下左右距离 |
| `optical` | 光学校正系数（目标字面率 0.90，上限 1.20） |
| `bytes` / `mtime` | 源文件指纹，字体换版后自动重测 |

键为字体 id 小写（`norm_font_id`），之后所有 mask 直接读这份基准，不再重复探测。基准属于**后台隐含能力**，界面不占位；需要查看或重建时用命令行：

```bash
python scripts/render_cli.py --font-spec --json      # 查看
python scripts/render_cli.py --font-spec --rebuild   # 全量重建
```

## 界面

顶部两个主 page：**工作台** / **参数**。

**工作台**（`#work`）

| 区域 | 内容 |
| --- | --- |
| 上左 · 字库池 | 白名单字库（单一，按字体家族分组）、搜索、展开 / 收起全部、全选结果 / 清空勾选、**加入 →（手动加入，权限最高；按钮左侧常显「建议先按 tag 同步再加入」）** |
| 上右 · 当前选择字体 | 单个移除、按 tag 同步、清空；**手动加入的字体带「手动」标记且置顶保底**；与字库池**等高并列**，默认按 **15 行**高度显示（**仅显示行数，不是数量上限**；选多少就出多少张） |
| 中左 · 文本池 | 多行文本框（行号 + **可编辑的当前文本行 t**）、生成 / 中断 / 结束；**生成时只出当前文本行** × 字体策略给出的字体序列；光标切行时智能 tag 自动同步 |
| 中右 · 智能 tag | 与文本池等高并列：识别 tag、指定 tag（默认 屌丝，躺平，筛选强制并入）、重新识别、6 个预设；卡片**底部内嵌「字体策略」面板**（智能tag / 随机 / 指定）；两栏都支持逗号 / 空格分隔 |
| 下 · 进度与结果 | 进度条、结果缩略图（棋盘格底）、日志 |

字库池没有标题栏（顶部一行是本地 / 云子 tab、搜索框、数量标签，下一行是批量按钮）；它与当前选择字体是同一行里的两张卡：高度按「15 行字体」量出来（首次渲染时按实际行高算，之后固定；窗口装不下时按 86vh 收敛，最少 6 行），列表条数多少只影响卡片内部滚动、不会把卡片撑高或压扁；需要更高时拖两卡下方那条拖拽柄（高度记在浏览器本地，下次打开沿用）。**这里的 15 只是卡片默认显示行数，不是字体数量上限**：「当前选择字体」可以超过 15 个，全部保留、全部出图，多出的在卡片内部滚动查看。**每次生成的字体数量没有上限**（唯一的额度约束是订阅月上限张数，见 `assets/zwcnt.pkl`）。

字库池按**字体家族**分组：同一家族的多个字体文件收进一个可折叠组（组头带三态勾选框，可整族勾选），默认收缩，点组头展开；单文件家族直接平铺成一行。搜索时命中组自动展开。分家时**忽略文件名里的数字**（`zw.ACIDBRANCH1/2/7/9` → `zw.ACIDBRANCH`，`zw.CLAY3/clay4` → `zw.CLAY`），合并组子项显示完整文件名。

**参数**（`#param`）

- **设置**（两个 Tab）：参数设置 · API 设置
  - 参数设置（字段与 UGI-API 一一对应）：字号 `s`、mask 留边 px、**字距 px（默认 0；汉字和英文、标点混用会有切分 bug，建议 0 px）**、字色 `tc`、底色 `bc`、输出格式 `o`（png / b64）、光学校正与输出目录。
  - API 设置：服务端口、超时、接口地址、**字体清单接口**、**ugi 演示站 / 标准参考站（可自定义，右侧「打开」即热链接）**、授权 Key、启动时自动下载云端清单、测试云接口（渲「元字库」，只测连通不写文件）。
- **字体策略**（工作台「智能 tag」卡片底部）：智能tag（默认）/ 随机 / 指定，切换后决定本次用哪些字体、出几张（见下方「字体策略」章节）。

输出方式固定为**单行文本**（整行一张），且**生成时只出当前文本行**，界面不提供切换。结果缩略图点击看大图（棋盘格底），Esc 关闭。

## 参数要点

- **Key**：`API 设置 → 授权 Key`。默认 `ugi-free-2026-12-12` 仅供本机功能自检、禁止商用，也可换云接口正式 Key 或环境变量 `UGI_FONT_KEY`（优先级最高）。该 Key 只作用于 UGI-API 取图，不代表平台订阅状态；订阅权限由平台控制，技能按月订阅，本档免费。校验在本地完成，不上传 Key，也不阻断渲染。
- **UGI-API**：`o / s / d / tc / bc / c / f / t / key`，方向恒为 `d=ltr`。接口回传不透明底图，本机按亮度重建 alpha 并强制 RGB 纯白，再统一裁边。
- **输出方式**：界面固定 `single`（整行一张）。服务端 `/api/render`、CLI `--dry-run` 与渲染主循环共用 `build_render_jobs()`，张数永远一致；CLI 可用 `--split-mode` 临时切到 `char` / `multi` 做单次输出。
- **参数映射**（界面字段 ↔ UGI-API 参数）：`t` 文本（文本池 / 可编辑的「当前文本行」）、`s` 字号、`tc` 字色、`bc` 底色、`o` 输出格式、`d` 排版方向（隐含固定 `ltr`，不提供设置）、字距 `char_gap` 与 mask 留边（均为本机后处理，不属于接口参数）；`work_fonts` / `selected_fonts` 为当前选择字体，`manual_fonts` 为其中手动加入、权限最高的子集。
- **文件名**：`{index:03d}_{font}_{text}_{split}`，平铺在输出目录，不建子目录。

## 字体策略

三种策略都由 `scripts/render_engine.py::matrix_font_plan()` 在**本次生成时**决定字体序列，界面切换后立即生效（提示条会显示策略与预计张数）。生成恒为「当前文本行 × 字体序列」，每个字体各出 1 张，不做行内逐字混搭。**字体数不设上限**，预计张数 = 当前选择字体数。

| 模式 | 行为 | 预计张数 |
| --- | --- | --- |
| 智能tag（**默认**） | 先用**结巴（jieba）分词 + `jieba.analyse` 关键词提取**把当前文本行切成真实词，再合并「智能tag + 指定tag」→ 与 tag-pools 精确命中 / 同系列映射 / 相关度补齐 → 按 tag 相关度排列「当前选择字体」；切行 / 切策略时自动按 tag 重算（保留手动加入）。与 `/api/work-fonts` 共用同一挑选口径 | 当前选择字体数 |
| 随机 | 把「当前选择字体」打乱顺序，每次生成结果不同；手动加入的字体仍置顶 | 当前选择字体数 |
| 指定 | 全部当前选择字体，顺序不变，每个字体各 1 张；手动加入的字体置顶 | 当前选择字体数 |

> 三种策略都出「当前选择字体」全集（界面所见即出图所用），区别只在**顺序**与**自动重算时机**；手动加入的字体在任何策略下都必出。
### 字库池手动加入（权限最高）

在字库池勾选后点「加入 →」的字体属于**手动加入**，写在 `config.json` 的 `manual_fonts` 里，列表上带「手动」标记：

- **建议顺序**：先点「按 tag 同步」让智能tag 挑好一批字体，再手动加入想要的字体；这条提示也常显在「加入 →」按钮左侧。
- **可以加入与智能tag 无关的字体**：手动加入不受 tag 匹配约束，只要是白名单内（授权 ∩ 云端可达）即可。
- **不会被覆盖**：按 tag 同步、光标切行自动同步、切换到智能tag 策略、启动默认填充，都是「先算 tag 结果 → 再叠加手动字体」，手动字体置顶且优先占位。
- **没有数量上限**：手动加入不会挤掉 tag 自动挑的字体，tag 同步也不会挤掉手动字体；两类字体全保留、全出图，卡片默认只显示 15 行，多出的内部滚动。
- **一定出图**：三种策略都把 `manual_fonts` 恒置顶、恒出图，不会因为 tag 只取前 N 个而被漏掉。
- 只有用户主动移除（`×`、取消勾选、清空勾选 / 清空）才会取消手动标记；替换建议点选加入的字体同样算手动加入。


tag-pools 来自 `assets/zwfnt26mtag_v1x.pkl`：20 个字体、7 个维度（书体类别 / 骨架结构 / 笔画形态 / 中宫重心 / 质感装饰 / 情绪性格 / 应用场景）、675 个中英标签，含 86 组场景同义桥接（如「霓虹 → 发光边缘 / 未来感 / 科技感」）。字体 id 做 exact / stem / series 三级映射，云端 F 变体与标签库 J 变体都能命中。

## 智能 tag

纯本地 NLP，**先分词、再提取关键词**：分词优先用结巴 `jieba.cut(HMM=False)`（`jieba-fast` 快速模式，关闭 HMM 新词发现），未装 jieba 时降级为内置零依赖的结巴式快速分词器（前缀词典 + DAG + 动态规划）。切出的词再经 `jieba.analyse` 的 TF-IDF / TextRank 提取关键词，与词级打分（领域词 > 词典词 > 普通词）合并排序，输出的是分词后的真实词而非整句；缺库也绝不让渲染失败。

- 默认按**当前文本行**（文本池里光标所在行，空行时取首个非空行）提取，结果以英文逗号写入 tag 框；**光标切行、编辑本行、改「当前文本行」输入框时自动重新识别并同步 tag 框**（280ms 防抖，正在手改 tag 框时不抢输入），智能tag 策略下还会连带刷新「当前选择字体」。
- 6 个预设（赛博霓虹 / 国风水墨 / 可爱圆体 / 故障电竞 / 极简品牌 / 金属综艺）点击即演示该案例的提取结果，不写文本框。
- 两个 tag 栏都接受英文逗号、中文逗号、分号、顿号与空格分隔，服务端统一归一化为逗号串。
- 「指定 tag」是可编辑输入框，默认 `屌丝，躺平`。智能 tag 筛选时强制把它并入识别结果：「按 tag 同步」与渲染时的 tag 匹配都按合并后的 tag 选字；清空该栏即不再并入。
- 「按 tag 选字 / 按 tag 同步」用合并后的 tag 重新匹配并刷新当前选择字体。

## 命令行

```bash
python scripts/render_cli.py --list-fonts
python scripts/render_cli.py --text "会挣钱的智能体" --json
python scripts/render_cli.py --text "富贵吉祥" --split-mode char --margin 3
python scripts/render_cli.py --text "元字库" --mode smart_tag --json
python scripts/render_cli.py --text "元字库" --channel cloud --probe
python scripts/render_cli.py --font-spec --json
python scripts/check_env.py --selftest --json
```

完整参数见 `doc/cli-cheatsheet.md`。

## 本机 API

服务默认 `http://127.0.0.1:8766`，仅监听回环地址。主要接口：

`GET /api/health`、`GET|POST /api/config`、`GET /api/catalog-status`、`GET|POST /api/catalog`、`GET /api/fonts`、`POST /api/work-fonts`、`GET /api/tag-pools`、`GET /api/tags`、`GET|POST /api/segment`、`GET|POST /api/smart-tag`、`GET /api/tag-presets`、`GET /api/hot-lines`、`GET|POST /api/font-spec`、`POST /api/probe`、**`POST /api/render`**、`GET /api/state`、`POST /api/pause`、`POST /api/stop`、`POST /api/reset`、`GET /api/preview`（仅限输出目录内的 PNG，越权返回 403）、`GET /api/docs`、`GET /api/license`、`GET /api/open-folder`。

完整字段见 `doc/api_reference.md`。

## 文件结构

```
ugi-font/
  SKILL.md / README.md / LICENSE.txt / config.json
  assets/    ugi-logo-512.jpg · zwfnt26mtag_v1x.pkl（各档次授权清单）· zwfnt26xsp.json（国字基准）
             hot_lines.json · stopwords.txt · 证书
  ui/        index.html · app.js · style.css · logo.jpg
  scripts/   ugi_core · font_spec · tag_pools · smart_tag · quick_cut · catalog
             font_selector · truetype_api · render_engine · server · render_cli · check_env
             paid_entry（平台付费入口）
  doc/       README · user-guide · cli-cheatsheet · api_reference · copyright · release-checklist
  templates/ config.example.json
```

## 常见问题

- **输出图看着全白**：白字透明底在白色查看器上不可见，贴到深色底查看。
- **智能tag 没匹配到字体**：tag-pools 用专业词表，口语词靠同义桥接；可换 tag 或改用随机模式。
- **云端字体清单下载失败**：后台线程自动降级到内置清单，出图不受影响，稍后刷新即可恢复完整字库。
- **某个字体出不了图**：多为字体文件损坏或缺中文字形。启动前会预检并写日志；缺字字体在基准里标记 `probe_ok=false`，渲染时按原字号处理。
- **字王大藏经缺字**：如「程」「鎏」「填」「纹」等，正文行建议换成覆盖更全的字体。

## 收费与授权

- **本包即免费版**：20 款字体、精简 tag 池，**仅限个人学习评估、不可商用**；需要更多字库、全量智能 tag 与商用授权，请订阅 Font 900。
- **本档免费 · ¥0**：本技能免费发布，无需订阅与付费；如需商用授权请订阅 Font 900。
- **每月维护**：字库与 tag 池月度更新、「国」字基准校正、出图规则与界面迭代、平台接口变更跟进，保证订阅期内持续可用。
- **授权边界**：订阅仅限订阅者自身使用，禁止转售、分发、嵌入、训练等；其他用途另行授权。
- **内置 Key**：`ugi-free-2026-12-12` 仅供本机功能自检、禁止商用，也不会联网上报；云接口正式 Key 由部署方通过 `UGI_FONT_KEY` 配置。

## 版权与授权

**UGI 系列插件是 zw《中华大字库》唯一合法版权持有人与唯一官方 API；其他渠道均属非法盗版。** 官方演示站与接口信息见 `doc/copyright.md`。证书截图见 `doc/copyright.md`。
